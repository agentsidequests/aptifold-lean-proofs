"""Mathematical routines extracted from the original Schwarzschild calculation."""
from math import comb
from flint import fmpq_poly
from angular_algebra import CTX, Q, decode, ell, f, k, potential, r

ZERO = Q(0)


def differentiate(q, index):
    """Differentiate with the repeated part of the denominator factored."""
    q = Q(q)
    dn, dd = q.n.derivative(index), q.d.derivative(index)
    if not dd:
        return Q(dn, q.d) if dn else ZERO
    common = q.d.gcd(dd)
    den, remain = divmod(q.d, common)
    diff, dremain = divmod(dd, common)
    if remain or dremain:
        raise ArithmeticError("Derivative denominator did not divide exactly")
    return Q(dn*den-q.n*diff, q.d*den)

def specialize(record,label):
    value = decode(record)
    out = []
    for poly in (value.n,value.d):
        terms = {}
        for powers,coefficient in poly.terms():
            key = (*powers[:9],0)
            terms[key] = terms.get(key,0)+coefficient*label**powers[9]
        out.append(CTX.from_dict(terms))
    return Q(*out)

def remove_polynomial(poly, divisor):
    count=0
    while poly.degrees()[0]>=divisor.degrees()[0]:
        smaller, remainder=divmod(poly,divisor)
        if remainder:
            break
        poly=smaller
        count+=1
    return poly,count

def action(row):
    Vp,Vd=potential(ell)[4],potential(2*ell)[4]
    a,b,c=r*r*(k*k+Vp),2*f/r,1/(r*r)
    def d(row):
        p,q,s=row
        return (f*differentiate(p,0)+a*q, f*differentiate(q,0)+2*c*p+b*q+2*a*s,
                f*differentiate(s,0)+c*q+2*b*s)
    return tuple(x-(4*k*k+Vd)*y for x,y in zip(d(d(row)),row))

def coefficients(value):
    if not value:
        return {}

    def gather(poly):
        groups={}
        for powers,c in poly.terms():
            groups.setdefault(powers[0],{})[(0,*powers[1:])]=c
        return {j:Q(CTX.from_dict(a)) for j,a in groups.items()}

    den = gather(value.d)
    if len(den)!=1:
        raise ValueError("Radial Laurent polynomial required")
    (index, scale),=den.items()
    return {j-index:c/scale for j,c in gather(value.n).items()}

def laurent_system(source,resource):
    right = [coefficients(q) for q in source]
    p = max(7, -min(power for row in right for power in row)-4)
    d = max(0,1+max(int(q.n.degrees()[0]-q.d.degrees()[0])+2*j for j,q in enumerate(source) if q))
    labels = []
    equations = {(j,power):({},q) for j,row in enumerate(right) for power,q in row.items()}
    for j in range(3):
        for m in range(-p,d-2*j+1):
            column = len(labels)
            labels.append((j,m))
            row = [ZERO]*3
            row[j] = r**m
            for component,value in enumerate(action(row)):
                for power,x in coefficients(value).items():
                    lhs,_ = equations.setdefault((component,power),({},ZERO))
                    lhs[column] = x
        resource()
    return labels,equations

def balanced_value(poly,axis,shift=0,imaginary=False):
    parts = [{},{}]
    units = ((1,0),(0,1),(-1,0),(0,-1))
    for power,c in poly.terms():
        if any(p for j,p in enumerate(power) if j!=axis):
            raise ValueError("Expected a univariate domain factor")
        n = power[axis]
        if imaginary:
            for row,sign in zip(parts,units[n%4]):
                row[n] = row.get(n,0)+sign*c
        else:
            for j in range(n+1):
                parts[0][j] = parts[0].get(j,0)+c*comb(n,j)*shift**(n-j)
    return tuple(fmpq_poly([row.get(i,0) for i in range(max(row,default=-1)+1)]) for row in parts)

def positive_roots(poly):
    """Sturm count using the one-sided signs at zero and positive infinity."""
    if not poly:
        raise ValueError("Whole-axis zero has no finite root count")
    poly //= poly.gcd(poly.derivative())
    if poly.degree()<=0:
        return 0
    sturm = [poly,poly.derivative()]
    while sturm[-1]:
        sturm.append(-(sturm[-2]%sturm[-1]))
    def variations(leading):
        signs = []
        for row in sturm[:-1]:
            terms = [c for c in row.coeffs() if c]
            first = terms[-1] if leading else terms[0]
            signs.append(int(first>0))
        return sum(a!=b for a,b in zip(signs,signs[1:]))
    return variations(False)-variations(True)

def no_imag_frequency_roots(poly):
    real,imag = balanced_value(poly,2,imaginary=True)
    return positive_roots(real.gcd(imag))==0

def signed_coefficients(factor,angular_floor):
    real,imag = {},{}
    units = ((1,0),(0,1),(-1,0),(0,-1))
    for powers,value in factor.terms():
        if any(n for index,n in enumerate(powers) if index not in (0,2,9)):
            raise ValueError("Unexpected variable in a domain factor")
        rp,kp,lp = powers[0],powers[2],powers[9]
        a,b = units[kp%4]
        for x in range(rp+1):
            for y in range(lp+1):
                coefficient = value*comb(rp,x)*comb(lp,y)*2**(rp-x)*angular_floor**(lp-y)
                term = (x,kp,y)
                for row,scale in ((real,a),(imag,b)):
                    if scale:
                        row[term] = row.get(term,0)+scale*coefficient
    for name,terms in (("real",real),("imaginary",imag)):
        terms = {p:c for p,c in terms.items() if c}
        if terms and any(p[2]==0 for p in terms):
            if all(x>0 for x in terms.values()) or all(x<0 for x in terms.values()):
                return name
    return None

def factor_certificate(factor):
    axes = {j for j,n in enumerate(factor.degrees()) if n}
    if axes=={9} and factor.degrees()[9]>1:
        # A nonlinear irreducible Q[ell] factor has no integer root.
        parts = factor.factor()[1]
        if len(parts)==1 and parts[0][1]==1:
            return {"irreducible_angular_polynomial_degree":int(factor.degrees()[9]),
                    "domain":"integer ell >= 2"}
    for floor in (2,3,4,5,6,8,12,16):
        sign = signed_coefficients(factor,floor)
        if sign is None:
            continue
        finite = True
        for label in range(2,floor):
            actual = specialize(Q(factor).record(),label)
            if not actual:
                finite = False
                break
            if not signed_coefficients(actual.n,2) and (actual.n.degrees()[0] or
                                                        not no_imag_frequency_roots(actual.n)):
                finite = False
                break
        if finite:
            return {"signed_component":sign,"angular_floor":floor,
                    "fixed_labels":list(range(2,floor))}
    return None

def domain_factors(quantities,numerators=()):
    factors = {}
    for poly in [*(q.d for q in quantities),*(q.n for q in numerators)]:
        if not poly:
            return {"zero_polynomial":None}
        for factor,_ in poly.factor()[1]:
            key = str(factor)
            if key not in factors:
                factors[key] = factor_certificate(factor)
    return factors
