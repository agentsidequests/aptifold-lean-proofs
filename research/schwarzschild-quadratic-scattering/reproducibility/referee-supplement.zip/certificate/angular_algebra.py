"""Exact rational jet algebra; highest-weight angular powers factored."""
from flint import fmpq, fmpq_mpoly, fmpq_mpoly_ctx

CTX = fmpq_mpoly_ctx.get(('r','v','k','E','Ep','M','Mp','J','Jp','ell'),'lex')
GENS = CTX.gens()


def polynomial(x):
    return x if isinstance(x, fmpq_mpoly) else CTX.constant(x)


class Q:
    def __init__(self, n=0, d=1):
        if isinstance(n, Q):
            self.n, self.d = n.n, n.d
            return
        n, d = polynomial(n), polynomial(d)
        if not d:
            raise ZeroDivisionError()
        if not n:
            self.n, self.d = CTX.constant(0), CTX.constant(1)
            return
        common = n.gcd(d)
        n, nr = divmod(n, common)
        d, dr = divmod(d, common)
        if nr or dr:
            raise ArithmeticError('Inexact rational cancellation')
        lead = d.leading_coefficient()
        self.n, self.d = n/lead, d/lead

    def __bool__(self): return bool(self.n)
    def __neg__(self): return Q(-self.n, self.d)
    def __add__(self, y):
        y = Q(y)
        return Q(self.n*y.d+y.n*self.d, self.d*y.d)
    __radd__ = __add__
    def __sub__(self, y): return self+-Q(y)
    def __rsub__(self, y): return Q(y)+-self
    def __mul__(self, y):
        y = Q(y)
        return Q(self.n*y.n, self.d*y.d)
    __rmul__ = __mul__
    def __truediv__(self, y):
        y = Q(y)
        return Q(self.n*y.d, self.d*y.n)
    def __rtruediv__(self, y): return Q(y)/self
    def __pow__(self, n):
        if not isinstance(n, int): raise TypeError('Integer powers required')
        return Q(self.d**(-n), self.n**(-n)) if n < 0 else Q(self.n**n, self.d**n)
    def __eq__(self, y):
        y = Q(y)
        return self.n*y.d == y.n*self.d
    def diff(self, j):
        return Q(self.n.derivative(j)*self.d-self.n*self.d.derivative(j), self.d**2)
    def record(self):
        def terms(p):
            return [[[int(v) for v in powers], str(c)] for powers,c in p.terms()]
        return {'numerator':terms(self.n), 'denominator':terms(self.d)}


r,v,k,E,Ep,M,Mp,J,Jp,ell = map(Q, GENS)
f = 1-2/r
SPHERE = (4/(1+v*v)**2, -4*v*v/(1+v*v)**2)


def decode(obj):
    return Q(*(CTX.from_dict({tuple(p):fmpq(c) for p,c in obj[name]}) for name in ('numerator','denominator')))


def replace(x, values):
    x = Q(x)
    def evaluate(p):
        total = Q(0)
        for powers,c in p.terms():
            term = Q(c)
            for j,n in enumerate(powers):
                if n: term *= Q(values[j])**int(n)
            total += term
        return total
    return evaluate(x.n)/evaluate(x.d)


def angular_derivative(x, label):
    """Angular derivative after dividing out the highest-weight harmonic."""
    logarithmic = (1-v*v)/(v*(1+v*v))
    return Q(x).diff(1) + label*logarithmic*x


def potential(label):
    lam = Q((label-1)*(label+2))/2
    gamma = lam*(lam+1)/3
    W = gamma+3*f/(r*(lam*r+3))
    even = 2*f*(lam*lam*(lam+1)*r**3+3*lam*lam*r*r+9*lam*r+9)/(r**3*(lam*r+3)**2)
    odd = f*(label*(label+1)/r**2-6/r**3)
    return lam, gamma, W, even, odd


class Frame:
    def __init__(self, parent=3, even_source=0, odd_source=0):
        self.parent = parent
        self.even_source, self.odd_source = Q(even_source), Q(odd_source)
        self.ve = potential(parent)[3]
        self.vde, self.vdo = potential(2*parent)[3:]
    def d(self, x):
        x = Q(x)
        epp = (k*k+self.ve)*E/f**2-f.diff(0)*Ep/f
        mpp = ((4*k*k+self.vde)*M+self.even_source)/f**2-f.diff(0)*Mp/f
        jpp = ((4*k*k+self.vdo)*J+self.odd_source)/f**2-f.diff(0)*Jp/f
        return x.diff(0)+Ep*x.diff(3)+epp*x.diff(4)+Mp*x.diff(5)+mpp*x.diff(6)+Jp*x.diff(7)+jpp*x.diff(8)
    def partial(self, x, axis, order):
        x = Q(x)
        if axis == 0: return -order*k*x
        if axis == 1: return self.d(x)
        if axis == 2: return angular_derivative(x, order*self.parent)
        return order*self.parent*x
    def wave(self, x, label, frequency, parity):
        V = potential(label)[3 if parity == 'E' else 4]
        return f*self.d(f*self.d(x))-(frequency*frequency+V)*x


def quadratic(x):
    x = Q(x)
    if any(any(p[j] for j in range(3,9)) for p,c in x.d.terms()):
        raise ValueError('Field-free denominator required')
    groups = {(2,0):{}, (1,1):{}, (0,2):{}}
    for powers,c in x.n.terms():
        key = int(powers[3]), int(powers[4])
        if key not in groups or any(powers[j] for j in range(5,9)):
            raise ValueError('Quadratic parent jets only')
        p = tuple(int(a) if j<3 or j==9 else 0 for j,a in enumerate(powers))
        groups[key][p] = c
    return [Q(CTX.from_dict(groups[key]),x.d) for key in ((2,0),(1,1),(0,2))]
