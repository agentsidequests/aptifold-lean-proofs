"""Check the two particular solutions and the exclusion of any third solution."""

import argparse
from fractions import Fraction
import json
from pathlib import Path

from angular_algebra import CTX, Q, decode, ell, k
from proof_core import action, domain_factors, laurent_system


ROOT = Path(__file__).resolve().parent
ZERO = Q(0)
PRIME = 65_537
I_MOD_PRIME = 256


def data(name):
    return json.loads((ROOT / "data" / (name + ".json")).read_text(encoding="utf-8"))


def gamma(angular):
    return (angular - 1) * angular * (angular + 1) * (angular + 2) / 12


def require(condition, label):
    if not condition:
        raise ValueError(label)


def admit(quantities, numerators=()):
    certificates = domain_factors(quantities, numerators)
    require(all(certificates.values()), "Nonvanishing certificate failed")
    return certificates


def certify():
    assembly = data("assembly")
    solutions = data("particulars")
    first = data("first-particular")
    odd = data("odd-poles")
    saved = data("obstruction")

    g, cap = gamma(ell), gamma(2 * ell) / 2
    rho = decode(assembly["rho"])
    expected_rho = (cap + g) * (g - k) / ((cap - g) * (g + k))
    require(rho == expected_rho == decode(solutions["rho"]), "Second mixture ratio")
    primitive = list(map(decode, first["primitive"]))
    partial = list(map(decode, first["pole_part"]))
    remaining = tuple(map(decode, first["remaining_source"]))
    require(action([full - pole for full, pole in zip(primitive, partial)]) == remaining,
            "First mixture residual after pole terms")
    difference = list(map(decode, solutions["difference"]))
    delta = tuple(map(decode, assembly["delta_source_rescaled"]))
    require(action(difference) == delta, "Difference primitive")
    second = list(map(decode, solutions["second_primitive"]))
    require(second == [first_piece + (rho - 1) * shift
                       for first_piece, shift in zip(primitive, difference)], "Second primitive")
    require(action(second) == tuple(x + (rho - 1) * y for x, y in zip(action(primitive), delta)),
            "Projected source at the second mixture")

    pure_odd = tuple(map(decode, assembly["oo_source_rescaled"]))
    without_poles = tuple(map(decode, odd["remaining_source"]))
    removed = action(tuple(map(decode, odd["removed_nonzero_radius_poles"])))
    require(tuple(x - y for x, y in zip(pure_odd, removed)) == without_poles,
            "Odd source pole subtraction")
    labels, equations = laurent_system(without_poles, lambda: None)
    require(len(labels) == saved["columns"] == 30 and len(equations) == saved["rows"] == 41,
            "Laurent matrix shape")
    require([list(key) for key in equations] == saved["equation_labels"], "Equation ordering")

    rows = [[lhs.get(i, ZERO) for i in range(len(labels))] + [rhs] for lhs, rhs in equations.values()]
    witness = {int(i): decode(value) for i, value in saved["witness"].items()}
    require(all(value.d == CTX.constant(1) and not value.n.degrees()[0] for value in witness.values()),
            "Witness polynomial structure")
    projected = [sum((weight * rows[i][j] for i, weight in witness.items()), ZERO)
                 for j in range(len(labels) + 1)]
    require(not any(projected[:-1]), "Exact operator-column annihilation")
    target = projected[-1]
    require(target and target == decode(saved["pure_odd_obstruction"]), "Exact nonzero odd-source projection")
    obstruction_factors = admit([target], [target])
    require(obstruction_factors == saved["obstruction_factor_certificates"],
            "Saved factor certificates")
    regularity_factors = admit([rho, *second, *pure_odd, *delta, *without_poles], [rho - 1])
    return labels, list(equations), rows, witness, {
        "first_mixture": "exact projected identity",
        "second_mixture": "exact difference identity",
        "matrix": [len(rows), len(labels)],
        "zero_operator_projections": len(labels),
        "odd_source": "nonzero on the stated domain",
        "obstruction_factors_checked": len(obstruction_factors),
        "regularity_factors_checked": len(regularity_factors),
    }


def finite_field_value(value, angular, parent_frequency):
    """Reduce a rational value of ell and k=i*w to the 65,537-element field."""
    k_value = I_MOD_PRIME * parent_frequency.numerator * pow(parent_frequency.denominator, -1, PRIME)

    def component(expression):
        total = 0
        for powers, coeff in expression.terms():
            require(not any(exponent for index, exponent in enumerate(powers) if index not in (2, 9)),
                    "Unexpected axis after collecting Laurent coefficients")
            scaled = int(coeff.numerator) * pow(int(coeff.denominator), -1, PRIME)
            total += scaled * pow(k_value, powers[2], PRIME) * pow(angular, powers[9], PRIME)
        return total % PRIME

    return int(component(value.n) * pow(component(value.d), -1, PRIME) % PRIME)


def browser_frames(path, labels, equations, rows, witness):
    frames = []
    for angular in (2, 4, 5):
        for frequency in (Fraction(1, 2048), Fraction(3, 8)):
            weighted = [finite_field_value(witness.get(i, ZERO), angular, frequency) for i in range(len(rows))]
            entries = [[finite_field_value(value, angular, frequency) for value in row] for row in rows]
            dot = [sum(weighted[i] * row[j] for i, row in enumerate(entries)) % PRIME
                   for j in range(len(labels) + 1)]
            require(not any(dot[:-1]) and dot[-1], "Unusable finite-field browser frame")
            frames.append({"ell": angular, "frequency": str(frequency), "witness": weighted, "rows": entries})
    result = {"prime": PRIME, "imaginaryUnit": I_MOD_PRIME,
              "columns": [list(map(int, pair)) for pair in labels], "equations": [list(map(int, pair)) for pair in equations],
              "frames": frames}
    path.write_text("export const proofSamples = " + json.dumps(result, separators=(",", ":")) + ";\n",
                    encoding="utf-8", newline="\n")
    return len(frames)


if __name__ == "__main__":
    parse = argparse.ArgumentParser(description=__doc__)
    parse.add_argument("--browser-frames", type=Path, help="Generate the six browser verification examples.")
    args = parse.parse_args()
    labels, equations, rows, witness, report = certify()
    if args.browser_frames:
        report["browser_frames"] = browser_frames(args.browser_frames, labels, equations, rows, witness)
    print(json.dumps(report, indent=2))
