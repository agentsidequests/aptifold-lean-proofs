"""Replay the shifted-polynomial proof in the manuscript using the public algebra archive."""
import json
from pathlib import Path
import sys

from flint import fmpq_poly

if len(sys.argv) != 2:
    raise SystemExit("Usage: python -B check-witness-domain.py PATH_TO_EXTRACTED_GW_REPLAY")

archive = Path(sys.argv[1]).resolve(strict=True)
sys.path.insert(0, str(archive))
from angular_algebra import Q, decode, ell, k
from prove import certify, data, gamma, require

# The public verifier rebuilds the operator, applies the witness, and
# checks that its result equals the stored exact source projection.
_, _, _, _, replay = certify()
target = decode(data("obstruction")["pure_odd_obstruction"])
require(Q(target.d) == k - gamma(2 * ell) / 2, "Expected the normalized denominator k - Gamma.")
degrees = target.n.degrees()
require(len(degrees) == 10 and degrees[9] == 65, "Expected angular degree 65.")
require(all(degree == 0 for i, degree in enumerate(degrees) if i not in (2, 9)),
        "Unexpected variable in the projection.")

coefficients = [0] * 66
for powers, coefficient in target.n.terms():
    require(powers[2] == 6, "Expected the common factor k**6.")
    coefficients[powers[9]] = coefficient

angular = fmpq_poly(coefficients)
shift = fmpq_poly([18, 1])
shifted = fmpq_poly()
for coefficient in reversed(coefficients):
    shifted = shifted * shift + coefficient

require(shifted[0] > 0 and all(coefficient >= 0 for coefficient in shifted.coeffs()),
        "A(18 + t) did not have the required coefficient signs.")
labels = list(range(2, 18))
require(all(angular(label) != 0 for label in labels), "A physical integer label is a root.")
print(json.dumps({
    "matrix": replay["matrix"],
    "zero_operator_projections": replay["zero_operator_projections"],
    "angular_degree": int(angular.degree()),
    "frequency_power": 6,
    "finite_labels_checked": labels,
    "positive_shift_from_ell": 18,
    "state": "PASS",
}, indent=2))