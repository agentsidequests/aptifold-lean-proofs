"""Independent real-frequency linear scattering check for the strain benchmark.

Run with Python-FLINT 0.9.0. This solver reads no existing amplitudes.
It uses polynomial ODE recurrences at the two endpoints and extrapolated
modified midpoint propagation in areal radius. Midpoints are propagated
at 192-bit precision. Refinement and flux checks test numerical accuracy.
The output is a convergence check, without a rigorous truncation enclosure.
"""

import argparse
from dataclasses import dataclass
from fractions import Fraction
import json

from flint import acb, acb_poly, arb, ctx


@dataclass(frozen=True)
class Resolution:
    horizon_offset: Fraction
    radius: int
    max_step: Fraction
    levels: int
    horizon_order: int
    far_order: int


RESOLUTIONS = {
    "coarse": Resolution(Fraction(1, 64), 80, Fraction(1, 4), 6, 18, 22),
    "fine": Resolution(Fraction(1, 96), 112, Fraction(1, 8), 7, 24, 32),
    "refined": Resolution(Fraction(1, 128), 160, Fraction(1, 16), 7, 30, 42),
}


def coordinate(r):
    return r + 2 * (r / 2 - 1).log()


def series(a, b, c, order):
    """Power series with P(0)=1 for aP''+bP'+cP=0 and a(0)=0."""
    if not a[0].is_zero():
        raise ArithmeticError("Unexpected nonzero second derivative at the expansion endpoint.")
    coefficients = [acb(1)]
    for power in range(order):
        second = sum(
            a[j] * (power - j + 1) * (power - j + 2) * coefficients[power - j + 2]
            for j in range(2, min(len(a), power + 1))
        )
        first = sum(
            b[j] * (power - j + 1) * coefficients[power - j + 1]
            for j in range(1, min(len(b), power + 1))
        )
        zeroth = sum(
            c[j] * coefficients[power - j]
            for j in range(min(len(c), power + 1))
        )
        leading = (power + 1) * (a[1] * power + b[0])
        coefficients.append(-(second + first + zeroth) / leading)
    return acb_poly(coefficients)


@dataclass(frozen=True)
class Wave:
    label: int
    rate: Fraction
    parity: str

    @property
    def angular(self):
        return self.label * (self.label + 1)

    @property
    def lam(self):
        return (self.angular - 2) // 2

    def geometric_source(self, r):
        """V/f for the real Regge-Wheeler or Zerilli potential."""
        if self.parity == "free":
            return arb(0)
        if self.parity == "odd":
            return (self.angular * r - 6) / r**3
        lam = self.lam
        numerator = lam**2 * (lam + 1) * r**3 + 3 * lam**2 * r**2 + 9 * lam * r + 9
        return 2 * numerator / (r**3 * (lam * r + 3)**2)

    def horizon_series(self, k, order):
        s = acb_poly([0, 1])
        r = 2 + s
        a = s * r**2
        b = 2 * r - 2 * k * r**3
        if self.parity == "even":
            lam = self.lam
            denominator = (lam * r + 3)**2
            c = -2 * (lam**2 * (lam + 1) * r**3 + 3 * lam**2 * r**2 + 9 * lam * r + 9)
            return series(a * denominator, b * denominator, c, order)
        c = acb_poly() if self.parity == "free" else 6 - self.angular * r
        return series(a, b, c, order)

    def infinity_series(self, signed_k, order):
        t = acb_poly([0, 1])
        a = t**2 * (1 - 2 * t)
        b = 2 * t - 6 * t**2 - 2 * signed_k
        if self.parity == "even":
            lam = self.lam
            denominator = (lam + 3 * t)**2
            c = -2 * (lam**2 * (lam + 1) + 3 * lam**2 * t + 9 * lam * t**2 + 9 * t**3)
            return series(a * denominator, b * denominator, c, order)
        c = acb_poly() if self.parity == "free" else 6 * t - self.angular
        return series(a, b, c, order)


def midpoint(rhs, r, step, y, z, subdivisions):
    step = step / subdivisions
    first, second = rhs(r)
    old_y, old_z = y, z
    y, z = y + step * first * z, z + step * second * y
    for i in range(1, subdivisions):
        first, second = rhs(r + i * step)
        old_y, y = y, old_y + 2 * step * first * z
        old_z, z = z, old_z + 2 * step * second * old_y
    first, second = rhs(r + subdivisions * step)
    return (old_y + y + step * first * z) / 2, (old_z + z + step * second * y) / 2


def extrapolated_step(rhs, r, h, y, z, levels):
    previous = []
    for n in range(2, 2 * levels + 1, 2):
        row = [midpoint(rhs, r, h, y, z, n)]
        for j in range(1, len(previous) + 1):
            now_y, now_z = row[-1]
            less_y, less_z = previous[j - 1]
            count = n - 2 * j
            denominator = n * n - count * count
            row.append(((n*n*now_y - count*count*less_y) / denominator,
                        (n*n*now_z - count*count*less_z) / denominator))
        previous = row
    value, slope = previous[-1]
    return value.mid(), slope.mid()


def components(z):
    return {"real": z.real.mid().str(44, radius=False), "imag": z.imag.mid().str(44, radius=False)}


def solve(wave, settings):
    nu = arb(str(wave.rate))
    k = acb(0, nu)
    s = arb(str(settings.horizon_offset))
    r = 2 + s
    seed = wave.horizon_series(k, settings.horizon_order)
    carrier = (-k * coordinate(r)).exp()
    initial = seed(s)
    y = carrier * initial
    z = carrier * ((1 - 2/r) * seed.derivative()(s) - k * initial)

    def rhs(radius):
        invf = radius / (radius - 2)
        return invf, wave.geometric_source(radius) - nu*nu*invf

    position = Fraction(2) + settings.horizon_offset
    steps = 0
    while position < settings.radius:
        h = min(settings.max_step, (position - 2) / 8, settings.radius - position)
        y, z = extrapolated_step(rhs, arb(str(position)), arb(str(h)), y, z, settings.levels)
        position += h
        steps += 1

    r = arb(settings.radius)
    t = 1 / r
    f = 1 - 2*t

    def basis(sign):
        expansion = wave.infinity_series(sign * k, settings.far_order)
        amplitude = expansion(t)
        phase = (sign * k * coordinate(r)).exp()
        return phase * amplitude, phase * (sign * k * amplitude - f * t*t * expansion.derivative()(t))

    incoming, incoming_slope = basis(-1)
    outgoing, outgoing_slope = basis(1)
    determinant = incoming * outgoing_slope - outgoing * incoming_slope
    ain = (y * outgoing_slope - z * outgoing) / determinant
    aout = (z * incoming - y * incoming_slope) / determinant
    flux_error = abs((y.conjugate() * z).imag / nu + 1)
    return {
        "reflection": components(aout/ain), "flux_defect": flux_error.mid().str(20, radius=False),
        "macro_steps": steps,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("resolution", choices=RESOLUTIONS)
    args = parser.parse_args()
    ctx.prec = 192
    settings = RESOLUTIONS[args.resolution]
    cases = {
        "even_parent": Wave(4, Fraction(1, 2), "even"),
        "odd_daughter": Wave(8, Fraction(1), "odd"),
    }
    if args.resolution == "coarse":
        cases["odd_parent_control"] = Wave(4, Fraction(1, 2), "odd")
        cases["free_wave_control"] = Wave(4, Fraction(1, 2), "free")
    print(json.dumps({
        "resolution": args.resolution, "arithmetic_bits": ctx.prec,
        "parameters": {name: str(value) for name, value in vars(settings).items()},
        "waves": {name: solve(wave, settings) for name, wave in cases.items()},
    }, indent=2))


if __name__ == "__main__":
    main()
