"""Check the manuscript's complex-strain bounds against the referee inputs."""

from fractions import Fraction
import argparse
import json
from pathlib import Path
import re

from flint import acb, arb, ctx

from verify_linear_reflections import closed_strain, gamma, interval, reflection


def printed_bounds(source):
    text = source.read_text(encoding="utf-8")
    last = text.index(r"\label{tab:bench}")
    table = text[text.rindex(r"\begin{table}", 0, last):last]
    pattern = (
        r"(?m)^\s*\\\((\d+)\\\)&\\\(([\d/]+)\\\)&([12])&[^\n]+?&"
        r"\\\(([\d.]+)\\times10\^\{(-\d+)\}\\\)\\\\"
    )
    rows = re.findall(pattern, table)
    limits = {
        (int(label), Fraction(frequency), int(mixture)): arb(mantissa + "e" + exponent)
        for label, frequency, mixture, mantissa, exponent in rows
    }
    if len(limits) != len(rows):
        raise ValueError("Table 1 has a duplicate benchmark row.")
    return limits


def body(path):
    record = json.loads(path.read_bytes())
    if record.get("state") != "PASS":
        raise ValueError(f"Unaccepted benchmark data at {path.name}.")
    return record["body"]


def published_comparisons(bundle, study, radial):
    for mixture, keys in enumerate((("value", "prediction"), ("Q_direct", "Q_prediction")), 1):
        data = body(bundle / "benchmarks" / f"ell2-mixture-{mixture}.json")
        yield (2, Fraction(3, 8), mixture), interval(data[keys[0]]), interval(data[keys[1]])

    member = study / "ell3-independent-20261116"
    parent = interval(body(member/"numerical-qualification/wave-E3-fine/RESULT.json")["values"]["reflection"])
    daughter = interval(body(member/"linear-recovery/wave-fine/RESULT.json")["values"]["reflection"])
    reference = study / "ell3-second-mixture-integration-20261117"
    first = body(reference/"comparison/compare-A/RESULT.json")["legacy_first_mixture_corrected"]["fine"]["value"]
    second = body(reference/"admit-A/RESULT.json")["values"]["fine"]["value"]
    for mixture, direct in enumerate((first, second), 1):
        frequency = Fraction(1, 4)
        yield (3, frequency, mixture), interval(direct), closed_strain(3, frequency, mixture, parent, daughter)

    record = json.loads((radial / "DIRECT-fine.json").read_bytes())
    frequency = Fraction(1, 2)
    k = acb(0, arb(str(frequency)))
    g = gamma(4)
    parent = (g + k)/(g - k)*reflection(record, 4)
    daughter = reflection(record, 8)
    yield (4, frequency, 2), interval(record["strain"]), closed_strain(4, frequency, 2, parent, daughter)


def verify(paper, bundle, study, radial):
    ctx.prec = 512
    limits = printed_bounds(paper)
    results = {}
    found = set()
    for mode, direct, prediction in published_comparisons(bundle, study, radial):
        label, frequency, mixture = mode
        name = f"ell={label}, Momega={frequency}, mixture={mixture}"
        difference = (direct - prediction).abs_upper()
        if mode not in limits:
            raise ValueError(f"Missing Table 1 row: {name}.")
        limit = limits[mode]
        if not (direct.overlaps(prediction) and difference < limit):
            raise ArithmeticError(
                f"Table 1 bound failed for {name}: exported difference {difference.str(10)},"
                f" printed bound {limit.str(10)}."
            )
        results[name] = {"exported_difference_upper": difference.str(18),
                         "printed_bound": limit.str(18)}
        found.add(mode)
    if set(limits) != found:
        raise ValueError("A printed Table 1 row lacks an archived comparison.")
    return {"state": "PASS", "rows": results}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    for argument in ("manuscript", "bundle", "scattering", "radial_archive"):
        parser.add_argument(argument, type=Path)
    args = parser.parse_args()
    print(json.dumps(verify(args.manuscript, args.bundle, args.scattering, args.radial_archive), indent=2))
