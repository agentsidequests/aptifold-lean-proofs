"""Recompute both linear reflection inputs for the near-cancellation case."""

from fractions import Fraction
import argparse
import json
from math import factorial
from pathlib import Path
import subprocess
import sys

from flint import acb, arb, ctx


def interval(record):
    return acb(arb(record["real"]), arb(record["imag"]))


def reflection(linear_record, label):
    wave = linear_record["linear"][str(label)]
    return interval(wave["A_out"]) / interval(wave["A_in"])


def gamma(label):
    return arb((label - 1) * label * (label + 1) * (label + 2)) / 12


def closed_strain(label, frequency, mixture, parent, daughter):
    """The two normalized closed formulas, with the declared phase origin."""
    k = acb(0, arb(str(frequency)))
    g = gamma(label)
    daughter_gamma = gamma(2 * label) / 2
    polynomial = 20*label**3 + 35*label**2 + label - 8
    normalization = (
        arb(factorial(2 * label + 1) * polynomial)
        / (144 * factorial(label - 1) * factorial(label - 2))
        * (arb(factorial(2 * label + 2) * factorial(2 * label - 2))
           / (arb.pi() * factorial(4 * label + 1))).sqrt()
    )
    if mixture == 1:
        return normalization * k*k / (4*g*g*(k - daughter_gamma)) * daughter
    if mixture == 2:
        return normalization / (4 * daughter_gamma) * (
            k * (k - g*g/daughter_gamma) / (k + g)**2 * parent**2
            + k / (k - daughter_gamma) * daughter
        )
    raise ValueError("Unknown parity mixture.")


def compute(name):
    source = Path(__file__).with_name("solve-linear.py")
    result = subprocess.run(
        [sys.executable, "-B", str(source), name],
        check=True, capture_output=True, text=True, encoding="utf-8",
    )
    return json.loads(result.stdout)


def verify(radial):
    ctx.prec = 512
    reference = json.loads((radial / "DIRECT-fine.json").read_bytes())
    records = {name: compute(name) for name in ("coarse", "fine", "refined")}
    solved = {
        level: {name: interval(data["reflection"]) for name, data in record["waves"].items()}
        for level, record in records.items()
    }
    k = acb(0, arb("1/2"))
    alpha = (gamma(4) + k) / (gamma(4) - k)
    archived = {"even_parent": alpha*reflection(reference, 4),
                "odd_daughter": reflection(reference, 8)}
    differences = {}
    refined = solved["refined"]
    for name, conventional in archived.items():
        error = (refined[name] - conventional).abs_upper()
        change = (refined[name] - solved["fine"][name]).abs_upper()
        earlier = (solved["fine"][name] - solved["coarse"][name]).abs_upper()
        flux = arb(records["refined"]["waves"][name]["flux_defect"])
        if not (error < arb("2e-13") and change < arb("2e-13") and change < earlier and flux < arb("1e-10")):
            raise ArithmeticError(f"Unexpected reflection, refinement or wave-current error for {name}.")
        differences[name] = {
            "distance_to_archived_enclosure_upper": error.str(20),
            "last_refinement_change": change.str(20),
            "previous_refinement_change": earlier.str(20),
            "flux_defect": flux.str(20),
        }

    free = abs(solved["coarse"]["free_wave_control"])
    parity = (solved["coarse"]["odd_parent_control"] - archived["even_parent"]).abs_lower()
    shifted = refined["odd_daughter"] * acb(0, -2).exp()
    phase = (shifted - archived["odd_daughter"]).abs_lower()
    if not (free < arb("2e-13") and parity > arb("1e-3") and phase > arb("1e-3")):
        raise ArithmeticError("A linear scattering control did not discriminate.")

    frequency = Fraction(1, 2)
    independent_strain = closed_strain(4, frequency, 2, refined["even_parent"], refined["odd_daughter"])
    reference_strain = closed_strain(4, frequency, 2, archived["even_parent"], archived["odd_daughter"])
    physical_difference = (independent_strain - interval(reference["strain"])).abs_upper()
    if not physical_difference < arb("1e-14"):
        raise ArithmeticError("The independent linear inputs disagree with the direct strain benchmark.")
    return {
        "state": "PASS",
        "interpretation": "convergence check with independent linear propagation, without a truncation enclosure",
        "reflection_comparisons": differences,
        "wrong_parent_parity_distance_lower": parity.str(20),
        "shifted_origin_distance_lower": phase.str(20),
        "free_reflection": free.str(20),
        "closed_with_fresh_linear_inputs": {"real": independent_strain.real.str(32),
                                             "imag": independent_strain.imag.str(32)},
        "strain_shift_upper": (independent_strain - reference_strain).abs_upper().str(20),
        "distance_to_saved_direct_enclosure_upper": physical_difference.str(20),
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("radial_archive", type=Path)
    print(json.dumps(verify(parser.parse_args().radial_archive), indent=2))

