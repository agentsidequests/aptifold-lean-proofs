"""Verify both rational local mixtures against the full published source."""

import argparse
import json
from pathlib import Path
import re
import sys

HERE = Path(__file__).resolve().parent
sys.path[:0] = [
    str(HERE.parent / "published-ooe-comparison-20261123"),
    str(HERE.parent / "published-eoo-comparison-20261123"),
]
from compare import (
    MatchedSource, Radicals, angular_controls, compare_odd_odd, highest_weight_inputs,
    require, translate as translate_odd_odd, translate_sections,
)
from compare_mixed import (
    DIFFERENCE_SHA, admitted_body, compare_even_odd, normalize, pinned_bytes, rescale,
    substitute_even_jets,
)
from angular_algebra import CTX, E, Ep, Frame, Q, decode, ell, f, k, potential, r
from verify import verify_denominators

SCATTERING = HERE.parents[1]
PUBLISHED = "jl/generated/SourceEEE.jl"
SOURCE_SHA = "f3e87b816478b8a540a6caf3668fb827cd205917623ff62be4f462c409045327"
FIRST_SHA = "f02c739928869c93aba8cec067db8e8ab1c999e06f6f17bc776e9e1cebf7c16b"
ZERO = Q(0)


def reader_control(text):
    wanted = translate_odd_odd(text)
    limited = translate_sections(
        text.splitlines(), highest_weight_inputs(E, Ep), coefficient_return=403,
        closure=429, source_header=432, expected_counts=(399, 339),
        retain_source=("_t33",),
    )
    require(all(a.terms == b.terms for a, b in zip(wanted[:3], limited[:3], strict=True)),
            "Releasing temporaries changed an odd-odd return summand.")
    require(wanted[3].keys() == limited[3].keys()
            and all(a.terms == limited[3][n].terms for n, a in wanted[3].items()),
            "Releasing temporaries changed a returned coefficient.")
    require(wanted[4]["_t33"].terms == limited[4]["_t33"].terms,
            "Releasing temporaries changed the retained regulator.")


def translate(text):
    lines = text.splitlines()
    require(
        len(lines) == 60730 and lines[2].startswith("function coefficients_eee(")
        and lines[59321].strip().startswith("zq=") and lines[59322] == "end"
        and lines[59324].startswith("function source_eee(") and lines[-1] == "end",
        "Pinned even-even layout changed.",
    )
    require(
        [j for j, line in enumerate(lines) if re.search(r"\bpi\b", line)] == [4, 59366]
        and [j for j, line in enumerate(lines) if "θ" in line] == [59366],
        "Pi appears outside the angular factor and the unused theta assignment.",
    )
    return translate_sections(
        lines, highest_weight_inputs(E, Ep), coefficient_return=59286, closure=59321,
        source_header=59324, expected_counts=(59282, 1403), retain_source=("_t39",),
    )


def compare_even_even(archive, even_frame, odd_frame):
    text = pinned_bytes(archive / PUBLISHED, SOURCE_SHA).decode("utf-8")
    angular = angular_controls(((1, 0),))
    complete, left, right, fields, values = translate(text)
    products = (E**2, f*Ep*E, E*f*Ep, (f*Ep)**2)
    logs = tuple(fields[f"clog_{j}"].rational() for j in range(1, 5))
    require(sum((a*b for a, b in zip(logs, products, strict=True)), ZERO) == ZERO,
            "A logarithmic part survives on the identical-parent family.")
    powers = (("m2", -2), ("m1", -1), ("0", 0), ("1", 1), ("2", 2), ("3", 3))
    coefficients = (
        sum((fields[f"c_{j}_{name}"] * Radicals(r**power) for name, power in powers), Radicals())
        for j in range(1, 5)
    )
    regulator = normalize(sum(
        (a*Radicals(b) for a, b in zip(coefficients, products, strict=True)), Radicals()
    ))
    require(regulator == normalize(values["_t39"]), "Even-even regulator temporary differs.")
    even_image = normalize(left)
    daughter = 2*ell
    require(even_image == even_frame.wave(regulator, daughter, 2*k, "E"),
            "The literal left summand is not the even operator acting on the regulator.")
    bare, regulated = normalize(right), normalize(complete)
    require(regulated == bare+even_image, "The complete source return did not recompose.")

    _, g, w, _, _ = potential(ell)
    _, gamma, wd, _, _ = potential(daughter)
    reference_even = (w*E+f*Ep)/(g+k)
    even_prime = odd_frame.d(reference_even)
    require(odd_frame.wave(reference_even, ell, k, "E") == ZERO,
            "The converted parent does not solve the even wave equation.")

    def project(q):
        # The two even inputs carry no rephasing. The same-mode source
        # receives the identical-parent half before the daughter map.
        mapped = (wd*q-f*even_frame.d(q))/(2*(gamma-2*k))
        return substitute_even_jets(mapped, reference_even, even_prime)

    bare, regulated, correction = map(project, (bare, regulated, regulator))
    require(regulated-bare == odd_frame.wave(correction, daughter, 2*k, "O"),
            "The projected even-even shift is not a local operator image.")
    require(bool(regulated-bare), "Omitting the even-even regulator escaped the check.")
    return MatchedSource(bare, regulated, correction, {
        "published_file_sha256": SOURCE_SHA,
        "coefficient_assignments": 59282,
        "source_assignments": 1403,
        "angular_controls": angular,
        "literal_regularizer_and_projected_image_verified": True,
        "self_log_shift_zero": True,
    })


def from_primitive(record):
    coefficients = tuple(map(decode, record))
    z = r*r*f*Ep
    return sum((a*b for a, b in zip(coefficients, (E**2, E*z, z*z), strict=True)), ZERO)


def at_horizon(q):
    def evaluate(poly):
        terms = {}
        for (radial, *other), coefficient in poly.terms():
            key = (0, *other)
            terms[key] = terms.get(key, 0) + coefficient*2**int(radial)
        return CTX.from_dict(terms)

    denominator = evaluate(q.d)
    require(bool(denominator), "The candidate has a horizon pole above the simple-pole bound.")
    # Check the evaluated denominator before cancelling with the
    # numerator, so an exceptional parameter cannot hide a pole.
    verify_denominators((Q(1, denominator),))
    return Q(evaluate(q.n), denominator)


def verify_horizon(q):
    # For the ingoing parent, Z/J tends to -4k at r=2. Multiplying by
    # r-2 first checks the pole ceiling and computes the possible residue.
    a, b, c = (at_horizon((r-2)*coefficient) for coefficient in rescale(q))
    require(a-4*k*b+16*k*k*c == ZERO, "A local candidate has an ingoing horizon residue.")


def check_mixtures(archive):
    """Return the checked regularized local fields with their mixture ratios."""
    reader_control(pinned_bytes(
        archive / "jl/generated/SourceOOE.jl",
        "9a987827b091d6f26e11e72b376883ebf07dc64e605f345258dc84a8d5365bd5",
    ).decode("utf-8"))
    odd_odd = compare_odd_odd(archive)
    mixed = compare_even_odd(archive)
    even_frame, odd_frame = Frame(ell), Frame(ell)
    odd_frame.ve = potential(ell)[4]
    even_even = compare_even_even(archive, even_frame, odd_frame)
    daughter = 2*ell

    first = admitted_body(
        SCATTERING / "native-family-20261117/symbolic-primitive/laurent-A/RESULT.json", FIRST_SHA
    )
    difference = admitted_body(HERE.parent / "general/rational/solve-A/RESULT.json", DIFFERENCE_SHA)
    first_primitive = from_primitive(first["primitive"])
    difference_primitive = from_primitive(difference["difference"])
    rho2 = decode(difference["rho"])
    g = potential(ell)[1]
    gamma_half = potential(daughter)[1]/2
    require(rho2 == (gamma_half+g)*(g-k)/((gamma_half-g)*(g+k)),
            "The second mixture ratio differs from the claimed value.")
    require(odd_frame.wave(first_primitive, daughter, 2*k, "O")
            == even_even.bare+mixed.bare+odd_odd.bare,
            "The first mixture fails on the complete published bare source.")
    require(odd_frame.wave(difference_primitive, daughter, 2*k, "O")
            == mixed.bare+(1+rho2)*odd_odd.bare,
            "The published bare source difference fails.")

    candidates = []
    for rho in (Q(1), rho2):
        source = even_even.regularized+rho*mixed.regularized+rho*rho*odd_odd.regularized
        field = first_primitive+(rho-1)*difference_primitive
        field += even_even.correction+rho*mixed.correction+rho*rho*odd_odd.correction
        require(odd_frame.wave(field, daughter, 2*k, "O") == source,
                "A candidate fails on the complete published regularized source.")
        verify_horizon(field)
        candidates.append(field)
    require(bool(even_even.bare) and odd_frame.wave(first_primitive, daughter, 2*k, "O")
            != 2*even_even.bare+mixed.bare+odd_odd.bare,
            "Incorrect even-even half escaped the assembled identity.")
    factors = verify_denominators((
        1/(rho2-1), rho2, *rescale(candidates[0]), *rescale(candidates[1]),
        *rescale(even_even.bare), *rescale(even_even.correction),
    ))
    report = {
        "symbolic_variables": ["r", "ell", "k"],
        "even_even": even_even.report,
        "even_odd": mixed.report,
        "odd_odd": odd_odd.report,
        "bounded_reader_control": True,
        "first_mixture_complete_bare_identity": True,
        "paired_bare_difference_identity": True,
        "both_complete_regularized_identities": True,
        "both_regular_on_ingoing_horizon": True,
        "certified_denominator_factors_in_closure": factors,
    }
    return tuple(zip((Q(1), rho2), candidates, strict=True)), report


def verify(archive):
    return check_mixtures(archive)[1]


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("archive", type=Path, help="Read-only pinned author-source directory")
    args = parser.parse_args()
    print(json.dumps(verify(args.archive), indent=2))
