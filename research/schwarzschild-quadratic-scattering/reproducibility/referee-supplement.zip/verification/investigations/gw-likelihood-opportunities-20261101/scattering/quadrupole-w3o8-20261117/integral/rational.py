"""Exact specialization at the frozen parent frequency; factored rational complex-disk bounds."""
import math
from fractions import Fraction as Q
from flint import arb,acb,acb_series,fmpq,fmpq_poly
from bridge import a,z,GQ,DATA

def zero(v):return not v.r and not v.i
def polynomial(co,x):
    out=x*0
    for v in reversed(co):out=out*x+z(v)
    return out
def shifted(co,center):
    return [sum((v*GQ(math.comb(j,k)*center**(j-k)) for j,v in enumerate(co) if j>=k),GQ()) for k in range(len(co))]
def mul(left,right,N):
    return [sum((left[j]*right[n-j] for j in range(max(0,n-len(right)+1),min(n+1,len(left)))),GQ()) for n in range(N+1)]
def exact_poly(co,part):return fmpq_poly([fmpq(str(getattr(v,part))) for v in co])

class Ratio:
    def __init__(self,n,d):
        nr,ni,dr,di=*(exact_poly(n,p) for p in ('r','i')),*(exact_poly(d,p) for p in ('r','i'))
        den=dr*dr+di*di
        if not den:raise ZeroDivisionError('Zero rational denominator')
        re,im=nr*dr+ni*di,ni*dr-nr*di
        gcd=den.gcd(re).gcd(im)
        den,re,im=den//gcd,re//gcd,im//gcd
        self.n=[GQ(Q(str(re[j])),Q(str(im[j]))) for j in range(max(len(re),len(im),1))]
        self.d=[GQ(Q(str(v))) for v in den.coeffs()]
        unit,factors=den.factor();self.unit=Q(str(unit));self.factors=[];rebuilt=fmpq_poly([unit])
        for fac,count in factors:
            rebuilt*=fac**count
            self.factors.append(([GQ(Q(str(v))) for v in fac.coeffs()],count))
        if rebuilt!=den:raise ArithmeticError('Rational factorization mismatch')
    @classmethod
    def native(cls,record):
        def parse(rows):
            co=[GQ() for _ in range(max((p[0] for p,c in rows),default=0)+1)]
            for powers,c in rows:
                if len(powers)!=9 or powers[1] or any(powers[3:]):raise ValueError('Unresolved source variables')
                co[powers[0]]+=GQ(Q(c))*GQ(0,DATA['E2'][1])**powers[2]
            return co
        return cls(parse(record['numerator']),parse(record['denominator']))
    @classmethod
    def restore(cls,record):
        return cls([GQ(Q(v[0]),Q(v[1])) for v in record['n']],[GQ(Q(v)) for v in record['d']])
    def record(self):return {'n':[[str(v.r),str(v.i)] for v in self.n],'d':[str(v.r) for v in self.d]}
    def reciprocal_r2(self):
        # H(t)=K(1/t)/t^2. Preserve relative polynomial degrees before cancellation.
        N=max(len(self.n)-1,len(self.d)-1)
        n=[GQ() for _ in range(N+1)];d=[GQ() for _ in range(N+3)]
        for j,v in enumerate(self.n):n[N-j]=v
        for j,v in enumerate(self.d):d[N-j+2]=v
        return Ratio(n,d)
    def eval(self,x):
        if not isinstance(x,(acb,acb_series)):x=z(x)
        den=polynomial(self.d,x);constant=den[0] if isinstance(den,acb_series) else den
        if constant.contains(0):raise ValueError('Rational denominator unresolved')
        return polynomial(self.n,x)/den
    def bound(self,center,rho):
        if type(center) not in (int,Q) or type(rho) not in (int,Q) or rho<=0:raise ValueError('Exact disk required')
        upper=sum((z(v).abs_upper()*a(rho)**j for j,v in enumerate(shifted(self.n,center))),arb(0))
        lower=a(abs(self.unit))
        for fac,count in self.factors:
            co=shifted(fac,center)
            bottom=z(co[0]).abs_lower()-sum((z(v).abs_upper()*a(rho)**j for j,v in enumerate(co) if j),arb(0))
            if not bottom>0:raise ValueError('Disk cannot exclude a rational pole')
            lower*=bottom**count
        return (upper/lower).upper()
    def exact_series(self,center,N):
        num,den=shifted(self.n,center),shifted(self.d,center)
        if zero(den[0]):raise ValueError('Exact series pole')
        out=[]
        for n in range(N+1):
            v=num[n] if n<len(num) else GQ()
            for j in range(1,min(n+1,len(den))):v-=den[j]*out[n-j]
            out.append(v/den[0])
        return out

def simple(num,den):return Ratio(list(map(GQ,num)),list(map(GQ,den)))

def exact_profile(parity,ell,k,N):
    if parity=='O':U=simple([-6,ell*(ell+1)],[0,0,0,1])
    else:
        n=(ell-1)*(ell+2)//2
        U=simple([18,18*n,6*n*n,2*n*n*(n+1)],[0,0,0,9,6*n,n*n])
    u=U.exact_series(Q(2),N);co=[GQ(1)]
    for m in range(1,N+1):
        rhs=sum((u[m-1-j]*co[j] for j in range(m)),GQ())
        rhs-=m*sum((co[j]*GQ(j*Q((-1)**(m-j),2**(m+1-j))) for j in range(1,m)),GQ())
        co.append(rhs/GQ(Q(m*m,2),-2*k*m))
    return co

def exact_infinity(parity,ell,k,N):
    def conv(p,q):return mul(list(map(GQ,p)),list(map(GQ,q)),len(p)+len(q)-2)
    if parity=='O':
        p=list(map(GQ,(0,0,1,-2)));q=[GQ(0,-2*k),GQ(2),GQ(-6)];s=list(map(GQ,(-ell*(ell+1),6)))
    else:
        n=(ell-1)*(ell+2)//2;d=[n*n,6*n,9]
        p=conv([0,0,1,-2],d);q=conv([GQ(0,-2*k),2,-6],d)
        s=list(map(GQ,(-2*n*n*(n+1),-6*n*n,-18*n,-18)))
    co=[GQ(1)]
    for m in range(N):
        rhs=GQ()
        for j in range(2,min(len(p)-1,m)+1):
            v=m-j+2;rhs+=p[j]*v*(v-1)*co[v]
        for j in range(1,min(len(q)-1,m)+1):
            v=m-j+1;rhs+=q[j]*v*co[v]
        for j in range(min(len(s)-1,m)+1):rhs+=s[j]*co[m-j]
        co.append(-rhs/(q[0]*(m+1)))
    return co
