"""Resource-bound known controls for the new completed-source evaluator."""
import ctypes
from ctypes import wintypes
from fractions import Fraction as R
import hashlib
import json
import math
import os
from pathlib import Path
import sys
import time

HERE = Path(__file__).resolve().parent
START = time.monotonic()
CODE = ('controls.py', 'source.py', 'PROTOCOL.md', 'run.ps1', '../PHYSICAL-SOURCE-SPEC.json')
CHECKS, METRICS = {}, {}


class Memory(ctypes.Structure):
    _fields_ = [('cb', wintypes.DWORD), ('faults', wintypes.DWORD)] + [
        (n, ctypes.c_size_t) for n in ('peak', 'working', 'qpp', 'pp', 'qnp', 'np', 'page', 'peakpage')]


class Status(ctypes.Structure):
    _fields_ = [('length', wintypes.DWORD), ('load', wintypes.DWORD)] + [
        (n, ctypes.c_ulonglong) for n in ('total', 'available', 'totalpage', 'availpage', 'totalvirtual', 'availvirtual', 'extended')]


def resources():
    kernel = ctypes.WinDLL('kernel32', use_last_error=True)
    kernel.GetCurrentProcess.restype = wintypes.HANDLE
    api = ctypes.WinDLL('psapi', use_last_error=True)
    api.GetProcessMemoryInfo.argtypes = [wintypes.HANDLE, ctypes.POINTER(Memory), wintypes.DWORD]
    api.GetProcessMemoryInfo.restype = wintypes.BOOL
    counter = Memory(); counter.cb = ctypes.sizeof(counter)
    status = Status(); status.length = ctypes.sizeof(status)
    kernel.GlobalMemoryStatusEx.argtypes = [ctypes.POINTER(Status)]
    kernel.GlobalMemoryStatusEx.restype = wintypes.BOOL
    if not api.GetProcessMemoryInfo(kernel.GetCurrentProcess(), ctypes.byref(counter), counter.cb) or not kernel.GlobalMemoryStatusEx(ctypes.byref(status)):
        raise ctypes.WinError(ctypes.get_last_error())
    if counter.peak >= 256*1024**2 or status.available < 2*1024**3 or time.monotonic()-START >= 90:
        raise RuntimeError('RESOURCE_GATE')
    return {'peak_working_set_bytes':int(counter.peak), 'available_bytes':int(status.available)}


class Q:
    """Exact complex pair; independent of Arb and the production derivative type."""
    def __init__(self, real=0, imaginary=0):
        if isinstance(real, Q):
            self.r, self.i = real.r, real.i
        else:
            self.r, self.i = R(real), R(imaginary)
    def __add__(self, other):
        b=Q(other); return Q(self.r+b.r, self.i+b.i)
    __radd__=__add__
    def __neg__(self): return Q(-self.r,-self.i)
    def __sub__(self, other): return self+-Q(other)
    def __rsub__(self, other): return Q(other)+-self
    def __mul__(self, other):
        b=Q(other); return Q(self.r*b.r-self.i*b.i,self.r*b.i+self.i*b.r)
    __rmul__=__mul__
    def __truediv__(self, other):
        b=Q(other); d=b.r*b.r+b.i*b.i
        return Q((self.r*b.r+self.i*b.i)/d,(self.i*b.r-self.r*b.i)/d)
    def __rtruediv__(self, other): return Q(other)/self
    def __pow__(self, n):
        v=Q(1)
        for _ in range(n): v=v*self
        return v


def bq(value):
    q=Q(value)
    return acb(arb(str(q.r)),arb(str(q.i)))


def check(name, condition):
    if name in CHECKS: raise ValueError('Duplicate check '+name)
    CHECKS[name]=bool(condition)


def enclosure(name, observed, expected):
    with ctx.workprec(768): reference=bq(expected)
    check(name, observed.is_finite() and observed.contains(reference))
    check(name+'_radius', observed.rad() < arb('1e-40'))
    METRICS[name+'_radius']=str(observed.rad())


def reject(name, function):
    try:
        function()
    except (ValueError, TypeError, ZeroDivisionError, KeyError):
        check(name,True)
    else:
        check(name,False)


def separated(name, wrong, correct):
    difference=wrong-correct
    check(name, not difference.contains(0) and difference.abs_lower()>arb('1e-12'))
    METRICS[name+'_difference_lower']=str(difference.abs_lower())


def polynomial_derivative(rows, r, w, order):
    result=Q()
    for powers, coefficient in rows:
        a=powers[0]
        if a < order: continue
        factor=math.prod(range(a-order+1,a+1)) if order else 1
        term=Q(R(coefficient)*factor*r**(a-order)*w**powers[2])
        if powers[7]: term=term*Q(0,1)
        result=result+term
    return result


def rational_oracle(record, r, w):
    n=[polynomial_derivative(record['numerator'],r,w,k) for k in range(3)]
    d=[polynomial_derivative(record['denominator'],r,w,k) for k in range(3)]
    return (n[0]/d[0], (n[1]*d[0]-n[0]*d[1])/d[0]**2,
            n[2]/d[0]-2*n[1]*d[1]/d[0]**2-n[0]*d[2]/d[0]**2+2*n[0]*d[1]**2/d[0]**3)


def parent_oracle(r, w, values, odd=False):
    f, fp, fpp=1-2/r,2/r**2,-4/r**3
    if odd:
        u=6/r**2-6/r**3; up=-12/r**3+18/r**4
    else:
        n=24*r**3+24*r**2+36*r+18; d=4*r**5+12*r**4+9*r**3
        np=72*r**2+48*r+36; dp=20*r**4+48*r**3+27*r**2
        u=n/d; up=(np*d-n*dp)/d**2
    v, vp=f*u,fp*u+f*up
    a=(v-w*w)/f**2; ap=vp/f**2-2*(v-w*w)*fp/f**3
    b=-fp/f; bp=-fpp/f+fp*fp/f**2
    p,pr=values; p2=a*p+b*pr; p3=ap*p+(a+bp)*pr+b*p2
    return ((p,pr,p2),(pr,p2,p3))


def bilinear_oracle(record,r,w,a,b):
    indices={'1010':(0,0),'1001':(0,1),'0110':(1,0),'0101':(1,1)}
    out=[Q(),Q(),Q()]
    for key,(i,j) in indices.items():
        c=rational_oracle(record[key],r,w); p,q=a[i],b[j]
        product=p[0]*q[0]; first=p[1]*q[0]+p[0]*q[1]
        second=p[2]*q[0]+2*p[1]*q[1]+p[0]*q[2]
        out[0]=out[0]+c[0]*product
        out[1]=out[1]+c[1]*product+c[0]*first
        out[2]=out[2]+c[2]*product+2*c[1]*first+c[0]*second
    return out


def source_oracle(r,w,j,F,c):
    f,fp=1-2/r,2/r**2
    v=f*(6480/r**2+1944/r**3+648/r**4+72/r**5)/(18+6/r)**2
    q0=c[0]*F[0]; q1=c[1]*F[0]+c[0]*F[1]
    q2=c[2]*F[0]+2*c[1]*F[1]+c[0]*F[2]
    return j[0]+f*f*q2+f*fp*q1+(4*w*w-v)*q0


def record_tests(evaluator,spec,raw,complete):
    zero=[0]*8
    def record(n,d=None):return {'numerator':n,'denominator':[[zero,'1']] if d is None else d}
    reject('reject_float_coefficient',lambda:s.Rational(record([[zero,0.5]])))
    reject('reject_missing_denominator',lambda:s.Rational({'numerator':[]}))
    reject('reject_zero_denominator',lambda:s.Rational(record([],[])))
    reject('reject_bad_ring_length',lambda:s.Rational(record([[[0]*7,'1']])) )
    reject('reject_negative_exponent',lambda:s.Rational(record([[[-1]+[0]*7,'1']])))
    reject('reject_unstripped_parent',lambda:s.Rational(record([[[0,0,0,1,0,0,0,0],'1']])))
    reject('reject_duplicate_monomial',lambda:s.Rational(record([[zero,'1'],[zero,'2']])))
    reject('reject_unreduced_I',lambda:s.Rational(record([[[0,0,0,0,0,0,0,2],'1']])))
    pole=record([[zero,'1']],[[[1,0,0,0,0,0,0,0],'1'],[zero,'-14']])
    reject('reject_actual_denominator_zero',lambda:s.Rational(pole).jet(acb(14),acb(1)))
    reject('reject_stale_payload_bytes',lambda:s.SourceEvaluator(spec,raw+b' ',complete))
    bad=json.loads(json.dumps(spec));bad['parents']['parities']=['E','O']
    reject('reject_odd_parent_contract',lambda:s.SourceEvaluator(bad,raw,complete))
    bad=json.loads(json.dumps(spec));bad['case']['w']='1/25'
    reject('reject_unqualified_frequency',lambda:s.SourceEvaluator(bad,raw,complete))
    bad=json.loads(json.dumps(spec));bad['normalization']['self_half_count']=2
    reject('reject_duplicate_self_half',lambda:s.SourceEvaluator(bad,raw,complete))
    reject('reject_missing_jet_key',lambda:s.bilinear({'1010':evaluator.raw['1010']},acb(14),acb(1),(s.Jet(),s.Jet()),(s.Jet(),s.Jet())))
    reject('reject_float_input',lambda:s.ball(0.5))
    reject('reject_window_straddle',lambda:s.completion_window(acb(arb(12,'0.001'))))
    reject('reject_radial_horizon',lambda:evaluator.evaluate(2,(1,0),(1,0)))
    reject('reject_complex_radius',lambda:evaluator.evaluate(acb(3,1),(1,0),(1,0)))
    reject('reject_domain_straddle',lambda:evaluator.evaluate(acb(arb(2,'0.01')),(1,0),(1,0)))
    reject('reject_normalization_zero',lambda:s.physical_response(1,0,1))
    with ctx.workprec(53):
        reject('reject_unqualified_precision',lambda:evaluator.evaluate(14,(1,0),(1,0)))


def run_tests(evaluator,spec,raw,complete):
    record_tests(evaluator,spec,raw,complete)
    raw_records=json.loads(raw)['Jraw']; f_records=json.loads(complete)['F']
    pa=(Q(2,R(1,3)),Q(R(-1,4),R(1,5)))
    pb=(Q(R(1,7),R(-1,8)),Q(R(3,11),R(1,13)))
    w=R(3,50); snapshots=[]
    for r in (R(101,50),R(6),R(12),R(14),R(16),R(20)):
        resources()
        a,b=parent_oracle(r,w,pa),parent_oracle(r,w,pb)
        j=bilinear_oracle(raw_records,r,w,a,b); F=bilinear_oracle(f_records,r,w,a,b)
        c=(R(0),R(0),R(0)) if r<=12 else ((R(1,2),R(1,2),R(0)) if r==14 else (R(1),R(0),R(0)))
        expected_source=source_oracle(r,w,j,F,c)
        low=None
        for bits in (256,384):
            with ctx.workprec(bits):
                rr,ww=bq(Q(r)),bq(Q(w))
                observed=evaluator.evaluate(rr,tuple(map(bq,pa)),tuple(map(bq,pb)))
                tag=str(r)+'_'+str(bits)
                for label,records,coefficients in [('Jcoef',raw_records,evaluator.raw),('Fcoef',f_records,evaluator.complete)]:
                    for key in s.KEYS:
                        exact=rational_oracle(records[key],r,w)
                        jet=coefficients[key].jet(rr,ww)
                        for k,value in enumerate(jet.values()):enclosure(tag+'_'+label+'_'+key+'_'+str(k),value,exact[k])
                for label,exact in [('J',j),('F',F)]:
                    for k,value in enumerate(observed[label].values()):enclosure(tag+'_'+label+'_'+str(k),value,exact[k])
                enclosure(tag+'_complete_source',observed['S'],expected_source)
                if low is None:
                    low=observed['S']
                else:
                    check(str(r)+'_precision_overlap',observed['S'].overlaps(low))
                if bits==256:
                    snapshots.append({'r':str(r),'S_real':observed['S'].real.str(80),'S_imag':observed['S'].imag.str(80),'kind':'KNOWN_MANUFACTURED_CAUCHY_DATA'})
        if r==14:
            rr=bq(Q(r));observed=evaluator.evaluate(rr,tuple(map(bq,pa)),tuple(map(bq,pb)))
            separated('missing_first_cutoff_derivative',observed['S']-observed['cutoff_first'],observed['S'])
            separated('missing_second_cutoff_derivative',observed['S']-observed['cutoff_second'],observed['S'])
            wrongF=bilinear_oracle(f_records,r,w,a,parent_oracle(r,w,pb,odd=True))
            separated('wrong_odd_dynamics_for_slot_B',bq(source_oracle(r,w,j,wrongF,c)),observed['S'])
            exchanged=evaluator.evaluate(rr,tuple(map(bq,pb)),tuple(map(bq,pa)))
            check('parent_exchange',exchanged['S'].overlaps(observed['S']))
            factor=Q(2,3)
            scaled=evaluator.evaluate(rr,tuple(bq(factor*v) for v in pa),tuple(map(bq,pb)))
            check('bilinear_scaling',scaled['S'].overlaps(bq(factor)*observed['S']))
            empty=evaluator.evaluate(rr,(0,0),tuple(map(bq,pb)))
            check('zero_parent',empty['S'].is_zero() and empty['J'].v.is_zero() and empty['F'].v.is_zero())
            encoded=acb(arb(observed['S'].real.str(80)),arb(observed['S'].imag.str(80)))
            check('outward_serialization',encoded.contains(observed['S']))
        if r==R(101,50):
            separated('missing_raw_source',acb(0),low)
    for r in (13,15):
        z=arb(r-12)/4; alpha=-1/z+1/(1-z)
        c=alpha.exp()/(1+alpha.exp()); gr=(1/z**2+1/(1-z)**2)/4
        grr=(-2/z**3+2/(1-z)**3)/16
        reference=(c,c*(1-c)*gr,c*(1-c)*(grr+(1-2*c)*gr**2))
        result=s.completion_window(acb(r))
        for k,value in enumerate(result.values()):check('window_direct_'+str(r)+'_'+str(k),value.overlaps(acb(reference[k])) and value.rad()<arb('1e-40'))
    for r in (R(12)+R(1,2**20),R(16)-R(1,2**20)):
        left=s.completion_window(bq(Q(r)));right=s.completion_window(bq(Q(28-r)))
        check('window_endpoint_finite_'+str(r),all(v.is_finite() and v.rad()<arb('1e-40') for v in left.values()))
        check('window_reflection_'+str(r),(left.v+right.v).contains(1))
    master=acb(3,4); result=s.physical_response(master)
    independent=(3*arb(10).sqrt()/(2*6))*(arb(5)/(14*arb.pi())).sqrt()*master
    check('physical_normalization',result.overlaps(independent))
    check('factor_square_pi', (s.physical_response(1)**2*arb.pi()).contains(acb(arb('25/112'))))
    check('nonunit_incoming',s.physical_response(master,2,3).overlaps(result/6))
    separated('extra_self_half',result/2,result)
    separated('missing_angular_factor',acb(arb(10).sqrt()/4)*master,result)
    q=s.Jet(acb(1,2),acb(3,4),0);p=Q(R(5,7),R(6,11));r=R(14)
    enclosure('boundary_completion_shift',s.boundary_shift(q,bq(Q(r)),bq(p)),(1-2/r)*Q(3,4)-p*Q(1,2))
    separated('missing_boundary_radial_factor',q.d-bq(p)*q.v,s.boundary_shift(q,bq(Q(r)),bq(p)))
    return snapshots


def main():
    global acb,arb,ctx,s
    mode,nonce,target=sys.argv[1:];output=Path(target).resolve()
    if mode!='controls' or not nonce.isalnum():raise ValueError('Known evaluator controls only')
    if not output.is_dir() or any(p.name not in {'stdout.log','stderr.log'} for p in output.iterdir()):raise RuntimeError('Fresh owned target required')
    hashes={name:hashlib.sha256((HERE/name).read_bytes()).hexdigest() for name in CODE}
    identity={'pid':os.getpid(),'ppid':os.getppid(),'mode':mode,'nonce':nonce,'argv_tokens':sys.argv[1:3],'script_sha256':hashes['controls.py'],'code_sha256':hashes}
    with (output/'WORKER.json').open('x',encoding='utf-8') as stream:json.dump(identity,stream)
    ack=None
    while ack is None:
        if time.monotonic()-START>12:raise RuntimeError('Live worker acknowledgement absent')
        try:ack=json.loads((output/'BOUND.json').read_bytes())
        except (OSError,ValueError):time.sleep(0.025)
    if ack['nonce']!=nonce:raise RuntimeError('Wrong worker acknowledgement')
    before=resources()
    try:
        import flint
        from flint import acb,arb,ctx
        import source as s
        if flint.__version__!='0.9.0':raise RuntimeError('Qualified numerical runtime version changed')
        if not Path(flint.__file__).resolve().is_relative_to(Path(os.environ['PYTHONPATH']).resolve()):raise RuntimeError('Numerical package outside qualified worker path')
        spec=json.loads((HERE.parent/'PHYSICAL-SOURCE-SPEC.json').read_bytes());directory=(HERE.parent/spec['inputs']['directory']).resolve()
        raw=(directory/'SOURCE-EE.json').read_bytes();complete=(directory/'TRACE-EE.json').read_bytes()
        evaluator=s.SourceEvaluator.load()
        check('public_loader_binding',evaluator.input_hashes=={'Jraw':spec['inputs']['reported_source_sha256'],'F':spec['inputs']['reported_completion_sha256']})
        with ctx.workprec(256):snapshots=run_tests(evaluator,spec,raw,complete)
        after=resources()
        if hashes!={name:hashlib.sha256((HERE/name).read_bytes()).hexdigest() for name in CODE}:raise RuntimeError('Code changed during the owned run')
        result={'state':'PASS' if all(CHECKS.values()) else 'FAILED','checks':CHECKS,'metrics':METRICS,'manufactured_points':snapshots,'identity':identity,'input_hashes':evaluator.input_hashes,'python':sys.version,'flint':flint.__version__,'flint_file':flint.__file__,'executable':sys.executable,'resources_before':before,'resources_after':after,'wall_seconds':time.monotonic()-START,'scope':'Known manufactured evaluator controls; no retarded parent solve, physical integral or nonlinear coefficient','G3':'PARTIAL; full scattering instrument, physical integration/error budget and replacement law remain open'}
    except Exception as exc:
        result={'state':'ERROR','checks':CHECKS,'metrics':METRICS,'identity':identity,'exception':type(exc).__name__+': '+str(exc),'wall_seconds':time.monotonic()-START}
    with (output/'CONTROLS.json').open('x',encoding='utf-8',newline='\n') as stream:json.dump(result,stream,indent=2,allow_nan=False);stream.write('\n')
    print(json.dumps({'state':result['state'],'checks':len(CHECKS),'failed':[k for k,v in CHECKS.items() if not v],'exception':result.get('exception'),'wall_seconds':result['wall_seconds']}))
    return 0 if result['state']=='PASS' else 1


if __name__=='__main__':sys.exit(main())
