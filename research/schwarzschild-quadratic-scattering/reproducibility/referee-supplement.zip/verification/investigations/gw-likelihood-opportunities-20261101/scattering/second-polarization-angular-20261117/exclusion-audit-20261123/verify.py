"""Check the pure-odd obstruction from the saved source and witness."""

from collections import defaultdict
from hashlib import sha256
import json
from math import comb
from pathlib import Path
import sys

from flint import fmpq_poly

HERE = Path(__file__).resolve().parent
ROOT = next(p for p in HERE.parents if (p / "SOURCE-OF-TRUTH.md").is_file())
OBSTRUCTION = HERE.parent / "general" / "obstruction"
sys.path.insert(0, str(HERE.parents[1] / "native-family-20261117"))
from angular_algebra import CTX, Q, decode, ell, k, r

ZERO = Q(0)
F = 1 - 2 / r
DAUGHTER_LABEL = 2 * ell
DAUGHTER_POLE_FACTOR = (DAUGHTER_LABEL - 1) * (DAUGHTER_LABEL + 2) * r / 2 + 3
CERTIFICATE_SHA256 = "287a591b48d4ef5ef8fe755cdb4f02f15bc34475e7998ddc9c97717c879cd133"


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read_pinned(path, digest):
    raw = path.read_bytes()
    require(sha256(raw).hexdigest() == digest, f"Changed input: {path.name}")
    return json.loads(raw)


def admitted_input(pin):
    folder = ROOT / pin["folder"]
    result = read_pinned(folder / "RESULT.json", pin["sha256"]["result"])
    run = read_pinned(folder / "RUN.json", pin["sha256"]["run"])
    require(
        (result["state"], run["state"], run["identity_live_bound"])
        == ("PASS", "COMPLETED", True),
        f"Invalid source receipt: {folder.name}",
    )
    return result["body"]


def potential(label):
    return F * (label * (label + 1) / r**2 - 6 / r**3)


def radial_derivative(q):
    return F * q.diff(0)


def wave_action(row):
    # Rows multiply the column (J², JZ, Z²), with Z = r² D_x J.
    a = r**2 * (k**2 + potential(ell))
    b = 2 * F / r
    c = 1 / r**2
    jet_derivative = ((ZERO, 2 * c, ZERO), (a, b, c), (ZERO, 2 * a, 2 * b))

    def apply_derivative(coeffs):
        return tuple(
            radial_derivative(value)
            + sum((coeffs[i] * jet_derivative[i][j] for i in range(3)), ZERO)
            for j, value in enumerate(coeffs)
        )

    twice = apply_derivative(apply_derivative(row))
    v = 4 * k**2 + potential(DAUGHTER_LABEL)
    return tuple(d - v * q for d, q in zip(twice, row, strict=True))


def radial_groups(poly):
    groups = defaultdict(dict)
    for (radial, *other), coefficient in poly.terms():
        groups[radial][(0, *other)] = coefficient
    return {power: CTX.from_dict(terms) for power, terms in groups.items()}


def laurent_entries(row):
    result = {}
    for index, q in enumerate(row):
        denominator = radial_groups(q.d)
        require(len(denominator) == 1, "A column or residual is not Laurent in r.")
        (offset, scalar), = denominator.items()
        for power, numerator in radial_groups(q.n).items():
            result[index, power - offset] = Q(numerator, scalar)
    return result


def spatial_poles(q):
    d = q.d
    orders = []
    for factor in (r, r - 2, DAUGHTER_POLE_FACTOR):
        order = 0
        while d.degrees()[0] > 0:
            quotient, remainder = divmod(d, factor.n)
            if remainder:
                break
            d = quotient
            order += 1
        orders.append(order)
    require(d.degrees()[0] == 0, "Uncovered radial denominator factor.")
    return orders


def unscaled_degree(row):
    return max(
        int(q.n.degrees()[0] - q.d.degrees()[0]) + 2*j
        for j, q in enumerate(row) if q
    )


def signed_component(poly):
    # Expand at r = 2 + x, ell = 2 + y, k = i*omega.
    parts = (defaultdict(int), defaultdict(int))
    for powers, coefficient in poly.terms():
        require(not any(powers[j] for j in (1, 3, 4, 5, 6, 7, 8)), "Unexpected variable.")
        radial, freq, label = (int(powers[j]) for j in (0, 2, 9))
        part = parts[freq % 2]
        for x in range(radial + 1):
            for y in range(label + 1):
                part[x, freq, y] += (
                    (-1)**(freq // 2) * coefficient
                    * comb(radial, x) * comb(label, y) * 2**(radial + label - x - y)
                )
    for part in parts:
        nonzero = {powers: value for powers, value in part.items() if value}
        signs = {value > 0 for value in nonzero.values()}
        if len(signs) == 1 and any(y == 0 for _, _, y in nonzero):
            return True
    return False


def verify_denominators(values):
    checked = set()
    for q in values:
        for factor, _ in q.d.factor()[1]:
            name = str(factor)
            if name not in checked:
                require(signed_component(factor), f"Uncertified denominator: {name}")
                checked.add(name)
    return len(checked)


def angular_tail(obstruction, gamma_half):
    require(Q(obstruction.d) == k - gamma_half,
            "Expected the normalized denominator k - Gamma.")
    degrees = obstruction.n.degrees()
    require(not any(degrees[j] for j in range(10) if j not in (2, 9)), "Nonangular obstruction.")
    coefficients = [0] * (int(degrees[9]) + 1)
    for powers, value in obstruction.n.terms():
        require(powers[2] == 6, "Expected exactly the frequency factor k**6.")
        coefficients[powers[9]] = value
    angular = fmpq_poly(coefficients)
    # Check the unfactored polynomial. A shift with positive coefficients
    # controls the entire tail. Exact evaluation covers the finite gap.
    floor = 18
    shifted = fmpq_poly()
    shift = fmpq_poly([floor, 1])
    for coefficient in reversed(coefficients):
        shifted = shifted * shift + coefficient
    require(all(c >= 0 for c in shifted.coeffs()) and shifted[0] > 0,
            "The shifted angular polynomial does not certify the tail.")
    finite = {j: angular(j) for j in range(2, floor)}
    require(all(finite.values()), "A physical integer label is a zero of the obstruction.")
    adjacent_sign_changes = [
        [j, j + 1] for j in finite if finite[j] * angular(j + 1) < 0
    ]
    return {
        "angular_degree": int(angular.degree()),
        "frequency_power": 6,
        "signed_tail_from_label": floor,
        "exactly_evaluated_integer_labels": list(finite),
        "noninteger_root_brackets": adjacent_sign_changes,
    }


def main():
    result = read_pinned(OBSTRUCTION / "prove-C" / "RESULT.json", CERTIFICATE_SHA256)
    require(result["state"] == "PASS", "Obstruction certificate is unaccepted.")
    case = read_pinned(OBSTRUCTION / "CASE.json", result["code_sha256"]["CASE.json"])
    proof = result["body"]
    source = admitted_input(case["inputs"]["source"])
    poles = admitted_input(case["inputs"]["oo_poles"])
    solution = admitted_input(case["inputs"]["solution"])
    raw, forced, remainder, difference, delta, second = (
        tuple(map(decode, obj[key]))
        for obj, key in (
            (source, "oo_source_rescaled"), (poles, "removed_nonzero_radius_poles"),
            (poles, "remaining_source"), (solution, "difference"),
            (source, "delta_source_rescaled"), (solution, "second_primitive"),
        )
    )

    pole_orders = [spatial_poles(q) for q in raw]
    require(pole_orders == [[6, 0, 3]] * 3, "Unexpected pure-odd source pole orders.")
    require(all(spatial_poles(q) in ([0, 0, 0], [0, 0, 1]) for q in forced),
            "Unexpected radial factor in the forced particular term.")
    require(
        tuple(a + b for a, b in zip(wave_action(forced), remainder, strict=True)) == raw,
        "The forced term and Laurent remainder do not reproduce the source.",
    )
    require(wave_action(difference) == delta, "The second-mixture difference identity failed.")
    growth = [unscaled_degree(row) for row in (raw, remainder)]
    require(max(growth) <= 3, "Unscaled source growth exceeds the bound.")
    g = ell * (ell + 1) * (ell - 1) * (ell + 2) / 12
    L = DAUGHTER_LABEL
    gamma_half = L * (L + 1) * (L - 1) * (L + 2) / 24
    rho2 = ((gamma_half + g) / (gamma_half - g)) * ((g - k) / (g + k))
    require(rho2 == decode(source["rho"]) == decode(solution["rho"]),
            "The incident ratio from the symbolic split changed.")
    # Check the residual of the proposed rational logarithmic derivative.
    # The unused second generator is the ordinary zero location.
    ordinary_zero = Q(CTX.gens()[1])
    angular_eigenvalue = ell * (ell + 1)
    profile = 1 - ordinary_zero / r
    profile_dx = radial_derivative(profile)
    residual = radial_derivative(profile_dx) + 2*k*profile_dx - potential(ell)*profile
    expected = F * (
        (2*k*ordinary_zero - angular_eigenvalue) / r**2
        + (ordinary_zero * (angular_eigenvalue - 2) + 6) / r**3
    )
    require(residual == expected, "Unexpected logarithmic-derivative residual.")
    # The exceptional non-scattering profile is a domain counterexample.
    profile = 1 + 6 / ((angular_eigenvalue - 2) * r)
    profile_dx = radial_derivative(profile)
    require(radial_derivative(profile_dx) - 2*g*profile_dx - potential(ell)*profile == ZERO,
            "The algebraically special profile control failed.")

    row_keys = [tuple(key) for key in proof["equation_labels"]]
    weights = {row_keys[int(i)]: decode(w) for i, w in proof["witness"].items()}
    require(all(w.d == CTX.constant(1) for w in weights.values()), "Nonpolynomial witness.")
    for w in weights.values():
        require(not any(w.n.degrees()[j] for j in range(10) if j not in (2, 9)),
                "Witness depends on a variable other than k or ell.")

    def project(entries):
        return sum((weights.get(key, ZERO) * value for key, value in entries.items()), ZERO)

    all_keys = set()
    column_count = 0
    sign_flip_rejected = False
    for index, highest_power in enumerate((4, 2, 0)):
        for power in range(-7, highest_power + 1):
            trial = tuple(r**power if j == index else ZERO for j in range(3))
            entries = laurent_entries(wave_action(trial))
            all_keys.update(entries)
            require(project(entries) == ZERO, f"Witness failed on column {index}, {power}.")
            column_count += 1
            if not sign_flip_rejected:
                flip = tuple(2 * potential(L) * q for q in trial)
                sign_flip_rejected = bool(project(laurent_entries(flip)))

    rhs = laurent_entries(remainder)
    all_keys.update(rhs)
    require(len(row_keys) == len(all_keys) == 41 and set(row_keys) == all_keys,
            "The coefficient equations differ from the certificate.")
    target = project(rhs)
    require(target == decode(proof["pure_odd_obstruction"]), "Wrong projected pure-odd source.")
    require(sign_flip_rejected, "Changing the daughter potential sign escaped the witness.")
    domain = angular_tail(target, gamma_half)
    denominator_count = verify_denominators(
        (*raw, *forced, *remainder, *difference, *delta, *second, rho2)
    )
    print(json.dumps({
        "equations": len(all_keys),
        "columns_checked_exactly": column_count,
        "source_pole_orders": pole_orders,
        "unscaled_infinity_degrees_source_and_remainder": growth,
        "denominator_factors_checked": denominator_count,
        "wrong_potential_sign_rejected": sign_flip_rejected,
        "algebraically_special_profile_control": True,
        **domain,
    }, indent=2))


if __name__ == "__main__":
    main()
