"""Compare the published even-odd kernel with the linear mixture coefficient."""

import argparse
from hashlib import sha256
import json
from pathlib import Path
import re
import sys

from flint import fmpq

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / "published-ooe-comparison-20261123"))
from compare import (
    MatchedSource, Radicals, angular_controls, highest_weight_inputs, require, scalar,
    translate_sections,
)
from angular_algebra import CTX, E, Ep, Frame, J, Jp, M, Q, decode, ell, f, k, potential, quadratic, r, v
from verify import verify_denominators

SCATTERING = HERE.parents[1]
PUBLISHED = "jl/generated/SourceEOO.jl"
SOURCE_SHA = "f458dc87445baf7d79e23608c4d83de906f2e018b6b2a53e72088da880fec14c"
METRIC_SHA = "c0166fae07045ed00e394ef1ab3657735ec1c17d21a6a96899aeef16a65aca44"
ASSEMBLY_SHA = "bd4c4b8849ec6717bc9afc04c0db695358e9eb309ecfe266e8c33170f1cd55c9"
DIFFERENCE_SHA = "8f9e040f3942a016bcb467c589e0b1c9054950d6e81bdfee8500795a2dbcdb7d"
ZERO = Q(0)
ANGULAR_FACTOR = Radicals(M*v*(2*ell+1)/2)
JET_PRODUCTS = ((1, 0, 1, 0), (0, 1, 1, 0), (1, 0, 0, 1), (0, 1, 0, 1))


def pinned_bytes(path, sha):
    data = path.read_bytes()
    require(sha256(data).hexdigest() == sha, f"Input differs: {path.name}")
    return data


def admitted_body(path, sha):
    document = json.loads(pinned_bytes(path, sha))
    require(document["state"] == "PASS", f"Unadmitted input: {path.parent.name}")
    return document["body"]


def exact_angle(arg, *, multiple, result):
    require(scalar(arg.rational()) == multiple, "Unexpected trigonometric angle.")
    return result


def translate(text):
    lines = text.splitlines()
    require(
        len(lines) == 3136 and lines[2].startswith("function coefficients_eoo(")
        and lines[1813].strip().startswith("zq=") and lines[1814] == "end"
        and lines[1816].startswith("function source_eoo(") and lines[-1] == "end",
        "Pinned mixed-source layout changed.",
    )
    require(
        [j for j, line in enumerate(lines) if re.search(r"\bpi\b", line)] == [4, 1853]
        and [j for j, line in enumerate(lines) if "θ" in line] == [1853, 3032, 3088, 3092],
        "Pi or theta appears outside the angular prefactor and known angles.",
    )
    # The prefactor contribution from pi is divided out later. In the
    # angle assignments a rational scalar records a multiple of pi.
    calls = {
        "cot": lambda arg: exact_angle(arg, multiple=fmpq(1, 4), result=Radicals(1)),
        "cos": lambda arg: exact_angle(arg, multiple=fmpq(1, 2), result=Radicals(0)),
        "csc": lambda arg: exact_angle(arg, multiple=fmpq(1, 4), result=Radicals(2).sqrt()),
    }
    return translate_sections(
        lines, highest_weight_inputs(J, Jp), coefficient_return=1783, closure=1813,
        source_header=1816, expected_counts=(1779, 1317), special_calls=calls,
    )


def normalize(expression):
    q = (expression / ANGULAR_FACTOR).rational()
    require(
        not any(poly.degrees()[j] for poly in (q.n, q.d) for j in (1, 5, 6)),
        "Angular normalization did not cancel exactly.",
    )
    return q


def bilinear(q):
    axes = (3, 4, 7, 8)
    require(not any(q.d.degrees()[j] for j in axes), "Expected a field-free denominator.")
    groups = {powers: {} for powers in JET_PRODUCTS}
    for powers, coefficient in q.n.terms():
        jet = tuple(int(powers[j]) for j in axes)
        require(jet in groups, "Unexpected jet powers in the mixed expression.")
        reduced = tuple(0 if j in axes else int(power) for j, power in enumerate(powers))
        groups[jet][reduced] = coefficient
    return tuple(Q(CTX.from_dict(groups[powers]), q.d) for powers in JET_PRODUCTS)


def restrict_to_even(q, odd, odd_derivative):
    products = (E*odd, Ep*odd, E*odd_derivative, Ep*odd_derivative)
    return sum((a*b for a, b in zip(bilinear(q), products, strict=True)), ZERO)


def substitute_even_jets(q, field, derivative):
    a, b, c = quadratic(q)
    return a*field**2 + b*field*derivative + c*derivative**2


def rescale(q):
    return tuple(a/(r*r*f)**j for j, a in enumerate(quadratic(q)))


def compare_even_odd(archive):
    snapshot = SCATTERING / "native/receipts/AUTHOR-SOURCE-SNAPSHOT.json"
    pins = {row["path"]: row["sha256"] for row in json.loads(snapshot.read_bytes())}
    require(pins[PUBLISHED] == SOURCE_SHA, "Published-source receipt differs.")
    text = pinned_bytes(archive / PUBLISHED, SOURCE_SHA).decode("utf-8")
    for path in ("jl/Source.jl", "jl/QFactor.jl", "jl/HomogeneousSolutions.jl"):
        pinned_bytes(archive / path, pins[path])
    controls = angular_controls()
    complete, left, right, fields, values = translate(text)

    v_even, v_odd = potential(ell)[3:]
    daughter = 2*ell
    v_daughter = potential(daughter)[4]
    even_dd = (k*k+v_even)*E/f**2 - f.diff(0)*Ep/f
    odd_dd = (k*k+v_odd)*J/f**2 - f.diff(0)*Jp/f

    def mixed_dx(q):
        return f*(q.diff(0)+Ep*q.diff(3)+even_dd*q.diff(4)+Jp*q.diff(7)+odd_dd*q.diff(8))

    require(all(fields[f"clog_{j}"].rational() == ZERO for j in range(1, 5)),
            "A logarithmic regulator coefficient survives on the matched family.")
    regularizer = normalize(values["_t32"])
    bare = normalize(right)
    full = normalize(complete)
    left_term = normalize(left)
    require(
        left_term == mixed_dx(mixed_dx(regularizer))-(4*k*k+v_daughter)*regularizer,
        "The literal left summand does not equal the odd operator on the regulator.",
    )
    require(full == bare+left_term, "The complete source return did not recompose.")

    even_frame = Frame(ell)
    odd_frame = Frame(ell)
    odd_frame.ve = v_odd
    _, g, w, _, _ = potential(ell)
    reference_odd = (w*E-f*Ep)/(g-k)
    odd_prime = even_frame.d(reference_odd)
    require(even_frame.wave(reference_odd, ell, k, "O") == ZERO,
            "The even-to-odd parent map does not solve the odd wave equation.")

    metric = admitted_body(SCATTERING / "native-family-20261117/daughter/metric-A/RESULT.json",
                           METRIC_SHA)
    # O=-iJ on the odd input and X^-=-i O_2 on the odd output. The
    # mixed source includes both orders, so its exchange sum gets no half.
    source_even_basis = -restrict_to_even(bare, reference_odd, odd_prime)
    expected_even_basis = -decode(metric["master_sources"][1])
    require(quadratic(source_even_basis) == quadratic(expected_even_basis),
            "The published bare mixed source differs in the even parent basis.")

    reference_even = (w*E+f*Ep)/(g+k)
    even_prime = odd_frame.d(reference_even)
    require(odd_frame.wave(reference_even, ell, k, "E") == ZERO,
            "The odd-to-even parent map does not solve the even wave equation.")
    require(
        (w*reference_even-f*even_prime)/(g-k) == E
        and (w*reference_odd+f*odd_prime)/(g+k) == E,
        "The parent maps are not inverses on both seeds.",
    )

    def to_odd_basis(q):
        restricted = -restrict_to_even(q, reference_odd, odd_prime)
        return substitute_even_jets(restricted, reference_even, even_prime)

    source_on_odd = to_odd_basis(bare)
    correction = to_odd_basis(regularizer)
    regularized = to_odd_basis(full)
    delta = regularized-source_on_odd
    require(delta == odd_frame.wave(correction, daughter, 2*k, "O"),
            "The projected mixed regulator does not give a local operator image.")
    require(bool(delta), "Dropping the regularizer did not change the full source.")

    saved = admitted_body(HERE.parent / "general/assemble-A/RESULT.json", ASSEMBLY_SHA)
    rho = decode(saved["rho"])
    odd_odd = tuple(map(decode, saved["oo_source_rescaled"]))
    mixed_delta = tuple(map(decode, saved["delta_source_rescaled"]))
    expected_mixed = tuple(a-(1+rho)*b for a, b in zip(mixed_delta, odd_odd, strict=True))
    actual_mixed = rescale(source_on_odd)
    require(actual_mixed == expected_mixed,
            "Mixed coefficient differs in the reference-odd proof basis.")
    require(any(expected_mixed) and rescale(source_on_odd/2) != expected_mixed
            and rescale(-source_on_odd) != expected_mixed,
            "Wrong mixed-input half or phase escaped comparison.")

    difference = admitted_body(HERE.parent / "general/rational/solve-A/RESULT.json", DIFFERENCE_SHA)
    require(decode(difference["rho"]) == rho, "Saved mixture ratios differ.")
    primitive = tuple(map(decode, difference["difference"]))
    z = r*r*f*Ep
    field = sum((a*b for a, b in zip(primitive, (E**2, E*z, z*z), strict=True)), ZERO)
    combined = tuple(a+(1+rho)*b for a, b in zip(actual_mixed, odd_odd, strict=True))
    require(rescale(odd_frame.wave(field, daughter, 2*k, "O")) == combined,
            "The mixed and odd-odd coefficients do not share the saved difference primitive.")

    denominators = verify_denominators((
        *expected_mixed, *rescale(correction), *rescale(delta), *primitive,
        reference_even, reference_odd,
    ))
    report = {
        "published_file_sha256": SOURCE_SHA,
        "symbolic_variables": ["r", "ell", "k"],
        "coefficient_assignments": 1779,
        "source_assignments": 1317,
        "angular_controls": controls,
        "log_coefficients_zero": 4,
        "independent_parent_jet_regularizer_identity": True,
        "bare_even_basis_coefficients_equal": 3,
        "bare_odd_basis_coefficients_equal": len(expected_mixed),
        "projected_source_differs_by_local_image": True,
        "paired_mixture_difference_identity": True,
        "wrong_half_phase_and_omitted_regulator_rejected": True,
        "certified_denominator_factors": denominators,
    }
    return MatchedSource(source_on_odd, regularized, correction, report)


def verify(archive):
    return compare_even_odd(archive).report


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("archive", type=Path, help="Read-only pinned author-source directory")
    args = parser.parse_args()
    print(json.dumps(verify(args.archive), indent=2))
