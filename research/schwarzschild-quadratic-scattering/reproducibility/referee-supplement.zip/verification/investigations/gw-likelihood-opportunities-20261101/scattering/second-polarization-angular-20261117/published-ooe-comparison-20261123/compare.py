"""Compare the published odd-odd scattering source with the saved source."""

import argparse
from collections import Counter
from fractions import Fraction
from hashlib import sha256
import json
from math import factorial
from pathlib import Path
import re
import sys
from typing import NamedTuple

from flint import fmpq, fmpq_poly, fmpz

HERE = Path(__file__).resolve().parent
SCATTERING = HERE.parents[1]
E1 = SCATTERING / "physical-source/eoo-bridge-20261111"
sys.path[:0] = [
    str(HERE.parent / "exclusion-audit-20261123"),
    str(SCATTERING / "native-family-20261117"),
    str(E1 / "independent-einstein"),
    str(E1 / "functional-comparison-20261112"),
]
from angular_algebra import CTX, E, Ep, Frame, M, Q, decode, ell, f, k, potential, quadratic, r, v
from source_math import C, FUNCTIONS, compile_expression, constant, norm, root_children, wigner
from verify import verify_denominators

ZERO = Q(0)
EMPTY = frozenset()
PUBLISHED = "jl/generated/SourceOOE.jl"
SOURCE_SHA = "bd4c4b8849ec6717bc9afc04c0db695358e9eb309ecfe266e8c33170f1cd55c9"


class MatchedSource(NamedTuple):
    """Projected source and local regulator in the reference-odd basis."""

    bare: Q
    regularized: Q
    correction: Q
    report: dict


def require(condition, message):
    if not condition:
        raise ValueError(message)


def scalar(q):
    if not q:
        return fmpq(0)
    require(not any(q.n.degrees()) and not any(q.d.degrees()), "Expected a scalar.")
    return q.n.leading_coefficient() / q.d.leading_coefficient()


class Radicals:
    """Finite sums of square-free angular roots with rational jet coefficients."""

    squares = {("i", ""): Q(-1)}
    positive_factors = set()

    def __init__(self, value=0):
        if isinstance(value, Radicals):
            self.terms = value.terms
            return
        if isinstance(value, Fraction):
            value = fmpq(value.numerator, value.denominator)
        self.terms = value if isinstance(value, dict) else {EMPTY: Q(value)}
        self.terms = {roots: coeff for roots, coeff in self.terms.items() if coeff}

    def rational(self):
        require(all(not roots for roots in self.terms), "Uncancelled radical in target.")
        return self.terms.get(EMPTY, ZERO)

    def __add__(self, other):
        combined = self.terms.copy()
        for roots, coeff in Radicals(other).terms.items():
            combined[roots] = combined.get(roots, ZERO) + coeff
        return Radicals(combined)

    __radd__ = __add__

    def __neg__(self):
        return Radicals({roots: -coeff for roots, coeff in self.terms.items()})

    def __sub__(self, other):
        return self + -Radicals(other)

    def __mul__(self, other):
        combined = {}
        for left, a in self.terms.items():
            for right, b in Radicals(other).terms.items():
                product = a * b
                for root in left & right:
                    product *= self.squares[root]
                roots = left ^ right
                combined[roots] = combined.get(roots, ZERO) + product
        return Radicals(combined)

    __rmul__ = __mul__

    def inverse(self):
        require(len(self.terms) == 1, "Expected a nonzero single-term denominator.")
        (roots, coeff), = self.terms.items()
        for root in roots:
            coeff *= self.squares[root]
        return Radicals({roots: 1 / coeff})

    def __truediv__(self, other):
        return self * Radicals(other).inverse()

    def power(self, exponent):
        exponent = scalar(exponent.rational())
        require(exponent.denominator in (1, 2), "Unsupported rational power.")
        base = self if exponent.denominator == 1 else self.sqrt()
        n = int(exponent.numerator)
        if n < 0:
            base, n = base.inverse(), -n
        if len(base.terms) == 1 and EMPTY in base.terms:
            return Radicals(base.terms[EMPTY]**n)
        result = Radicals(1)
        while n:
            if n % 2:
                result *= base
            n //= 2
            if n:
                base *= base
        return result

    def sqrt(self):
        q = self.rational()
        if not q:
            return Radicals()
        require(
            not any(poly.degrees()[j] for poly in (q.n, q.d) for j in range(9)),
            "A root depends on a nonangular variable.",
        )
        n_unit, n_factors = q.n.factor()
        d_unit, d_factors = q.d.factor()
        unit = n_unit / d_unit
        require(unit > 0, "Angular radicand has negative content.")
        outside = Q(1)
        roots = set()
        constants = [(p, int(e)) for p, e in fmpz(unit.numerator).factor()]
        constants += [(p, -int(e)) for p, e in fmpz(unit.denominator).factor()]
        factors = [(("prime", str(p)), Q(int(p)), e) for p, e in constants]
        for group, sign in ((n_factors, 1), (d_factors, -1)):
            for polynomial, exponent in group:
                name = ("angular", str(polynomial))
                if name not in self.positive_factors:
                    coeffs = [fmpq(0)] * (int(polynomial.degrees()[9]) + 1)
                    for powers, value in polynomial.terms():
                        coeffs[powers[9]] = value
                    shifted = fmpq_poly()
                    for value in reversed(coeffs):
                        shifted = shifted * fmpq_poly([2, 1]) + value
                    require(
                        shifted[0] > 0 and all(c >= 0 for c in shifted.coeffs()),
                        f"Could not choose the positive angular root of {polynomial}.",
                    )
                    self.positive_factors.add(name)
                factors.append((name, Q(polynomial), sign * int(exponent)))
        for name, square, exponent in factors:
            outside *= square**(exponent // 2)
            if exponent % 2:
                self.squares[name] = square
                roots.add(name)
        return Radicals({frozenset(roots): outside})


I = Radicals({frozenset({("i", "")}): Q(1)})


def wigner_ratio_squared(label, a, b):
    factors = {
        (0, 0): Q(1),
        (0, 1): (2*label + 1) / (2*(label + 1)),
        (1, 0): (2*label + 1) / (2*(label + 1)),
        (0, 2): (label - 1)*(2*label + 1) / ((label + 2)*(2*label - 1)),
        (1, 1): label*(2*label + 1) / ((label + 1)*(2*label - 1)),
        (2, 0): (label - 1)*(2*label + 1) / ((label + 2)*(2*label - 1)),
    }
    return factors[a, b]


def normalized_wigner(arguments):
    args = [x.rational() for x in arguments]
    require(args[:3] == [ell, ell, 2*ell], "Unexpected angular coupling.")
    a, b, c = args[3:]
    require(a + b + c == ZERO, "Wigner weights do not sum to zero.")
    if a == ell and b == ell:
        return Radicals(1 / (4*ell + 1)).sqrt()
    a, b = int(scalar(a)), int(scalar(b))
    return (-1)**(a + b) * Radicals(v) * Radicals(wigner_ratio_squared(ell, a, b)).sqrt()


def angular_controls(additional_pairs=()):
    def harmonic_norm_squared_times_pi(label):
        return Fraction(factorial(2*label+1), 4**(label+1)*factorial(label)**2)

    count = 0
    for l0 in (2, 5, 6):
        def fixed_wigner(a, b):
            return wigner(*map(C, (l0, l0, 2*l0, a, b, -a-b)))

        top = fixed_wigner(l0, l0)
        require((top*top).scalar() == Fraction(1, 4*l0+1), "Highest-weight Wigner square.")
        require(constant(next(iter(top.v.values()))) > 0, "Highest-weight Wigner sign.")
        zero = fixed_wigner(0, 0)
        angular_squared_times_pi = Fraction((2*l0+1)**2, 4) * (zero*zero).scalar()
        expected = harmonic_norm_squared_times_pi(l0)**2 / harmonic_norm_squared_times_pi(2*l0)
        require(angular_squared_times_pi == expected, "Highest-weight projection normalization.")
        count += 2
        for a, b in ((0, 0), (0, 1), (0, 2), (1, 1), (2, 0)) + additional_pairs:
            ratio = fixed_wigner(a, b) / zero
            expect = scalar(wigner_ratio_squared(Q(l0), a, b))
            require(fmpq(str((ratio*ratio).scalar())) == expect, "Wigner ratio square.")
            require(
                (-1)**(a + b) * constant(next(iter(ratio.v.values()))) > 0,
                "Wigner ratio sign.",
            )
            count += 1
    return count


def evaluate(compiled, env, fields, special_calls=None):
    stack = []
    for kind, value in compiled:
        if kind == "number":
            stack.append(Radicals(Fraction(value)))
        elif kind == "name":
            stack.append(fields[value[3:]] if value.startswith("cf.") else env[value])
        elif value in ("neg", "pos"):
            if value == "neg":
                stack[-1] = -stack[-1]
        elif value.startswith("call:"):
            name = value[5:]
            count = FUNCTIONS[name]
            args = stack[-count:]
            del stack[-count:]
            if name == "wigner3j":
                stack.append(normalized_wigner(args))
            elif name == "sqrt":
                stack.append(args[0].sqrt())
            elif name == "Float64":
                stack.append(args[0])
            elif special_calls and name in special_calls:
                stack.append(special_calls[name](*args))
            else:
                raise ValueError(f"Unsupported call in the pinned source: {name}")
        else:
            b, a = stack.pop(), stack.pop()
            if value == "+":
                stack.append(a+b)
            elif value == "-":
                stack.append(a-b)
            elif value == "*":
                stack.append(a*b)
            elif value == "/":
                stack.append(a/b)
            elif value == "^":
                stack.append(a.power(b))
            else:
                raise ValueError(f"Unsupported source operator: {value}")
    require(len(stack) == 1, "Incomplete translation.")
    return stack[0]


def statements(lines):
    for line in lines:
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        name, value = re.fullmatch(r"([^\W\d]\w*)\s*=\s*(.+)", line).groups()
        yield norm(name), value


def local_references(compiled):
    return {value for kind, value in compiled if kind == "name" and not value.startswith("cf.")}


def assignments(lines, env, fields, special_calls=None, retain=None):
    remaining = None
    if retain is not None:
        # Every assignment still evaluates. Discard temporaries after
        # their final use to bound memory on the large even-even source.
        remaining = Counter(retain)
        for _, value in statements(lines):
            remaining.update(local_references(compile_expression(value)))
    count = 0
    for name, value in statements(lines):
        compiled = compile_expression(value)
        expr = evaluate(compiled, env, fields, special_calls)
        if name == "KK" and not fields:
            require(expr.rational() == (2*ell+1)/2, "Wrong highest-weight KK.")
            expr *= Radicals(M)
        if remaining is not None:
            for dependency in local_references(compiled):
                remaining[dependency] -= 1
                if not remaining[dependency]:
                    env.pop(dependency, None)
        if remaining is None or remaining[name]:
            env[name] = expr
        count += 1
    return count


def highest_weight_inputs(second_parent, second_derivative):
    return {
        norm(name): Radicals(value)
        for name, value in {
            "l1": ell, "l2": ell, "l": 2*ell, "m1": ell, "m2": ell,
            "ω1": -I*Radicals(k), "ω2": -I*Radicals(k), "im": I, "pi": 1,
            "r": r, "ϕ1": E, "ψ1": Ep, "ϕ2": second_parent, "ψ2": second_derivative,
            **dict.fromkeys(("c1m2", "c1m1", "c2m2", "c2m1", "c3m2", "c4m2"), 0),
        }.items()
    }


def translate_sections(lines, inputs, *, coefficient_return, closure, source_header,
                       expected_counts, special_calls=None, retain_source=None):
    env = dict(inputs)
    first_return = lines[coefficient_return].strip()
    require(first_return.startswith("return ("), "Missing coefficient return.")
    aliases = {}
    returned_fields = first_return[len("return ("):] + "".join(lines[coefficient_return+1:closure])
    for field in returned_fields.split(","):
        if field.strip():
            name, value = map(norm, (token.strip() for token in field.split("=")))
            require(name not in aliases, "Duplicate coefficient field.")
            aliases[name] = value
    retain_fields = set(aliases.values()) if retain_source is not None else None
    ncoeff = assignments(lines[4:coefficient_return], env, {}, special_calls, retain_fields)
    fields = {name: env[value] for name, value in aliases.items()}
    source_env = dict(inputs)
    source_return = lines[-2].strip()
    require(source_return.startswith("return "), "Missing published source return.")
    compiled = compile_expression(source_return[len("return "):])
    keep = set(retain_source) | local_references(compiled) if retain_source is not None else None
    nsource = assignments(lines[source_header+1:-2], source_env, fields, special_calls, keep)
    require((ncoeff, nsource) == expected_counts, "Incomplete published assignment inventory.")
    root, (left, right) = root_children(compiled)
    require(root == "+", "Published source does not have the expected additive split.")
    return (
        evaluate(compiled, source_env, fields, special_calls),
        evaluate(left, source_env, fields, special_calls),
        evaluate(right, source_env, fields, special_calls),
        fields, source_env,
    )


def translate(text):
    lines = text.splitlines()
    require(
        len(lines) == 774 and lines[2].startswith("function coefficients_ooe(")
        and lines[430] == "end" and lines[432].startswith("function source_ooe(")
        and lines[-1] == "end" and lines[429].strip().startswith("zq="),
        "Pinned source layout changed.",
    )
    pi_lines = [j for j, line in enumerate(lines) if re.search(r"\bpi\b", line)]
    theta_lines = [j for j, line in enumerate(lines) if re.search(r"\bθ\b", line)]
    require(pi_lines == [4, 465] and theta_lines == [465],
            "Pi appears outside the angular prefactor or the unused theta assignment.")
    return translate_sections(
        lines, highest_weight_inputs(E, Ep), coefficient_return=403, closure=429,
        source_header=432, expected_counts=(399, 339),
    )


def compare_odd_odd(archive):
    snapshot = SCATTERING / "native/receipts/AUTHOR-SOURCE-SNAPSHOT.json"
    pins = {row["path"]: row["sha256"] for row in json.loads(snapshot.read_bytes())}
    files = {
        name: (archive / name).read_bytes()
        for name in (PUBLISHED, "jl/Source.jl", "jl/QFactor.jl", "jl/HomogeneousSolutions.jl")
    }
    for name, raw in files.items():
        require(sha256(raw).hexdigest() == pins[name], f"Author source differs: {name}")
    source_text = files[PUBLISHED].decode("utf-8")
    checks = angular_controls()
    total, left, bare, fields, values = translate(source_text)

    # The two marker axes prove that the exact expressions carry the
    # common KK*JS_000 angular projection factor. pi=1 omits its 1/sqrt(pi).
    angular = M * v * (2*ell+1) / 2

    def remove_angular(expression):
        q = (expression / Radicals(angular)).rational()
        require(
            not any(poly.degrees()[j] for poly in (q.n, q.d) for j in (1, 5, 6, 7, 8)),
            "Angular factors did not cancel exactly.",
        )
        return q

    odd_jets = (E, f*Ep)
    products = tuple(x*y for x in odd_jets for y in odd_jets)
    logs = tuple(fields[f"clog_{j}"].rational() for j in range(1, 5))
    require(sum((c*t for c, t in zip(logs, products, strict=True)), ZERO) == ZERO,
            "The published logarithmic shift survives the equal-parent restriction.")
    u_fields = (
        sum((fields[f"c_{j}_{name}"] * Radicals(r**power)
             for name, power in (("m2", -2), ("m1", -1), ("0", 0), ("1", 1))), Radicals())
        for j in range(1, 5)
    )
    u = remove_angular(sum((c*Radicals(t) for c, t in zip(u_fields, products, strict=True)), Radicals()))
    require(u == remove_angular(values["_t33"]), "Published regularizer fields and temporary differ.")
    frame = Frame(ell)
    frame.ve = potential(ell)[4]
    daughter = 2*ell
    _, gamma, w, _, _ = potential(daughter)
    require(
        remove_angular(left) == frame.wave(u, daughter, 2*k, "E"),
        "The literal left return summand is not the even operator acting on the regularizer.",
    )
    q_total, q_bare = remove_angular(total), remove_angular(bare)
    require(q_total == remove_angular(left) + q_bare, "Complete return did not recompose.")

    def project(q):
        return (w*q-f*frame.d(q))/(gamma-2*k)

    def rescale(q):
        return tuple(value/(r*r*f)**j for j, value in enumerate(quadratic(q)))

    stored = (HERE.parent / "general/assemble-A/RESULT.json").read_bytes()
    require(sha256(stored).hexdigest() == SOURCE_SHA, "Saved pure-odd source differs.")
    admitted = json.loads(stored)
    require(admitted["state"] == "PASS", "Saved pure-odd source is unadmitted.")
    ours = tuple(map(decode, admitted["body"]["oo_source_rescaled"]))

    # The author expression is exchange-summed. Its equal-parent half
    # and the two phases O=-i J give the fixed map -1/2.
    bare_projected = -project(q_bare)/2
    observed = rescale(bare_projected)
    for power, (expected, actual) in enumerate(zip(ours, observed, strict=True)):
        require(actual == expected, f"Projected bare source differs in jet coefficient {power}.")
    correction = -project(u)/2
    regularized = -project(q_total)/2
    difference = regularized-bare_projected
    require(difference == frame.wave(correction, daughter, 2*k, "O"),
            "The regularized source is not the bare source plus the projected local shift.")
    require(bool(difference), "Omitting the regularization shift escaped the comparison.")
    require(any(q for q in ours) and rescale(2*bare_projected) != ours
            and rescale(-bare_projected) != ours, "Normalization negatives did not reject.")
    denominators = verify_denominators((*ours, *rescale(correction), *rescale(difference)))
    report = {
        "published_file_sha256": pins[PUBLISHED],
        "symbolic_variables": ["r", "ell", "k"],
        "coefficient_assignments": 399,
        "source_assignments": 339,
        "fixed_wigner_controls": checks,
        "bare_projected_jet_coefficients_equal": len(ours),
        "regularizer_return_grouping_passed": True,
        "self_log_shift_zero": True,
        "projected_regularized_source_equivalent": True,
        "normalization_and_omitted_shift_negatives_rejected": True,
        "certified_denominator_factors": denominators,
    }
    return MatchedSource(bare_projected, regularized, correction, report)


def verify(archive):
    return compare_odd_odd(archive).report


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("archive", type=Path, help="Read-only pinned author-source directory")
    args = parser.parse_args()
    print(json.dumps(verify(args.archive), indent=2))
