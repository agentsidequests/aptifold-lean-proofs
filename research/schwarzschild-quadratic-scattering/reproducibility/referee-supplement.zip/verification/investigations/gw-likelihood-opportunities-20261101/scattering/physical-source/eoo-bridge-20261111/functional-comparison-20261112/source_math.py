"""Restricted exact Julia-expression representation, never Julia execution."""
from fractions import Fraction
from math import factorial,gcd,isqrt
import re
import unicodedata
from algebra import RF,I,from_record


def rat(value):
    if isinstance(value,RF): return value
    value=Fraction(value)
    return RF(value.numerator)/value.denominator


def constant(value):
    value=RF(value)
    if any(p>0 for p in value.n.degrees()+value.d.degrees()):
        raise ValueError("Nonconstant exact scalar")
    numerator=sum((Fraction(str(c)) for _,c in value.n.terms()),Fraction(0))
    denominator=sum((Fraction(str(c)) for _,c in value.d.terms()),Fraction(0))
    return numerator/denominator


class C:
    """sum coefficient_RF * sqrt(squarefree integer) * pi^(integer/2)."""
    def __init__(self,value=0):
        if isinstance(value,C): self.v=value.v
        elif isinstance(value,dict): self.v={k:rat(v) for k,v in value.items() if v}
        else:
            value=rat(value)
            self.v={(1,0):value} if value else {}
    def __bool__(self): return bool(self.v)
    def __neg__(self): return C({k:-v for k,v in self.v.items()})
    def __add__(self,other):
        out=dict(self.v)
        for k,v in C(other).v.items(): out[k]=out.get(k,RF(0))+v
        return C(out)
    __radd__=__add__
    def __sub__(self,other): return self+-C(other)
    def __rsub__(self,other): return C(other)+-self
    def __mul__(self,other):
        out={}
        for (a,p),x in self.v.items():
            for (b,q),y in C(other).v.items():
                common=gcd(a,b)
                key=(a*b//(common*common),p+q)
                out[key]=out.get(key,RF(0))+common*x*y
        return C(out)
    __rmul__=__mul__
    def inverse(self):
        if len(self.v)!=1: raise ValueError("Nonmonomial or zero angular divisor")
        (d,p),coefficient=next(iter(self.v.items()))
        return C({(d,-p):RF(1)/(d*coefficient)})
    def __truediv__(self,other): return self*C(other).inverse()
    def __rtruediv__(self,other): return C(other)*self.inverse()
    def __pow__(self,n):
        if not isinstance(n,int): raise ValueError("Noninteger power")
        if n<0: return self.inverse()**(-n)
        out=C(1)
        base=self
        while n:
            if n%2: out=out*base
            n//=2
            if n: base=base*base
        return out
    def exact_power(self,exponent):
        exponent=C(exponent).scalar()
        if exponent.denominator==1: return self**exponent.numerator
        if exponent.denominator==2: return sqrt_fraction(self)**exponent.numerator
        raise ValueError("Unsupported algebraic exponent")
    def __eq__(self,other): return not self-C(other)
    def scalar(self):
        if not self: return Fraction(0)
        if set(self.v)!={(1,0)}: raise ValueError("Nonrational exact scalar")
        return constant(self.v[1,0])
    def rational_function(self):
        if not self: return RF(0)
        if set(self.v)!={(1,0)}: raise ValueError("Unresolved angular factor")
        return self.v[1,0]
    def record(self): return [[d,p,v.record()] for (d,p),v in sorted(self.v.items())]


def sqrt_fraction(value):
    value=C(value)
    if not value: return C(0)
    if len(value.v)!=1: raise ValueError("Nonmonomial square root")
    (basis,power),coefficient=next(iter(value.v.items()))
    if basis!=1 or power%2: raise ValueError("Unsupported fourth root")
    q=constant(coefficient)
    if q<0: return C(I)*sqrt_fraction(C({(1,power):-coefficient}))
    if q==0: return C(0)
    # sqrt(n/d)=sqrt(n*d)/d, keeping the squarefree basis explicit.
    rest=q.numerator*q.denominator
    outside=1
    squarefree=1
    divisor=2
    while divisor*divisor<=rest:
        count=0
        while rest%divisor==0:
            rest//=divisor
            count+=1
        outside*=divisor**(count//2)
        if count%2: squarefree*=divisor
        divisor+=1
    squarefree*=rest
    return C({(squarefree,power//2):RF(outside)/q.denominator})


def integer(value):
    q=C(value).scalar()
    if q.denominator!=1: raise ValueError("Noninteger discrete argument")
    return q.numerator


def sign(n): return 1 if n%2==0 else -1


def wigner(*values):
    if len(values)!=6: raise ValueError("Wigner arity")
    a,b,c,m,n,p=map(integer,values)
    if m+n+p or min(a,b,c)<0 or abs(m)>a or abs(n)>b or abs(p)>c or c>a+b or c<abs(a-b): return C(0)
    triangle=Fraction(factorial(a+b-c)*factorial(a-b+c)*factorial(-a+b+c),factorial(a+b+c+1))
    product=factorial(a+m)*factorial(a-m)*factorial(b+n)*factorial(b-n)*factorial(c+p)*factorial(c-p)
    total=Fraction(0)
    for z in range(a+b+c+1):
        indices=(z,a+b-c-z,a-m-z,b+n-z,c-b+m+z,c-a-n+z)
        if min(indices)<0: continue
        divisor=1
        for j in indices: divisor*=factorial(j)
        total+=Fraction(sign(z),divisor)
    return sign(a-b-p)*total*sqrt_fraction(triangle*product)


def trig(name,value):
    value=C(value)
    if not value: angle=Fraction(0)
    elif set(value.v)=={(1,2)}: angle=constant(value.v[1,2])
    else: raise ValueError("Trig argument is not a rational multiple of pi")
    index=angle*4
    if index.denominator!=1: raise ValueError("Unsupported exact angle")
    k=index.numerator%8
    halfroot=sqrt_fraction(Fraction(1,2))
    sine=(C(0),halfroot,C(1),halfroot,C(0),-halfroot,C(-1),-halfroot)[k]
    cosine=(C(1),halfroot,C(0),-halfroot,C(-1),-halfroot,C(0),halfroot)[k]
    if name=="cos": return cosine
    if name=="cot": return cosine/sine
    if name=="csc": return 1/sine
    raise ValueError("Unsupported trigonometric function")


FUNCTIONS={"sqrt":1,"Float64":1,"wigner3j":6,"cot":1,"cos":1,"csc":1}
TOKEN=re.compile(r"\s+|cf\.[^\W\d]\w*|(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?|[^\W\d]\w*|[+*/^(),-]",re.UNICODE)
NUMBER=re.compile(r"(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?\Z")
IDENTIFIER=re.compile(r"[^\W\d]\w*\Z",re.UNICODE)
PRECEDENCE={"+":1,"-":1,"*":2,"/":2,"neg":3,"pos":3,"^":4}


def norm(value): return unicodedata.normalize("NFKC",value)


def decode(value): return C({(int(d),int(p)):from_record(c) for d,p,c in value})


def compile_expression(text):
    tokens=[]
    end=0
    for match in TOKEN.finditer(text):
        if match.start()!=end: raise ValueError("Unsupported source token at "+str(end))
        end=match.end()
        token=match.group()
        if token.isspace(): continue
        token=norm(token)
        if tokens and NUMBER.fullmatch(tokens[-1]) and (IDENTIFIER.fullmatch(token) or token=="("):
            tokens.append("*")
        tokens.append(token)
    if end!=len(text): raise ValueError("Unsupported source tail")
    output=[]
    stack=[]
    operand=False
    for j,token in enumerate(tokens):
        if NUMBER.fullmatch(token): output.append(("number",token)); operand=True
        elif IDENTIFIER.fullmatch(token) or token.startswith("cf."):
            if j+1<len(tokens) and tokens[j+1]=="(":
                if token not in FUNCTIONS: raise ValueError("Unsupported callable: "+token)
                stack.append("call:"+token)
            else: output.append(("name",token)); operand=True
        elif token=="(": stack.append(token); operand=False
        elif token==",":
            while stack and stack[-1]!="(": output.append(("op",stack.pop()))
            if not stack: raise ValueError("Unbound source comma")
            operand=False
        elif token==")":
            while stack and stack[-1]!="(": output.append(("op",stack.pop()))
            if not stack: raise ValueError("Unbalanced source close")
            stack.pop()
            if stack and stack[-1].startswith("call:"): output.append(("op",stack.pop()))
            operand=True
        else:
            if token in ("+","-") and not operand: stack.append("pos" if token=="+" else "neg"); continue
            if token not in PRECEDENCE or not operand: raise ValueError("Malformed source operator")
            while stack and stack[-1] in PRECEDENCE and (PRECEDENCE[stack[-1]]>PRECEDENCE[token] or PRECEDENCE[stack[-1]]==PRECEDENCE[token] and token!="^"):
                output.append(("op",stack.pop()))
            stack.append(token)
            operand=False
    if not operand: raise ValueError("Incomplete source expression")
    while stack:
        token=stack.pop()
        if token=="(" or token.startswith("call:"): raise ValueError("Unbalanced source open")
        output.append(("op",token))
    return output


def evaluate(compiled,env,cf=None):
    stack=[]
    for kind,value in compiled:
        if kind=="number": stack.append(C(Fraction(value))); continue
        if kind=="name":
            stack.append(cf[value[3:]] if value.startswith("cf.") and cf is not None else env[value]); continue
        if value in ("neg","pos"):
            if not stack: raise ValueError("Unary source stack underflow")
            a=stack.pop(); stack.append(-a if value=="neg" else a); continue
        if value.startswith("call:"):
            name=value[5:]; count=FUNCTIONS[name]
            if len(stack)<count: raise ValueError("Callable source stack underflow")
            args=stack[-count:]; del stack[-count:]
            if name=="sqrt": answer=sqrt_fraction(args[0])
            elif name=="Float64": answer=args[0]
            elif name=="wigner3j": answer=wigner(*args)
            else: answer=trig(name,args[0])
            stack.append(answer); continue
        if len(stack)<2: raise ValueError("Binary source stack underflow")
        b,a=stack.pop(),stack.pop()
        if value=="+": answer=a+b
        elif value=="-": answer=a-b
        elif value=="*": answer=a*b
        elif value=="/": answer=a/b
        elif value=="^": answer=a.exact_power(b)
        else: raise ValueError("Unknown source opcode")
        stack.append(answer)
    if len(stack)!=1: raise ValueError("Incomplete source-stack reduction")
    return stack[0]


def expression(text,env,cf=None): return evaluate(compile_expression(text),env,cf)


def root_children(compiled):
    stack=[]
    for j,(kind,value) in enumerate(compiled):
        if kind!="op": stack.append((j,j+1)); continue
        count=FUNCTIONS[value[5:]] if value.startswith("call:") else 1 if value in ("neg","pos") else 2
        if len(stack)<count: raise ValueError("Malformed root scope")
        children=stack[-count:]
        del stack[-count:]
        stack.append((children[0][0],j+1))
        if j==len(compiled)-1:
            return value,[compiled[a:b] for a,b in children]
    raise ValueError("Source return lacks an operator root")


def statements(lines,start,end,env,cf=None):
    count=0
    for j in range(start,end):
        line=lines[j].strip()
        if not line or line.startswith("#"): continue
        match=re.fullmatch(r"([^\W\d]\w*)\s*=\s*(.+)",line)
        if not match: raise ValueError("Unlisted source statement at line "+str(j+1))
        env[norm(match.group(1))]=expression(match.group(2),env,cf)
        count+=1
    return count


def translate(text,inputs):
    lines=text.splitlines()
    first=next(j for j,line in enumerate(lines) if line.startswith("function coefficients_eoo("))
    while not lines[first].endswith(")"): first+=1
    returned=next(j for j in range(first+1,len(lines)) if lines[j].lstrip().startswith("return ("))
    closure=next(j for j in range(returned+1,len(lines)) if lines[j].lstrip().startswith("zq="))
    if lines[closure+1]!="end": raise ValueError("Unexpected coefficient closure boundary")
    env=dict(inputs)
    ncoeff=statements(lines,first+1,returned,env)
    fields={}
    parts=lines[returned].strip()[len("return ("):]+"".join(lines[returned+1:closure])
    for part in parts.split(","):
        if not part.strip(): continue
        match=re.fullmatch(r"\s*([^\W\d]\w*)\s*=\s*([^\W\d]\w*)\s*",part)
        if not match: raise ValueError("Unlisted returned coefficient")
        key,rhs=map(norm,match.groups())
        if key in fields: raise ValueError("Duplicate returned field")
        fields[key]=env[rhs]
    first=next(j for j in range(closure+2,len(lines)) if lines[j].startswith("function source_eoo("))
    returned=next(j for j in range(first+1,len(lines)) if lines[j].lstrip().startswith("return "))
    source_env=dict(inputs)
    nsource=statements(lines,first+1,returned,source_env,fields)
    compiled=compile_expression(lines[returned].strip()[len("return "):])
    value=evaluate(compiled,source_env,fields)
    root,children=root_children(compiled)
    if root=="+":
        source_env["_return_left"]=evaluate(children[0],source_env,fields)
        source_env["_return_right"]=evaluate(children[1],source_env,fields)
    return value,fields,source_env,{"coefficient_assignments":ncoeff,"source_assignments":nsource,
                                  "return_line":returned+1,"excluded_unused_closure_line":closure+1,
                                  "return_root_operator":root,"return_child_roots":[part[-1][1] for part in children]}
