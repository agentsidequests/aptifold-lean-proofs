"""Real-frequency even-Zerilli instrument; analytic tails and Arb Taylor flow.

The bounds and their domain are derived in METHOD.md. No nonlinear source is
loaded, no source integral is evaluated, and no paused calculation is entered.
"""
from fractions import Fraction as Q
import math
from flint import arb, acb

SETTINGS = {
    'coarse': dict(rfar=400, far_order=32, h=Q(1,512), h_order=16, order=96, bits=256),
    'mid': dict(rfar=600, far_order=40, h=Q(1,1024), h_order=20, order=112, bits=320),
    'fine': dict(rfar=800, far_order=48, h=Q(1,2048), h_order=24, order=128, bits=384),
}
CASES = {'parent': (2,Q(3,50)), 'daughter': (4,Q(3,25))}
CUT = Q(101,50)
POINTS = (CUT,Q(8),Q(40))


def a(v):
    return arb(str(v)) if isinstance(v,Q) else arb(v)


def upper(v):
    return abs(v).upper()


def maxpoint(*values):
    return max(v.upper() for v in values)


def ball_error(v,e):
    return v+arb(0,e.upper())


def complex_error(v,ey,ed):
    # Rectangles enclose the complex disks supplied by the analytic bounds.
    return acb(ball_error(v.real,ey),ball_error(v.imag,ed))


def conjugate(v):
    return acb(v.real,-v.imag)


def f(r):
    r=a(r); return (r-2)/r


def x(r):
    r=a(r); return r+2*(r/2-1).log()


def u(r,ell):
    r=a(r); n=(ell-1)*(ell+2)//2
    return 2*(n*n*(n+1)*r**3+3*n*n*r*r+9*n*r+9)/(r**3*(n*r+3)**2)


def padd(*polys):
    out=[0]*max(map(len,polys))
    for p in polys:
        for j,c in enumerate(p): out[j]=out[j]+c
    return out


def pmul(p,q):
    out=[0]*(len(p)+len(q)-1)
    for j,c in enumerate(p):
        for k,d in enumerate(q): out[j+k]=out[j+k]+c*d
    return out


def scale(p,c):
    return [v*c for v in p]


def derivative(p):
    return [j*p[j] for j in range(1,len(p))] or [0]


def evaluate(p,t):
    out=0
    for c in reversed(p):out=out*t+c
    return out


def shifted(p,r):
    r=a(r)
    powers=[arb(1)]
    for j in range(1,len(p)): powers.append(powers[-1]*r)
    return [sum(a(p[j])*math.comb(j,i)*powers[j-i] for j in range(i,len(p))) for i in range(len(p))]


def radial_polys(ell,k,flat=False):
    n=(ell-1)*(ell+2)//2; d2=[9,6*n,n*n]
    p=pmul([0,0,4,-4,1],d2)
    q=pmul([0,-4,2],d2)
    N=[9,9*n,3*n*n,n*n*(n+1)]
    s=scale(pmul([0,0,0,0,1],d2),k*k)
    if not flat:s=padd(s,scale(pmul([-2,1],N),-2))
    return p,q,s


def disk(r,ell,k,flat=False):
    """Exact rational step choices; all required inequalities rechecked in Arb."""
    h=r-2; rr=float(r); hh=float(h); kk=float(k); ff=hh/rr
    nn=(ell-1)*(ell+2)//2
    approx_u=0. if flat else 2*(nn*nn*(nn+1)+3*nn*nn/rr+9*nn/rr**2+9/rr**3)/(nn*rr+3)**2
    S=Q.from_float(1/(kk/ff+math.sqrt(approx_u/ff)+2/(rr*hh)))
    radius=min(h/2,S)
    for _ in range(100):
        rm=a(r-radius); hm=a(h-radius); invf=a(r+radius)/hm
        umax=arb(0) if flat else 2*(nn*nn*(nn+1)+3*nn*nn/rm+9*nn/rm**2+9/rm**3)/(nn*rm+3)**2
        bound=maxpoint(1/a(S),a(S)*(umax*invf+a(k)**2*invf**2)+2/(rm*hm))
        if bound*a(radius)<=1:return S,radius,bound
        radius/=2
    raise ArithmeticError('Analytic disk selection failed')


def taylor_step(columns,r,delta,ell,k,order,flat=False):
    S,R,M=disk(r,ell,k,flat)
    rho=a(abs(delta)/R)
    if not rho<=arb('1/4'):raise ArithmeticError('Taylor step left frozen disk fraction')
    p,q,s=[shifted(z,r) for z in radial_polys(ell,k,flat)]
    dd=a(delta); output=[]; errors=[]
    for y,yr in columns:
        co=[y,yr]
        for m in range(order):
            total=arb(0)
            for j in range(1,min(len(p)-1,m)+1):
                z=m-j+2; total=total+p[j]*z*(z-1)*co[z]
            for j in range(min(len(q)-1,m)+1):
                z=m-j+1; total=total+q[j]*z*co[z]
            for j in range(min(len(s)-1,m)+1):total=total+s[j]*co[m-j]
            co.append(-total/(p[0]*(m+2)*(m+1)))
        yn=evaluate(co[:order+1],dd)
        yrd=evaluate([(j+1)*co[j+1] for j in range(order+1)],dd)
        norm=maxpoint(upper(y),a(S)*upper(yr))
        eps=(norm*(M*a(R)).exp()*rho**(order+1)/(1-rho)).upper()
        output.append((ball_error(yn,eps),ball_error(yrd,eps/a(S))))
        errors.append(eps)
    return output, maxpoint(*errors)


def transfer(start,targets,ell,k,order,resource=lambda:None,flat=False):
    r=Q(start); T=[(arb(1),arb(0)),(arb(0),arb(1))]
    saved={}; steps=0; maxerror=arb(0)
    for target in targets:
        target=Q(target)
        direction=1 if target>r else -1
        while r!=target:
            _,radius,_=disk(r,ell,k,flat)
            delta=direction*min(radius/4,abs(target-r))
            T,err=taylor_step(T,r,delta,ell,k,order,flat)
            r+=delta;steps+=1;maxerror=maxpoint(maxerror,err)
            if steps%8==0:resource()
        saved[str(target)]=tuple(T)
    return saved,dict(steps=steps,largest_local_state_error=str(maxerror))


def apply(T,z):
    return (T[0][0]*z[0]+T[1][0]*z[1],T[0][1]*z[0]+T[1][1]*z[1])


def horizon_coefficients(ell,k,order):
    n=(ell-1)*(ell+2)//2
    N=[9,9*n,3*n*n,n*n*(n+1)]
    num=shifted(scale(N,2),Q(2))
    den=shifted(pmul([0,0,0,1],[9,6*n,n*n]),Q(2))
    U=[]
    for m in range(order):
        value=num[m] if m<len(num) else arb(0)
        for j in range(1,min(m,len(den)-1)+1):value=value-den[j]*U[m-j]
        U.append(value/den[0])
    co=[acb(1)]
    for m in range(1,order+1):
        rhs=sum(U[m-1-j]*co[j] for j in range(m))
        rhs=rhs-m*sum(j*a(Q((-1)**(m-j),2**(m+1-j)))*co[j] for j in range(1,m))
        co.append(rhs/(m*acb(a(m)/2,-2*a(k))))
    return co


def horizon_seed(ell,k,h,order):
    if order<8:raise ValueError('Majorant requires at least eight coefficients')
    co=horizon_coefficients(ell,k,order)
    n=(ell-1)*(ell+2)//2
    MU=2*evaluate([9,9*n,3*n*n,n*n*(n+1)],a(Q(5,2)))/(a(Q(3,2))**3*(a(Q(3*n,2))+3)**2)
    if not MU/64+a(Q(1,3))<1:raise ArithmeticError('Horizon majorant induction failed')
    K=maxpoint(*[co[j].abs_upper()/2**j for j in range(8)])
    q=a(2*h)
    if not q<1:raise ValueError('Horizon seed outside majorant domain')
    eps=K*q**(order+1)/(1-q)
    deps=K/a(h)*q**(order+1)*((order+1)-order*q)/(1-q)**2
    carrier=acb(0,-a(k)*x(2+h)).exp()
    F=evaluate(co,a(h));Fr=evaluate(derivative(co),a(h))
    y=carrier*F;yr=carrier*(Fr-acb(0,a(k))*F/f(2+h))
    seed=(complex_error(y,eps,eps),complex_error(yr,deps+a(k)*eps/f(2+h),deps+a(k)*eps/f(2+h)))
    return seed,dict(F_tail=str(eps),F_r_tail=str(deps),majorant_K=str(K),majorant_MU=str(MU),order=order), (y,yr)


def infinity_polys(ell,k):
    n=(ell-1)*(ell+2)//2; d2=[n*n,6*n,9]
    p=pmul([0,0,1,-2],d2)
    q=pmul([acb(0,-2*a(k)),acb(2),acb(-6)],d2)
    s=scale([n*n*(n+1),3*n*n,9*n,9],-2)
    return list(map(acb,p)),list(map(acb,q)),list(map(acb,s))


def infinity_seed(ell,k,r,order):
    p,q,s=infinity_polys(ell,k);co=[acb(1)]
    for m in range(order):
        rhs=acb(0)
        for j in range(2,min(len(p)-1,m)+1):
            z=m-j+2;rhs=rhs+p[j]*z*(z-1)*co[z]
        for j in range(1,min(len(q)-1,m)+1):
            z=m-j+1;rhs=rhs+q[j]*z*co[z]
        for j in range(min(len(s)-1,m)+1):rhs=rhs+s[j]*co[m-j]
        co.append(-rhs/(q[0]*(m+1)))
    residual=padd(pmul(p,derivative(derivative(co))),pmul(q,derivative(co)),pmul(s,co))
    n=(ell-1)*(ell+2)//2;R=a(r);kk=a(k)
    CV=ell*(ell+1)/R+3/R**2+a(Q(6,n))/R**3+a(Q(9,2*n*n))/R**4
    CR=sum(v.abs_upper()/(n*n*(m+1)*R**(m+1)) for m,v in enumerate(residual))
    eta=CV/kk
    if not eta<1:raise ArithmeticError('Infinity Volterra contraction failed')
    eps=CR/(kk*(1-eta));epsx=CR+CV*eps
    G=evaluate(co,1/R);Gr=-evaluate(derivative(co),1/R)/R**2
    carrier=acb(0,kk*x(r)).exp()
    y=carrier*G;yr=carrier*(Gr+acb(0,kk)*G/f(r))
    seed=(complex_error(y,eps,eps),complex_error(yr,epsx/f(r),epsx/f(r)))
    return seed,dict(y_tail=str(eps),y_x_tail=str(epsx),residual_L1=str(CR),potential_L1=str(CV),eta=str(eta),order=order), (y,yr), co


def wronskian(z,w,r):
    return f(r)*(z[0]*w[1]-z[1]*w[0])


def flux(z,r):
    return (conjugate(z[0])*f(r)*z[1]).imag


def serialize(z):
    z=acb(z)
    out={'real':z.real.str(140),'imag':z.imag.str(140)}
    back=acb(arb(out['real']),arb(out['imag']))
    if not back.contains(z):raise ArithmeticError('Serialization lost an enclosure')
    return out


def decode(z):
    return acb(arb(z['real']),arb(z['imag']))


def relative_radius(z):
    z=acb(z)
    return z.rad()/maxpoint(arb(1),z.abs_lower())


def solve(case,level,resource=lambda:None):
    ell,k=CASES[case]; setting=SETTINGS[level]; rH=2+setting['h'];R=Q(setting['rfar'])
    seedH,tailH,midH=horizon_seed(ell,k,setting['h'],setting['h_order'])
    seedUp,tailUp,midUp,_=infinity_seed(ell,k,R,setting['far_order'])
    TH,statsH=transfer(rH,(*POINTS,R),ell,k,setting['order'],resource)
    TU,statsUp=transfer(R,tuple(reversed(POINTS)),ell,k,setting['order'],resource)
    H={r:apply(TH[str(r)],seedH) for r in (*POINTS,R)}
    Up={r:apply(TU[str(r)],seedUp) for r in POINTS};Up[R]=seedUp
    incoming=tuple(map(conjugate,seedUp)); twoik=acb(0,2*a(k))
    Ain=wronskian(H[R],seedUp,R)/twoik
    Aout=wronskian(incoming,H[R],R)/twoik
    if Ain.contains(0) or H[CUT][0].contains(0):raise ArithmeticError('Division denominator not admitted')
    reflection=Aout/Ain; transmission=1/Ain
    checks={};metrics={}
    cap=arb('1e-8') if level=='fine' else arb('1e-5')
    def invariant(name,value,target):
        d=acb(value)-acb(target)
        checks[name+'_contains']=d.contains(0)
        checks[name+'_width']=d.abs_upper()<cap
        metrics[name+'_absolute_envelope']=str(d.abs_upper())
    invariant('infinity_basis_W',wronskian(incoming,seedUp,R),twoik)
    for r in (*POINTS,R):
        invariant('H_flux_'+str(r),flux(H[r],r),-a(k))
        invariant('Up_flux_'+str(r),flux(Up[r],r),a(k))
        invariant('cross_W_'+str(r),wronskian(H[r],Up[r],r),twoik*Ain)
        t=TH[str(r)]
        invariant('H_transfer_det_'+str(r),t[0][0]*t[1][1]-t[1][0]*t[0][1],f(rH)/f(r))
        if r!=R:
            t=TU[str(r)]
            invariant('Up_transfer_det_'+str(r),t[0][0]*t[1][1]-t[1][0]*t[0][1],f(R)/f(r))
    invariant('absolute_flux_balance',(Ain*conjugate(Ain)-Aout*conjugate(Aout)),1)
    invariant('unit_incident_flux_balance',reflection*conjugate(reflection)+transmission*conjugate(transmission),1)
    pH=f(CUT)*H[CUT][1]/H[CUT][0]
    normalized=tuple(z/Ain for z in H[CUT])
    quantities=dict(Ain=Ain,Aout=Aout,reflection=reflection,transmission=transmission,pH=pH,
                    incident_y_cut=normalized[0],incident_y_r_cut=normalized[1])
    radiuscap=arb('1e-10') if level=='fine' else arb('1e-6')
    for name,z in quantities.items():
        checks[name+'_radius']=z.is_finite() and relative_radius(z)<radiuscap
        metrics[name+'_relative_radius']=str(relative_radius(z))
    return dict(state='PASS' if all(checks.values()) else 'FAILED',case=case,level=level,ell=ell,k=str(k),
                settings={key:str(value) for key,value in setting.items()},checks=checks,metrics=metrics,
                values={key:serialize(value) for key,value in quantities.items()},
                points={str(r):{'H':[serialize(z) for z in H[r]],'Up':[serialize(z) for z in Up[r]]} for r in (*POINTS,R)},
                horizon_seed=tailH,infinity_seed=tailUp,H_flow=statsH,Up_flow=statsUp,
                independent_seeds={'rH':str(rH),'R':str(R),'H':[serialize(z) for z in midH],'Up':[serialize(z) for z in midUp]})
