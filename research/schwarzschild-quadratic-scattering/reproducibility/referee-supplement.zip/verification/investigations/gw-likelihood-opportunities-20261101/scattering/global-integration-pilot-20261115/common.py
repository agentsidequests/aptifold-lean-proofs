"""Pinned runtime/data utilities. No old driver or nonlinear source is run."""
from fractions import Fraction as Q
import hashlib
import importlib.util
import json
from pathlib import Path
from flint import arb, acb

HERE=Path(__file__).resolve().parent
CASE=json.loads((HERE/'CASE.json').read_bytes())


def bound_path(name):
    item=CASE['inputs'][name]
    path=(HERE/item['path']).resolve()
    if not path.is_relative_to(HERE.parent) or hashlib.sha256(path.read_bytes()).hexdigest()!=item['sha256']:
        raise ValueError('Pinned pilot dependency changed: '+name)
    return path


def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    value=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value


oracle=module('pilot_exact_complex',bound_path('exact_complex'))
GQ=oracle.Q


def a(value):
    if type(value) in (int,Q):return arb(str(value))
    if isinstance(value,arb):return value
    raise TypeError('Exact rational or explicit real enclosure required')


def z(value):
    if isinstance(value,acb):return value
    if isinstance(value,GQ):return acb(a(value.r),a(value.i))
    return acb(a(value))


def nonnegative(value):
    value=a(value)
    if not value.is_finite() or not value>=0:raise ValueError('Finite nonnegative bound required')
    return value


def f(r):return 1-2/r
def x(r):
    rr=a(r)
    if not rr>2:raise ValueError('Real r>2 required')
    return rr+2*(rr/2-1).log()


def with_error(value,error):
    value=z(value);e=nonnegative(error).upper()
    return acb(value.real+arb(0,e),value.imag+arb(0,e))


def serialize(value):
    value=z(value)
    record={'real':value.real.str(140),'imag':value.imag.str(140)}
    if not decode(record).contains(value):raise ArithmeticError('Serialization lost an enclosure')
    return record


def decode(record):return acb(arb(record['real']),arb(record['imag']))


def potential(r,ell,parity):
    ff=1-2/r
    if parity=='O':return ff*(ell*(ell+1)/r**2-6/r**3)
    if parity!='E':raise ValueError('Unknown parity')
    n=(ell-1)*(ell+2)//2
    return ff*2*(n*n*(n+1)*r**3+3*n*n*r**2+9*n*r+9)/(r**3*(n*r+3)**2)


def umax(center,radius,ell,parity):
    rm=a(center-radius)
    if not rm>0:raise ValueError('Potential disk reaches zero')
    if parity=='O':return ell*(ell+1)/rm**2+6/rm**3
    n=(ell-1)*(ell+2)//2
    return 2*(n*n*(n+1)+3*n*n/rm+9*n/rm**2+9/rm**3)/(n*rm+3)**2
