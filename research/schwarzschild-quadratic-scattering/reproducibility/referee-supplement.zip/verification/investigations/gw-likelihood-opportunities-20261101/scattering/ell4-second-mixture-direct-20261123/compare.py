"""Compare the two sealed direct enclosures with the closed strain response."""

from hashlib import sha256
import json
from math import factorial
from pathlib import Path

from flint import acb, arb, ctx

HERE = Path(__file__).resolve().parent
PINS = {
    "SOURCE.json": "a3e3cc553867d415d2d56a04c4f52c9b96eaf318f7ae62461f0ec411e9b2942b",
    "DIRECT-coarse.json": "dbc6e5c9793021f927853153eddea81f0ed6aff3a9389dd108e35b76e9cb3138",
    "DIRECT-fine.json": "541b3daa07cc41d7b0e22172828ef576ba729b9f8469b51d8f8e5928ded4d710",
}


def sha(path):
    return sha256(path.read_bytes()).hexdigest()


def decode(data):
    return acb(arb(data["real"]), arb(data["imag"]))


def encode(value):
    record = {"real": value.real.str(85), "imag": value.imag.str(85)}
    if not decode(record).contains(value):
        raise ArithmeticError("Serialization lost a comparison enclosure.")
    return record


def radius(value):
    return (value.real.rad()**2+value.imag.rad()**2).sqrt().upper()


def load_direct(level):
    name = "DIRECT-"+level+".json"
    raw = (HERE/name).read_bytes()
    if sha256(raw).hexdigest() != PINS[name]:
        raise ValueError("The pre-comparison result changed.")
    case = json.loads(raw)
    if ((case["state"], case["level"], case["source_sha256"], case["closed_response_used"])
            != ("PASS", level, PINS["SOURCE.json"], False)):
        raise ValueError("The pre-comparison result is not admitted.")
    if any(sha(HERE/path) != pinned for path, pinned in case["input_code_sha256"].items()):
        raise ValueError("The direct integration code changed.")
    return case


def reflection(case, label):
    wave = case["linear"][str(label)]
    return decode(wave["A_out"])/decode(wave["A_in"])


def coefficients(case):
    ell = 4
    k = acb(0, arb(1)/2)
    g, gamma = arb(30), arb(210)
    even_parent = (g+k)/(g-k)*reflection(case, ell)
    odd_daughter = reflection(case, 2*ell)
    K = (arb(factorial(2*ell+1)*(20*ell**3+35*ell**2+ell-8))
         / (144*factorial(ell-1)*factorial(ell-2))
         * (arb(factorial(2*ell+2)*factorial(2*ell-2))/(arb.pi()*factorial(4*ell+1))).sqrt())
    common = K/(4*gamma)
    parent = common*k*(k-g*g/gamma)/(k+g)**2*even_parent**2
    daughter = common*k/(k-gamma)*odd_daughter
    return parent, daughter


def verify():
    ctx.prec = 384
    if sha(HERE/"SOURCE.json") != PINS["SOURCE.json"]:
        raise ValueError("The pre-comparison source changed.")
    data = {level: load_direct(level) for level in ("coarse", "fine")}
    directs = {level: decode(case["strain"]) for level, case in data.items()}
    coarse, fine = directs["coarse"], directs["fine"]
    checks = {
        "two_direct_integrations_overlap": coarse.overlaps(fine),
        "fine_enclosure_is_narrower": radius(fine) < radius(coarse),
        "direct_response_is_nonzero": not fine.contains(0),
    }
    rows = {}
    for level, case in data.items():
        direct = directs[level]
        parent, daughter = coefficients(case)
        predicted = parent+daughter
        difference = (direct-predicted).abs_upper()
        checks[level+"_matches_closed_complex_response"] = direct.overlaps(predicted)
        checks[level+"_difference_within_budget"] = difference < arb("1e-10")
        rows[level] = {
            "direct": encode(direct),
            "closed_response": encode(predicted),
            "direct_enclosure_radius_upper": str(radius(direct)),
            "absolute_complex_difference_upper": str(difference),
        }

    case = data["fine"]
    parent, daughter = coefficients(case)
    predicted = parent+daughter
    controls = {
        "omitted_parent_term": daughter,
        "omitted_daughter_term": parent,
        "reversed_parent_sign": daughter-parent,
        "reversed_daughter_sign": parent-daughter,
        "omitted_infinity_tail": decode(case["parts"]["horizon"])+decode(case["parts"]["finite"]),
        "omitted_horizon_tail": decode(case["parts"]["finite"])+decode(case["parts"]["infinity"]),
    }
    checks.update({name+"_fails": not value.overlaps(fine) for name, value in controls.items()})
    checks["both_reflection_terms_are_resolved"] = (
        parent.abs_lower() > daughter.abs_upper()/4 and daughter.abs_lower() > parent.abs_upper()/4
    )
    if not all(checks.values()):
        raise ArithmeticError("Failed comparison: "+", ".join(name for name, ok in checks.items() if not ok))
    return {
        "state": "PASS",
        "channel": "(4,4)^2 -> (8,8)",
        "parent_frequency": "1/2",
        "incident_odd_over_even": "-4i/3",
        "checks": checks,
        "integrations": rows,
        "fine_parent_squared_term": encode(parent),
        "fine_daughter_reflection_term": encode(daughter),
        "fine_magnitude": str(abs(fine)),
        "fine_phase_radians": str(fine.arg()),
        "parent_term_to_total_lower": str((parent.abs_lower()/fine.abs_upper()).lower()),
        "daughter_term_to_total_lower": str((daughter.abs_lower()/fine.abs_upper()).lower()),
        "minimum_wrong_prediction_distance": str(min(
            (value-fine).abs_lower() for name, value in controls.items() if not name.endswith("_tail")
        )),
        "precomparison_pins": PINS,
    }


if __name__ == "__main__":
    print(json.dumps(verify(), indent=2))
