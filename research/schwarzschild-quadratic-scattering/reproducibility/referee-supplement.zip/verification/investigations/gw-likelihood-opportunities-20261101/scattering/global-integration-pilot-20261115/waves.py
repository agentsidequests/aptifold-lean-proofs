"""New E/O wave cases with separately bounded odd seeds and flow coefficients."""
from fractions import Fraction as Q
import math
from flint import arb,acb
from common import CASE,a,module,bound_path


def odd_polys(L,ell,k,flat=False):
    angular=ell*(ell+1)
    p=[0,0,4,-4,1];q=[0,-4,2]
    s=[0,0,0,0,k*k] if flat else [-12,2*angular+6,-angular,0,k*k]
    return p,q,s


def odd_disk(L,r,ell,k,flat=False):
    h=r-2;rr,hh,kk=float(r),float(h),float(k);ff=hh/rr
    approx=0 if flat else ell*(ell+1)/rr**2-6/rr**3
    scale=Q.from_float(1/(kk/ff+math.sqrt(approx/ff)+2/(rr*hh)))
    radius=min(h/2,scale)
    for _ in range(100):
        rm,hm=a(r-radius),a(h-radius);invf=a(r+radius)/hm
        U=arb(0) if flat else ell*(ell+1)/rm**2+6/rm**3
        norm=L.maxpoint(1/a(scale),a(scale)*(U*invf+a(k)**2*invf**2)+2/(rm*hm))
        if norm*a(radius)<=1:return scale,radius,norm
        radius/=2
    raise ArithmeticError('Odd analytic disk selection failed')


def odd_horizon_coefficients(L,ell,k,order):
    numerator=L.shifted([-6,ell*(ell+1)],Q(2))
    denominator=L.shifted([0,0,0,1],Q(2))
    U=[]
    for m in range(order):
        value=numerator[m] if m<len(numerator) else arb(0)
        for j in range(1,min(m,len(denominator)-1)+1):value-=denominator[j]*U[m-j]
        U.append(value/denominator[0])
    co=[acb(1)]
    for m in range(1,order+1):
        rhs=sum(U[m-1-j]*co[j] for j in range(m))
        rhs-=m*sum(j*a(Q((-1)**(m-j),2**(m+1-j)))*co[j] for j in range(1,m))
        co.append(rhs/(m*acb(a(m)/2,-2*a(k))))
    return co


def odd_horizon_seed(L,ell,k,h,order):
    if order<8:raise ValueError('At least eight horizon coefficients required')
    co=odd_horizon_coefficients(L,ell,k,order)
    MU=a(Q(ell*(ell+1),1))/a(Q(3,2))**2+6/a(Q(3,2))**3
    if not MU/64+a(Q(1,3))<1:raise ArithmeticError('Odd horizon majorant not admitted')
    K=L.maxpoint(*[co[j].abs_upper()/2**j for j in range(8)])
    q=a(2*h)
    if not q<1:raise ValueError('Horizon seed outside majorant domain')
    eps=K*q**(order+1)/(1-q)
    deps=K/a(h)*q**(order+1)*((order+1)-order*q)/(1-q)**2
    carrier=acb(0,-a(k)*L.x(2+h)).exp()
    F=L.evaluate(co,a(h));Fr=L.evaluate(L.derivative(co),a(h))
    y=carrier*F;yr=carrier*(Fr-acb(0,a(k))*F/L.f(2+h))
    seed=(L.complex_error(y,eps,eps),L.complex_error(yr,deps+a(k)*eps/L.f(2+h),deps+a(k)*eps/L.f(2+h)))
    return seed,dict(F_tail=str(eps),F_r_tail=str(deps),majorant_K=str(K),majorant_MU=str(MU),order=order), (y,yr)


def odd_infinity_polys(ell,k):
    return list(map(acb,[0,0,1,-2])),[acb(0,-2*a(k)),acb(2),acb(-6)],list(map(acb,[-ell*(ell+1),6]))


def odd_infinity_seed(L,ell,k,r,order):
    p,q,s=odd_infinity_polys(ell,k);co=[acb(1)]
    for m in range(order):
        rhs=acb(0)
        for j in range(2,min(len(p)-1,m)+1):
            v=m-j+2;rhs+=p[j]*v*(v-1)*co[v]
        for j in range(1,min(len(q)-1,m)+1):
            v=m-j+1;rhs+=q[j]*v*co[v]
        for j in range(min(len(s)-1,m)+1):rhs+=s[j]*co[m-j]
        co.append(-rhs/(q[0]*(m+1)))
    residual=L.padd(L.pmul(p,L.derivative(L.derivative(co))),L.pmul(q,L.derivative(co)),L.pmul(s,co))
    R,kk=a(r),a(k)
    CV=ell*(ell+1)/R-3/R**2
    CR=sum(v.abs_upper()/((m+1)*R**(m+1)) for m,v in enumerate(residual))
    eta=CV/kk
    if not (CV>0 and eta<1):raise ArithmeticError('Odd Volterra contraction failed')
    eps=CR/(kk*(1-eta));epsx=CR+CV*eps
    G=L.evaluate(co,1/R);Gr=-L.evaluate(L.derivative(co),1/R)/R**2
    carrier=acb(0,kk*L.x(r)).exp();y=carrier*G;yr=carrier*(Gr+acb(0,kk)*G/L.f(r))
    seed=(L.complex_error(y,eps,eps),L.complex_error(yr,epsx/L.f(r),epsx/L.f(r)))
    return seed,dict(y_tail=str(eps),y_x_tail=str(epsx),residual_L1=str(CR),potential_L1=str(CV),eta=str(eta),order=order),(y,yr),co


def instrument(parity):
    if parity not in ('E','O'):raise ValueError('Unqualified parity')
    L=module('pilot_linear_'+parity,bound_path('even_core'))
    L.CASES={key:(record['ell'],Q(record['k'])) for key,record in CASE['wave_cases'].items()}
    L.SETTINGS={key:{name:Q(value) if name=='h' else value for name,value in record.items()}
                for key,record in CASE['wave_levels'].items()}
    if parity=='O':
        L.u=lambda r,ell:ell*(ell+1)/a(r)**2-6/a(r)**3
        L.radial_polys=lambda ell,k,flat=False:odd_polys(L,ell,k,flat)
        L.disk=lambda r,ell,k,flat=False:odd_disk(L,r,ell,k,flat)
        L.horizon_coefficients=lambda ell,k,order:odd_horizon_coefficients(L,ell,k,order)
        L.horizon_seed=lambda ell,k,h,order:odd_horizon_seed(L,ell,k,h,order)
        L.infinity_polys=odd_infinity_polys
        L.infinity_seed=lambda ell,k,r,order:odd_infinity_seed(L,ell,k,r,order)
    original=L.solve
    def solve(case,level,resource=lambda:None):
        if case not in CASE['wave_cases'] or CASE['wave_cases'][case]['parity']!=parity or level not in L.SETTINGS:
            raise ValueError('Unqualified wave case or parity')
        return original(case,level,resource)
    L.solve=solve
    return L


def coefficients(L,state,center,ell,k,through):
    p,q,s=[L.shifted(v,center) for v in L.radial_polys(ell,k)]
    co=list(state)
    for m in range(through-1):
        total=acb(0)
        for j in range(1,min(len(p)-1,m)+1):
            v=m-j+2;total+=p[j]*v*(v-1)*co[v]
        for j in range(min(len(q)-1,m)+1):
            v=m-j+1;total+=q[j]*v*co[v]
        for j in range(min(len(s)-1,m)+1):total+=s[j]*co[m-j]
        co.append(-total/(p[0]*(m+2)*(m+1)))
    return co
