"""Same exact rational disks, using qualified FLINT polynomial shifts."""
from fractions import Fraction as Q
from flint import arb,fmpq,fmpq_poly
from rational import Ratio as NativeRatio
from bridge import a

class Ratio(NativeRatio):
    def __init__(self,n,d):
        super().__init__(n,d)
        self.npolys=[fmpq_poly([fmpq(str(getattr(v,p))) for v in self.n]) for p in ('r','i')]
        self.fpolys=[(fmpq_poly([fmpq(str(v.r)) for v in co]),count) for co,count in self.factors]
    def bound(self,center,rho):
        if type(center) not in (int,Q) or type(rho) not in (int,Q) or rho<=0:raise ValueError('Exact disk required')
        rr=a(rho);shift=fmpq_poly([fmpq(str(center)),1])
        def positive(coeff):
            out=arb(0)
            for v in reversed(coeff):out=out*rr+arb(str(abs(v)))
            return out
        # The coefficient complex modulus is <= |Re|+|Im|.
        top=sum((positive(poly(shift).coeffs()) for poly in self.npolys),arb(0))
        bottom=a(abs(self.unit))
        for poly,count in self.fpolys:
            co=poly(shift).coeffs();lower=arb(str(abs(co[0])))-rr*positive(co[1:])
            if not lower>0:raise ValueError('Disk cannot exclude a rational pole')
            bottom*=lower**count
        return (top/bottom).upper()
