"""Compile the published nonlinear source independently of the strain response."""

import argparse
from fractions import Fraction
from hashlib import sha256
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
SCATTERING = HERE.parent
ANGULAR = SCATTERING / "second-polarization-angular-20261117"
sys.path[:0] = [
    str(SCATTERING / "global-integration-pilot-20261115"),
    str(SCATTERING / "quadrupole-w3o8-20261117/integral"),
    str(ANGULAR / "published-mixtures-20261123"),
]

from verify_mixtures import compare_even_even
from angular_algebra import Frame, ell, f, k, potential, quadratic, r as radial
from compare import compare_odd_odd, require
from compare_mixed import compare_even_odd
from common import GQ
from disks import Ratio

PARENT, DAUGHTER = 4, 8
OMEGA = Fraction(1, 2)
PUBLISHED_REVISION = "5831ae75e20b31489ef2034c8bbb13a53c5d4a3d"


def fixed_ratio(row):
    """Specialize ell and k exactly; retain the ordinary radial variable."""
    def polynomial(poly):
        coefficients = [GQ() for _ in range(int(poly.degrees()[0])+1)]
        for powers, value in poly.terms():
            require(not any(p for i, p in enumerate(powers) if i not in (0, 2, 9)),
                    "The radial source retained a field or angular variable.")
            factor = Fraction(str(value))*PARENT**int(powers[9])
            coefficients[int(powers[0])] += GQ(factor)*GQ(0, OMEGA)**int(powers[2])
        return coefficients or [GQ()]
    return Ratio(polynomial(row.n), polynomial(row.d))


def horizon_pole(ratio):
    return sum(count for coefficients, count in ratio.factors
               if len(coefficients) == 2 and coefficients[0].r+2*coefficients[1].r == 0)


def prepare_kernels(rows):
    r = tuple(map(fixed_ratio, rows))
    # For the horizon envelope H, dJ/dr = exp(-kx)*(H'-kH/f).
    a, b, c = rows
    density = ((a-k*b/f+(k/f)**2*c)/f, (b-2*k*c/f)/f, c/f)
    pole = max(horizon_pole(item) for item in map(fixed_ratio, density))
    h = tuple(fixed_ratio(item*(radial-2)**pole) for item in density)
    t = tuple(item.reciprocal_r2() for item in r)
    for item in h:
        item.bound(Fraction(2), Fraction(1, 32))
    for item in t:
        item.bound(Fraction(0), Fraction(1, 64))
    return pole, {label: [item.record() for item in group]
                  for label, group in (("r", r), ("horizon_density", h), ("inverse_square", t))}


def compile_source(archive):
    even_frame, odd_frame = Frame(ell), Frame(ell)
    odd_frame.ve = potential(ell)[4]
    even = compare_even_even(archive, even_frame, odd_frame)
    mixed = compare_even_odd(archive)
    odd = compare_odd_odd(archive)

    g = potential(ell)[1]
    gamma = potential(2*ell)[1]/2
    rho = (gamma+g)*(g-k)/((gamma-g)*(g+k))
    # Combine source returns, without constructing a local daughter field.
    source = even.regularized+rho*mixed.regularized+rho**2*odd.regularized
    pole, kernels = prepare_kernels(quadratic(source))
    return {
        "state": "COMPILED",
        "published_revision": PUBLISHED_REVISION,
        "parent": PARENT,
        "daughter": DAUGHTER,
        "parent_frequency": str(OMEGA),
        "odd_over_even_incident": "-4i/3",
        "horizon_density_pole_order_before_parent_substitution": pole,
        "author_source_pins": {
            name: component.report["published_file_sha256"]
            for name, component in zip(("EEE", "EOO", "OOE"), (even, mixed, odd), strict=True)
        },
        "kernels": kernels,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("archive", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    result = compile_source(args.archive.resolve())
    raw = json.dumps(result, indent=2).encode() + b"\n"
    with args.output.open("xb") as output:
        output.write(raw)
    print(json.dumps({"compiled": True, "bytes": len(raw), "sha256": sha256(raw).hexdigest()}))


if __name__ == "__main__":
    main()
