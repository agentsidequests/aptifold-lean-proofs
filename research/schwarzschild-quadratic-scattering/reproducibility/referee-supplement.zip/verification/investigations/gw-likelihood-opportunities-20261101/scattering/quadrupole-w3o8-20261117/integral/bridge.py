"""Pinned arithmetic and phase-agnostic linear routines for the new point."""
import hashlib
import json
from fractions import Fraction as F
from pathlib import Path

from flint import arb
import common as C
import quadrature as G
import tails as T
import waves as W

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[4]
CASE = json.loads((HERE / "CASE.json").read_bytes())
W.CASE = CASE
DATA = {"E2": (2, F(CASE["omega"]), "E"), "O4": (4, F(CASE["daughter_omega"]), "O")}
OMEGA = DATA["O4"][1]
a, z, GQ = C.a, C.z, C.GQ


def radius(value):
    return (value.real.rad()**2 + value.imag.rad()**2).sqrt().upper()


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def physical(name):
    spec = CASE["physical"][name]
    path = (ROOT / spec["path"]).resolve()
    if not path.is_relative_to(HERE.parent):
        raise ValueError("Independent physical source path required")
    data = path.read_bytes()
    receipt_bytes = (path.parent / "RUN.json").read_bytes()
    if sha(data) != spec["sha256"] or sha(receipt_bytes) != spec["run_sha256"]:
        raise ValueError("Changed admitted physical input: " + name)
    result = json.loads(data)
    receipt = json.loads(receipt_bytes)
    if result["state"] != "PASS" or result["mode"] != name or not all(result["body"]["checks"].values()):
        raise ValueError("Unadmitted physical input: " + name)
    if receipt["state"] != "COMPLETED" or not receipt["identity_live_bound"]:
        raise ValueError("Unbound physical input: " + name)
    return result["body"]


def saved(name):
    slot = CASE.get("receipt_slots", {}).get(name, "A")
    folder = HERE / (name + "-" + slot)
    raw = (folder / "RESULT.json").read_bytes()
    result = json.loads(raw)
    receipt = json.loads((folder / "RUN.json").read_bytes())
    if result["state"] != "PASS" or result["mode"] != name or not all(result["body"]["checks"].values()):
        raise ValueError("Unadmitted prerequisite: " + name)
    if receipt["state"] != "COMPLETED" or not receipt["identity_live_bound"] or receipt["mode"] != name:
        raise ValueError("Unbound prerequisite: " + name)
    identity = {source: sha((HERE / source).read_bytes()) for source in CASE["code_files"]}
    if result["code_sha256"] != identity or receipt["code_sha256"] != identity:
        raise ValueError("Changed frozen calculation: " + name)
    return result["body"], sha(raw)
