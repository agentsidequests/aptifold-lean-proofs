"""Bounded finite and tail integrals for the fixed ell=4 Schwarzschild check."""

from collections import defaultdict
from dataclasses import dataclass
from fractions import Fraction as F
from itertools import product

from flint import acb, acb_series, arb, ctx

from source import DAUGHTER, OMEGA, PARENT, Ratio, require
from common import GQ, a, f, with_error, x
from rational import exact_profile, mul, zero
from tails import moment
import waves

PAIRS = ((0, 0), (0, 1), (1, 1))
MODES = ((PARENT, OMEGA), (DAUGHTER, 2*OMEGA))
HORIZON_DISK = F(1, 32)
INFINITY_DISK = F(1, 64)


@dataclass(frozen=True)
class Resolution:
    h: F
    R: int
    finite_order: int
    horizon_order: int
    far_order: int
    tail_order: int
    by_parts_order: int
    bits: int


LEVELS = {
    "coarse": Resolution(F(1, 128), 128, 36, 30, 32, 44, 9, 256),
    "fine": Resolution(F(1, 256), 176, 46, 36, 44, 52, 12, 320),
}


@dataclass
class Wave:
    label: int
    rate: F
    center: tuple
    error: arb

    def metric_error(self, boxes, center, r):
        y, yr = [(v-u).abs_upper() for v, u in zip(boxes, center, strict=True)]
        return (y*y+(f(a(r))*yr/a(self.rate))**2).sqrt().upper()

    def enclose(self, r):
        y, yr = self.center
        return with_error(y, self.error), with_error(yr, self.error*a(self.rate)/f(a(r)))

    def growth(self, left, right):
        # In (y, (D_x y)/omega), the free generator is skew-Hermitian.
        # The positive potential contributes at most V/(2*omega) to
        # logarithmic energy growth. Integrate V/f <= ell*(ell+1)/r**2.
        integral = self.label*(self.label+1)*(1/left-1/right)/(2*self.rate)
        return a(integral).exp()


def midpoint(value):
    return acb(value.real.mid(), value.imag.mid())


def initial_wave(L, label, rate, settings):
    boxes, proof, _ = L.horizon_seed(label, rate, settings.h, settings.horizon_order)
    center = tuple(map(midpoint, boxes))
    wave = Wave(label, rate, center, arb(0))
    wave.error = wave.metric_error(boxes, center, 2+settings.h)
    return wave, proof


def row_values(rows, r, left, right):
    return sum((q.eval(r)*left[i]*right[j] for q, (i, j) in zip(rows, PAIRS, strict=True)), acb(0))


def product_error(magnitudes, errors):
    base, expanded = arb(1), arb(1)
    for value, error in zip(magnitudes, errors, strict=True):
        base *= value
        expanded *= value+error
    return (expanded-base).upper()


def advance(L, wave, left, step, order, disk):
    """Local Taylor coefficients and center error for an odd radial wave."""
    scale, _, norm = disk
    previous = wave.center
    coefficients = waves.coefficients(L, previous, left, wave.label, wave.rate, order+1)
    y, yr = previous
    M = (L.maxpoint(y.abs_upper(), a(scale)*yr.abs_upper())*(norm*a(disk[1])).exp()).upper()
    delta = a(step)
    value = L.evaluate(coefficients[:order+1], delta)
    derivative = L.evaluate(L.derivative(coefficients), delta)
    end = tuple(map(midpoint, (value, derivative)))
    ratio = a(step/disk[1])
    truncation = M*ratio**(order+1)/(1-ratio)
    right = left+step
    local = truncation*(1+(f(a(right))/(a(wave.rate)*a(scale)))**2).sqrt()
    old_error = (wave.error*wave.growth(left, right)).upper()
    wave.error = (old_error+local+wave.metric_error((value, derivative), end, right)).upper()
    wave.center = end
    solution = acb_series(coefficients, prec=order+2)
    return (solution, solution.derivative()), (M, (M/a(scale)).upper()), (
        old_error, (old_error*a(wave.rate)/f(a(left))).upper(),
    )


def finite_integrals(L, settings, radial, states):
    """Simultaneous finite Green quadrature, with separate source controls."""
    order = settings.finite_order
    ctx.cap = order+3
    total = [acb(0) for _ in radial]
    errors = [arb(0) for _ in radial]
    left, right = 2+settings.h, F(settings.R)
    first, panels = left, 0
    flux_checks = {}
    while left < right:
        disks = [L.disk(left, wave.label, wave.rate) for wave in states]
        radius = min(disk[1] for disk in disks)
        for _ in range(32):
            try:
                K = [[item.bound(left, radius) for item in group] for group in radial]
                break
            except ValueError:
                radius /= 2
        else:
            raise ArithmeticError("Could not exclude a source pole on a finite panel.")
        step = min(radius/4, right-left)
        rr = acb_series([a(left), 1], prec=order+3)
        parent, daughter = (advance(L, wave, left, step, order, disk)
                            for wave, disk in zip(states, disks, strict=True))
        pjet, pbound, perror = parent
        djet, dbound, derror = daughter
        J = a(left+radius)/a(left-2-radius)
        ratio = a(step/radius)
        tail_scale = a(step)*ratio**(order+1)/((order+2)*(1-ratio))
        old_scales = [product_error((dbound[0], pbound[i], pbound[j]),
                                    (derror[0], perror[i], perror[j])) for i, j in PAIRS]
        powers = [a(step)**(j+1)/(j+1) for j in range(order+1)]
        for index, (group, bounds) in enumerate(zip(radial, K, strict=True)):
            density = djet[0]*row_values(group, rr, pjet, pjet)/(1-2/rr)
            require(density.prec >= order+1, "Finite Taylor precision was lost.")
            total[index] += sum((density[n]*p for n, p in enumerate(powers)), acb(0))
            analytic = dbound[0]*sum((u*pbound[i]*pbound[j]
                                      for u, (i, j) in zip(bounds, PAIRS, strict=True)), arb(0))
            incoming = sum((u*e for u, e in zip(bounds, old_scales, strict=True)), arb(0))
            errors[index] += analytic*J*tail_scale+incoming*a(step)/f(a(left))
        left += step
        panels += 1
        if panels == 1 or left == right or left-first >= 16:
            first = left
            for wave in states:
                observed = L.flux(wave.enclose(left), left)
                require((observed+a(wave.rate)).contains(0), "Horizon flux was lost on a finite panel.")
                flux_checks[wave.label] = max(flux_checks.get(wave.label, arb(0)),
                                              (observed+a(wave.rate)).abs_upper())
    return [with_error(value, error) for value, error in zip(total, errors, strict=True)], {
        "panels": panels,
        "integral_error_before_normalization": [str(v.upper()) for v in errors],
        "max_flux_difference": {str(label): str(error) for label, error in flux_checks.items()},
        "outgoing_panel_energy_errors": [str(wave.error) for wave in states],
    }


def horizon_tail(L, group, pole, settings, seed_proofs):
    """Integrate the horizon carrier and an analytic envelope in h=r-2."""
    if pole:
        P = exact_profile("O", PARENT, OMEGA, pole)
        jets = (P, [j*P[j] for j in range(1, pole+1)])
        dense = [GQ() for _ in range(pole)]
        for item, (i, j) in zip(group, PAIRS, strict=True):
            term = mul(item.exact_series(F(2), pole-1), mul(jets[i], jets[j], pole-1), pole-1)
            dense = [v+w for v, w in zip(dense, term, strict=True)]
        require(all(map(zero, dense)), "An exact pole survives in the ingoing source density.")

    end = settings.horizon_order+pole
    ctx.cap = end+4
    t = acb_series([0, 1], prec=end+4)
    profiles = [acb_series(L.horizon_coefficients(label, freq, end+1), prec=end+2)
                for label, freq in MODES]
    p, d = profiles
    q = -4*OMEGA
    jets = (p, p.derivative())
    series = d*row_values(group, 2+t, jets, jets)*(acb(0, a(q))*t).exp()
    require(series.prec >= end+1, "Horizon Taylor precision was lost.")
    h = a(settings.h)
    carrier = acb(0, a(q)*(2+2*(h/2).log())).exp()
    value = carrier*sum((series[j]*h**(j-pole+1)/acb(j-pole+1, 2*a(q))
                         for j in range(pole, end+1)), acb(0))
    rho = a(HORIZON_DISK)
    radii = [arb(row["majorant_K"]).upper()/(1-2*rho) for row in seed_proofs]
    p_bounds = (radii[0], 2*radii[0]/(1-2*rho))
    bound = radii[1]*(abs(a(q))*rho).exp()*sum(
        (row.bound(F(2), HORIZON_DISK)*p_bounds[i]*p_bounds[j]
         for row, (i, j) in zip(group, PAIRS, strict=True)), arb(0),
    )
    ratio = h/rho
    error = bound/rho**pole*h*ratio**(settings.horizon_order+1)/(
        (settings.horizon_order+2)*(1-ratio)
    )
    return with_error(value, error), {"absolute_remainder": str(error.upper()), "exact_pole_zeros": pole}


def asymptotic_wave(L, wave, settings):
    R = settings.R
    frequency = wave.rate
    outgoing, certificate, _, coefficients = L.infinity_seed(wave.label, frequency, R, settings.far_order)
    incoming = tuple(map(L.conjugate, outgoing))
    H = wave.enclose(F(R))
    twice = acb(0, 2*a(frequency))
    require((L.wronskian(incoming, outgoing, R)-twice).contains(0), "Jost Wronskian mismatch.")
    A_in = L.wronskian(H, outgoing, R)/twice
    A_out = L.wronskian(incoming, H, R)/twice
    require(not A_in.contains(0), "Incident wave amplitude is unresolved.")
    reflection = A_out/A_in
    transmission = 1/A_in
    balance = reflection*L.conjugate(reflection)+transmission*L.conjugate(transmission)-1
    require(balance.contains(0) and balance.abs_upper() < arb("1e-8"), "Linear flux balance failed.")
    amps = {-1: A_in, 1: A_out}
    polynomials = {-1: [L.conjugate(c) for c in coefficients], 1: coefficients}

    def profile_bound(t):
        value = sum((c.abs_upper()*t**n for n, c in enumerate(coefficients)), arb(0))
        derivative = sum((n*c.abs_upper()*t**(n+1) for n, c in enumerate(coefficients) if n), arb(0))
        return value, (a(frequency)*value/(1-2*t)+derivative).upper()

    mass = sum((v.abs_upper() for v in amps.values()), arb(0))
    real_bound = tuple((mass*b).upper() for b in profile_bound(1/a(R)))
    y_error = arb(certificate["y_tail"]).upper()
    yr_error = arb(certificate["y_x_tail"]).upper()/f(a(R))
    errors = ((mass*y_error).upper(), (mass*yr_error).upper())
    return amps, polynomials, real_bound, errors, profile_bound(a(INFINITY_DISK)), certificate, balance


def infinity_tail(group, far_waves, settings):
    ctx.cap = settings.tail_order+4
    t = acb_series([0, 1], prec=ctx.cap)
    series = []
    for (_, rate), (_, profiles, *_rest) in zip(MODES, far_waves, strict=True):
        phases = {}
        for sign, coefficients in profiles.items():
            p = acb_series(coefficients, prec=ctx.cap)
            phases[sign] = (p, acb(0, sign*a(rate))*p/(1-2*t)-t*t*p.derivative())
        series.append(phases)
    R, tau = settings.R, INFINITY_DISK
    moments = {n: moment(n, R).upper() for n in range(2, settings.tail_order+3+2*settings.by_parts_order)}
    p, d = far_waves
    amp_p, _, mag_p, err_p, disk_p, *_ = p
    amp_d, _, mag_d, err_d, disk_d, *_ = d
    uniform = disk_d[0]*sum((row.bound(F(0), tau)*disk_p[i]*disk_p[j]
                             for row, (i, j) in zip(group, PAIRS, strict=True)), arb(0))
    ratio = 1/a(R*tau)
    kernel_tail = uniform*ratio**(settings.tail_order+1)/(1-ratio)*moments[2]
    profile_tail = moments[2]*sum(
        (row.bound(F(0), F(1, R))*product_error((mag_d[0], mag_p[i], mag_p[j]),
                                                (err_d[0], err_p[i], err_p[j]))
         for row, (i, j) in zip(group, PAIRS, strict=True)), arb(0),
    )
    value, analytic_remainder, amplitude_sum = acb(0), arb(0), arb(0)
    resonant = 0
    for ds, ps, pt in product((-1, 1), repeat=3):
        q = 2*OMEGA*ds+OMEGA*(ps+pt)
        branch_amp = amp_d[ds]*amp_p[ps]*amp_p[pt]
        density = series[1][ds][0]*row_values(group, t, series[0][ps], series[0][pt])
        require(density.prec >= settings.tail_order+1, "Infinity Taylor precision was lost.")
        powers = {j+2: density[j] for j in range(settings.tail_order+1)}
        if q:
            integral, error = oscillatory_moments(powers, q, R, settings.by_parts_order, moments)
        else:
            # Use full moment enclosures for the resonant values.
            integral = sum((c*moment(n, R) for n, c in powers.items()), acb(0))
            error = arb(0)
            resonant += 1
        value += branch_amp*integral
        amplitude_sum += branch_amp.abs_upper()
        analytic_remainder += branch_amp.abs_upper()*error
    require(resonant == 2, "Unexpected number of resonant infinity branches.")
    error = amplitude_sum*kernel_tail+profile_tail+analytic_remainder
    return with_error(value, error), {
        "taylor_remainder": str((amplitude_sum*kernel_tail).upper()),
        "profile_remainder": str(profile_tail.upper()),
        "integration_by_parts_remainder": str(analytic_remainder.upper()),
        "resonant_branches": resonant,
    }


def oscillatory_moments(coeffs, frequency, R, order, moments):
    iq = acb(0, a(frequency))
    boundary = acb(0)
    for j in range(order):
        boundary += (-1)**j*sum((v/a(R)**n for n, v in coeffs.items()), acb(0))/iq**(j+1)
        derivative = defaultdict(acb)
        for power, value in coeffs.items():
            derivative[power+1] -= power*value
            derivative[power+2] += 2*power*value
        coeffs = derivative
    error = sum((v.abs_upper()*moments[n] for n, v in coeffs.items()), arb(0))/a(abs(frequency))**order
    return -((iq*x(R)).exp())*boundary, error.upper()
