"""Compute and save the direct Green integral before reading a closed response."""

import argparse
from dataclasses import asdict
from fractions import Fraction as F
from hashlib import sha256
import json
from math import factorial
from pathlib import Path

from flint import acb, arb, ctx

from source import (
    DAUGHTER, OMEGA, PARENT, PUBLISHED_REVISION, Ratio, prepare_kernels, require,
)
from angular_algebra import E, Frame, f as radial_f, k, potential, quadratic, r
from common import a, f, serialize
import green

HERE = Path(__file__).resolve().parent


def manufactured():
    frame = Frame(PARENT)
    frame.ve = potential(PARENT)[4]
    field = radial_f**3*E**2/r**2
    pole, kernels = prepare_kernels(quadratic(frame.wave(field, DAUGHTER, 2*k, "O")))
    return {"kernels": kernels, "horizon_density_pole_order_before_parent_substitution": pole}


def current(states, radius):
    radius = a(radius)
    (v, vr), (u, ur) = states
    ff = f(radius)
    factor = ff**3/radius**2
    derivative = 6*ff**2/radius**4-2*ff**3/radius**3
    return ff*(u*(derivative*v*v+2*factor*v*vr)-ur*factor*v*v)


def strain_units():
    # B_l = N_(2l) times the product-harmonic coefficient / N_l**2.
    # N_l is the paper's linear strain-to-master coefficient.
    label = PARENT
    parent_squared = arb(factorial(label+2))/(4*factorial(label-2))
    daughter = (arb(factorial(2*label+2))/factorial(2*label-2)).sqrt()/2
    harmonic = (arb(factorial(2*label+1)*factorial(2*label))
                / (factorial(label)**2*(4*arb.pi()*factorial(4*label+1)).sqrt()))
    return daughter*harmonic/parent_squared


def record_hashes():
    return {file: sha256((HERE/file).read_bytes()).hexdigest()
            for file in ("source.py", "green.py", "direct.py")}


def calculate(raw, level):
    settings = green.LEVELS[level]
    ctx.prec = settings.bits
    source = json.loads(raw)
    require(
        (source["state"], source["parent"], source["daughter"], source["parent_frequency"],
         source["published_revision"], source["odd_over_even_incident"])
        == ("COMPILED", PARENT, DAUGHTER, str(OMEGA), PUBLISHED_REVISION, "-4i/3"),
        "The source does not describe the fixed physical test."
    )
    inputs = (source, manufactured())
    data = [{label: tuple(map(Ratio.restore, rows)) for label, rows in q["kernels"].items()}
            for q in inputs]
    poles = [q["horizon_density_pole_order_before_parent_substitution"] for q in inputs]

    L = green.waves.instrument("O")
    waves, seed_proofs = zip(*(green.initial_wave(L, label, rate, settings)
                               for label, rate in green.MODES), strict=True)
    h_left, r_far = 2+settings.h, F(settings.R)
    left_current = current([wave.enclose(h_left) for wave in waves], h_left)
    near = [green.horizon_tail(L, q["horizon_density"], pole, settings, seed_proofs)
            for q, pole in zip(data, poles, strict=True)]
    require((near[1][0]-left_current).contains(0), "Manufactured horizon current mismatch.")
    finite, finite_report = green.finite_integrals(L, settings, [q["r"] for q in data], waves)

    right_current = current([wave.enclose(r_far) for wave in waves], r_far)
    far_waves = [green.asymptotic_wave(L, wave, settings) for wave in waves]
    far = [green.infinity_tail(q["inverse_square"], far_waves, settings) for q in data]

    (parent_amps, *_), (daughter_amps, *_) = far_waves
    g, rate = arb(30), acb(0, a(OMEGA))
    alpha = (g+rate)/(g-rate)
    # The reference odd wave has incident amplitude alpha for a unit
    # even incident wave. The selected physical iO/E incidence is 4/3.
    parent_scale = alpha/parent_amps[-1]
    incident_spin_factor = 1+a(F(4, 3))
    normalizer = strain_units()*(parent_scale/incident_spin_factor)**2/(4*rate*daughter_amps[-1])
    contributions = [near[0][0], finite[0], far[0][0]]
    target = normalizer*sum(contributions, acb(0))
    control_deltas = (
        near[1][0]-left_current, finite[1]-(right_current-left_current), far[1][0]+right_current,
    )
    require(all(delta.contains(0) and (delta*normalizer).abs_upper() < arb("1e-9")
                for delta in control_deltas), "Manufactured Green pieces fail endpoint currents.")
    require(target.is_finite() and target.rad() < arb("1e-10"), "Direct enclosure too wide for admission.")
    return {
        "state": "PASS",
        "method": "direct integration of the published regularized quadratic source",
        "source_sha256": sha256(raw).hexdigest(),
        "input_code_sha256": record_hashes(),
        "level": level,
        "settings": {name: str(value) for name, value in asdict(settings).items()},
        "closed_response_used": False,
        "strain": serialize(target),
        "strain_radius": str(target.rad()),
        "raw_integral": serialize(sum(contributions, acb(0))),
        "parts": {name: serialize(normalizer*value)
                  for name, value in zip(("horizon", "finite", "infinity"), contributions, strict=True)},
        "linear": {
            str(label): {
                "A_in": serialize(amps[-1]),
                "A_out": serialize(amps[1]),
                "flux_balance_difference": str(balance.abs_upper()),
                "volterra": proof,
            }
            for (label, _), (amps, _, _, _, _, proof, balance) in zip(green.MODES, far_waves, strict=True)
        },
        "remainder_ledger": {
            "horizon": near[0][1], "finite": finite_report, "infinity": far[0][1],
        },
        "manufactured_current_absolute_differences": {
            name: str((normalizer*delta).abs_upper())
            for name, delta in zip(("horizon", "finite", "infinity"), control_deltas, strict=True)
        },
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("level", choices=green.LEVELS)
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    raw = json.dumps(calculate(args.source.read_bytes(), args.level), indent=2).encode()+b"\n"
    with args.output.open("xb") as output:
        output.write(raw)
    print(json.dumps({"level": args.level, "bytes": len(raw), "sha256": sha256(raw).hexdigest()}))


if __name__ == "__main__":
    main()
