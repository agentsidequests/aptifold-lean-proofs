"""Cauchy-bounded Taylor quadrature, including the r-to-x Jacobian."""
from fractions import Fraction as Q
from flint import arb,acb,acb_series,ctx
from common import a,z,x,f,with_error,potential,umax
from waves import coefficients


def polynomial_integral(series,h,order):
    if series.prec<order+1:raise ArithmeticError('Insufficient finite jet precision')
    return sum((2*series[n]*a(h)**(n+1)/(n+1) for n in range(0,order+1,2)),acb(0))


def cauchy_error(M,h,radius,order):
    if h<=0 or radius<=h:raise ValueError('Strict Cauchy disk fraction required')
    ratio=a(h/radius)
    if not ratio<=arb('1/4'):raise ValueError('Unqualified Cauchy step')
    return 2*M*a(h)/(order+2)*ratio**(order+1)/(1-ratio)


def finite_branch(B,q,left,right,order,resource=lambda:None):
    if type(q) not in (int,Q) or not Q(2)<left<right:raise ValueError('Qualified finite branch interval required')
    pos=Q(left);total=acb(0);error=arb(0);steps=0;maxM=arb(0)
    prior=ctx.cap
    try:
        ctx.cap=order+4
        while pos<right:
            h=min((pos-2)/8,Q(2),(right-pos)/2);center=pos+h;radius=4*h
            rr=acb_series([a(center),1],prec=order+4)
            xx=rr+2*(rr/2-1).log()
            phase=(acb(0,a(q))*xx).exp() if q else acb_series([1],prec=order+4)
            density=phase*B.series(rr)/(1-2/rr)
            total+=polynomial_integral(density,h,order)
            log_bound=a(radius)-2*(1-a(radius/(center-2))).log()
            M=(a(abs(q))*log_bound).exp()*B.bound(center-radius)*a(center+radius)/a(center-2-radius)
            error+=cauchy_error(M,h,radius,order);maxM=max(maxM,M.upper())
            pos+=2*h;steps+=1
            if steps%8==0:resource()
    finally:ctx.cap=prior
    return with_error(total,error),dict(steps=steps,remainder=str(error),largest_disk_bound=str(maxM),order=order)


def propagate(L,T,start,end,ell,k,order,resource):
    pos=start;steps=0
    while pos!=end:
        _,radius,_=L.disk(pos,ell,k)
        step=min(radius/4,abs(end-pos))*(1 if end>pos else -1)
        T,_=L.taylor_step(T,pos,step,ell,k,order)
        pos+=step;steps+=1
        if steps%8==0:resource()
    return T,steps


def coupled_current(states,r):
    e,er=states['E2'];o,orr=states['O2'];u,ur=states['O4']
    rr=a(r);ff=1-2/rr;fp=2/rr**2
    phi=ff*ff/rr**2;phir=2*ff*fp/rr**2-2*ff*ff/rr**3
    field=phi*e*o;fieldr=phir*e*o+phi*(er*o+e*orr)
    return ff*(u*fieldr-ur*field)


def coupled(wave_records,level,resource=lambda:None):
    from common import CASE,decode
    from waves import instrument
    setting=CASE['coupled_levels'][level];left=Q(setting['left']);right=Q(setting['right']);order=setting['order']
    info={};flow_order=CASE['wave_levels'][level]['order'];steps_flow=0
    for key in ('E2','O2','O4'):
        record=wave_records[key];definition=CASE['wave_cases'][key]
        if record['state']!='PASS' or record['case']!=key or record['level']!=level:raise ValueError('Wrong wave receipt')
        L=instrument(definition['parity']);ell=definition['ell'];k=Q(definition['k'])
        ws=CASE['wave_levels'][level];rh=Q(2)+Q(ws['h'])
        seed=L.horizon_seed(ell,k,Q(ws['h']),ws['h_order'])[0]
        divisor=decode(record['values']['Ain']) if key!='O4' else acb(1)
        if divisor.contains(0):raise ValueError('Unresolved parent normalization')
        seed=tuple(v/divisor for v in seed)
        T=[(arb(1),arb(0)),(arb(0),arb(1))]
        T,count=propagate(L,T,rh,left,ell,k,flow_order,resource);steps_flow+=count
        info[key]=dict(L=L,ell=ell,k=k,T=T,pos=left,seed=seed)
    def advance(target):
        nonlocal steps_flow
        result={}
        for key,item in info.items():
            item['T'],count=propagate(item['L'],item['T'],item['pos'],target,item['ell'],item['k'],flow_order,resource)
            steps_flow+=count;item['pos']=target
            result[key]=item['L'].apply(item['T'],item['seed'])
        return result
    start_states=advance(left);current_left=coupled_current(start_states,left)
    total=acb(0);error=arb(0);pos=left;cells=0;largestM=arb(0)
    prior=ctx.cap
    try:
        ctx.cap=order+4
        while pos<right:
            proposed=min(info[key]['L'].disk(pos,item['ell'],item['k'])[1] for key,item in info.items())
            h=min(proposed/8,(right-pos)/2)
            while True:
                center=pos+h;disks={key:item['L'].disk(center,item['ell'],item['k']) for key,item in info.items()}
                radius=min(value[1] for value in disks.values())
                if h<=radius/4:break
                h/=2
            states=advance(center)
            series={};bounds={}
            for key,item in info.items():
                co=coefficients(item['L'],states[key],center,item['ell'],item['k'],order+2)
                y=acb_series(co,prec=order+3);yr=y.derivative()
                series[key]=(y,yr)
                S,_,norm=disks[key]
                M=max(states[key][0].abs_upper(),a(S)*states[key][1].abs_upper())*(norm*a(radius)).exp()
                bounds[key]=(M,M/a(S))
            rr=acb_series([a(center),1],prec=order+4);ff=1-2/rr;fp=2/rr**2
            phi=ff*ff/rr**2;phir=phi.derivative();phirr=phir.derivative()
            w=a(Q(1,4))
            A=ff*ff*phirr+ff*fp*phir+phi*(potential(rr,2,'E')+potential(rr,2,'O')+2*w*w-potential(rr,4,'O'))
            B=2*ff*ff*phir;C=2*ff*ff*phi
            e,er=series['E2'];o,orr=series['O2'];u=series['O4'][0]
            density=u*(A*e*o+B*(er*o+e*orr)+C*er*orr)/ff
            total+=polynomial_integral(density,h,order)
            rm=a(center-radius);Fmax=1+2/rm;Fp=2/rm**2;Fpp=4/rm**3
            p0=Fmax**2/rm**2
            p1=2*Fmax*Fp/rm**2+2*Fmax**2/rm**3
            p2=2*(Fp**2+Fmax*Fpp)/rm**2+8*Fmax*Fp/rm**3+6*Fmax**2/rm**4
            Vsum=Fmax*(umax(center,radius,2,'E')+umax(center,radius,2,'O')+umax(center,radius,4,'O'))
            Amax=Fmax**2*p2+Fmax*Fp*p1+p0*(Vsum+2*w*w)
            Bmax=2*Fmax**2*p1;Cmax=2*Fmax**2*p0
            E,Er=bounds['E2'];O,Or=bounds['O2'];U=bounds['O4'][0]
            invf=a(center+radius)/a(center-2-radius)
            M=U*invf*(Amax*E*O+Bmax*(Er*O+E*Or)+Cmax*Er*Or)
            error+=cauchy_error(M,h,radius,order);largestM=max(largestM,M.upper())
            pos+=2*h;cells+=1;resource()
    finally:ctx.cap=prior
    end_states=advance(right);current_right=coupled_current(end_states,right)
    middle=with_error(total,error)
    horizon=current_left;infinity=-current_right
    whole=horizon+middle+infinity
    residual=middle-(current_right-current_left)
    return dict(parts={'horizon':horizon,'finite':middle,'infinity':infinity,'total':whole},
                residual=residual,current_left=current_left,current_right=current_right,
                metrics=dict(cells=cells,wave_flow_steps=steps_flow,remainder=str(error),largest_disk_bound=str(largestM)),
                scope='MANUFACTURED L4[phi*E*O], with native-wave current tail oracles; not the Einstein source')
