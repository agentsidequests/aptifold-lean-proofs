"""Certified finite Laurent branch tails for manufactured controls."""
from fractions import Fraction as Q
from flint import arb,acb,acb_series,ctx
from common import GQ,a,z,x,nonnegative,with_error


def exact(value):
    if isinstance(value,GQ):return value
    if type(value) in (int,Q):return GQ(value)
    raise TypeError('Exact rational complex Laurent coefficient required')


def zero(value):return value.r==0 and value.i==0


class Laurent:
    def __init__(self,terms=None):
        self.c={}
        for n,value in (terms or {}).items():
            if type(n) is not int or not 0<=n<=512:raise ValueError('Bounded nonnegative Laurent power required')
            value=exact(value)
            if not zero(value):self.c[n]=value

    def __add__(self,other):
        other=other if isinstance(other,Laurent) else Laurent({0:other})
        terms=dict(self.c)
        for n,v in other.c.items():terms[n]=terms.get(n,GQ())+v
        return Laurent(terms)
    __radd__=__add__
    def __neg__(self):return Laurent({n:-v for n,v in self.c.items()})
    def __sub__(self,other):return self+(-other if isinstance(other,Laurent) else -exact(other))
    def __rsub__(self,other):return -self+other
    def __mul__(self,other):
        other=other if isinstance(other,Laurent) else Laurent({0:other})
        terms={}
        for n,v in self.c.items():
            for m,w in other.c.items():terms[n+m]=terms.get(n+m,GQ())+v*w
        return Laurent(terms)
    __rmul__=__mul__

    def D(self):
        terms={}
        for n,v in self.c.items():
            if n:
                terms[n+1]=terms.get(n+1,GQ())-n*v
                terms[n+2]=terms.get(n+2,GQ())+2*n*v
        return Laurent(terms)

    def value(self,r):
        rr=a(r)
        return sum((z(v)/rr**n for n,v in self.c.items()),acb(0))

    def series(self,r):
        return sum((z(v)/r**n for n,v in self.c.items()),acb_series([0]))

    def bound(self,rmin):
        rr=a(rmin)
        if not rr>0:raise ValueError('Laurent disk reaches zero')
        return sum((z(v).abs_upper()/rr**n for n,v in self.c.items()),arb(0))

    def divide_f(self):
        if not self.c:return Laurent()
        N=max(self.c)
        if N==0:raise ValueError('Horizon pole cannot be canceled')
        p=[GQ() for _ in range(N+1)]
        for n,v in self.c.items():p[N-n]=v
        quotient=[GQ() for _ in range(N)]
        carry=p[N];quotient[N-1]=carry
        for j in range(N-1,0,-1):
            carry=p[j]+2*carry;quotient[j-1]=carry
        if not zero(p[0]+2*carry):raise ValueError('Exact B(2)=0 required for the horizon tail')
        return Laurent({N-1-j:v for j,v in enumerate(quotient)})


def moment(n,R,terms=64):
    if type(n) is not int or n<2 or type(R) not in (int,Q) or R<=2:
        raise ValueError('Convergent infinity moment required')
    rr=a(R);ratio=2/rr
    total=sum((ratio**j/(n+j-1) for j in range(terms)),arb(0))*rr**(1-n)
    error=rr**(1-n)*ratio**terms/((n+terms-1)*(1-ratio))
    return total+arb(0,error.upper())


def nonresonant_tail(B,q,R,order,*,residual_l1):
    if type(q) not in (int,Q) or q==0:raise ValueError('Nonzero exact real branch frequency required')
    if not 1<=order<=24 or any(n<2 for n in B.c):raise ValueError('Unqualified tail order or decay')
    residual=nonnegative(residual_l1)
    iq=acb(0,a(q));partial=acb(0);current=B
    for j in range(order):
        partial+=(-1)**j*current.value(R)/iq**(j+1)
        current=current.D()
    error=sum((z(v).abs_upper()*moment(n,R).upper() for n,v in current.c.items()),arb(0))/a(abs(q))**order
    value=-acb(0,a(q)*x(R)).exp()*partial
    return with_error(value,error+residual),dict(remainder=str(error),residual_L1=str(residual),ibp_order=order,branch=str(q))


def infinity(B,q,R,order,*,residual_l1):
    if type(q) not in (int,Q) or any(n<2 for n in B.c):raise ValueError('Exact frequency and integrable Laurent tail required')
    if q:return nonresonant_tail(B,q,R,order,residual_l1=residual_l1)
    value=sum((z(v)*moment(n,R) for n,v in B.c.items()),acb(0))
    return with_error(value,nonnegative(residual_l1)),dict(branch='0',method='positive resonant moments',residual_L1=str(nonnegative(residual_l1)))


def horizon(B,q,h,order):
    if type(q) not in (int,Q) or type(h) not in (int,Q) or not 0<h<Q(1,2):
        raise ValueError('Exact real frequency and h inside the horizon disk required')
    density=B.divide_f();radius=Q(1,2)
    prior=ctx.cap
    try:
        ctx.cap=order+3
        t=acb_series([0,1],prec=order+3)
        series=density.series(2+t)*(acb(0,a(q))*t).exp()
        if series.prec<order+1:raise ArithmeticError('Horizon series precision lost')
        value=sum((series[n]*a(h)**(n+1)/acb(n+1,2*a(q)) for n in range(order+1)),acb(0))
    finally:ctx.cap=prior
    carrier=acb(0,a(q)*(2+2*(a(h)/2).log())).exp()
    bound=density.bound(Q(2)-radius)*(a(abs(q))*a(radius)).exp()
    ratio=a(h/radius)
    error=bound*a(h)*ratio**(order+1)/(1-ratio)
    return with_error(carrier*value,error),dict(remainder=str(error),disk_bound=str(bound),order=order,branch=str(q))


def free_source(k=Q(1,2)):
    ff=Laurent({0:1,1:-2});g=ff*ff;h=Laurent({3:GQ(Q(24,7),Q(8,7))})
    ik=GQ(0,k)
    B0=g.D().D()+g.D()*(2*ik)
    B1=h.D().D()-h.D()*(2*ik)
    return g,h,((Q(0),B0),(-2*k,B1))


def free_current(r,k=Q(1,2)):
    g,h,_=free_source(k)
    return acb(0,2*a(k))*g.value(r)+g.D().value(r)+acb(0,-2*a(k)*x(r)).exp()*h.D().value(r)
