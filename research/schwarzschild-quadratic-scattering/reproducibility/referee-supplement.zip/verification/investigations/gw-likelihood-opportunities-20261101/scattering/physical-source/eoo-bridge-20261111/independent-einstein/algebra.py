"""Small exact rational-function layer over the existing FLINT polynomial ring."""
from flint import fmpq, fmpq_mpoly, fmpq_mpoly_ctx

CTX = fmpq_mpoly_ctx.get(("r","u","w","E","Er","O","Or","I"),"lex")
GENS = CTX.gens()
IMOD = GENS[7]**2+1


def poly(value):
    return value if isinstance(value,fmpq_mpoly) else CTX.constant(value)


def divide_exact(a,b):
    q,rem = divmod(a,b)
    if rem != 0:
        raise ArithmeticError("Nonexact polynomial cancellation")
    return q


class RF:
    __slots__ = ("n","d")

    def __init__(self,n=0,d=1):
        if isinstance(n,RF):
            if d != 1:
                raise ValueError("Ambiguous rational-function constructor")
            self.n,self.d = n.n,n.d
            return
        n,d = poly(n)%IMOD,poly(d)%IMOD
        if d == 0:
            raise ZeroDivisionError()
        if d.degrees()[7] > 0:
            conjugate = d.compose(*GENS[:7],-GENS[7])%IMOD
            n,d = (n*conjugate)%IMOD,(d*conjugate)%IMOD
        if any(v > 0 for v in d.degrees()[3:7]) or d.degrees()[7] > 0:
            raise ValueError("Field-dependent or complex denominator is inadmissible")
        if n == 0:
            self.n,self.d = CTX.constant(0),CTX.constant(1)
            return
        common = n.gcd(d)
        n,d = divide_exact(n,common),divide_exact(d,common)
        leading = d.leading_coefficient()
        self.n,self.d = n/leading,d/leading

    def __bool__(self): return self.n != 0
    def __neg__(self): return RF(-self.n,self.d)
    def __add__(self,other):
        other = RF(other)
        if not other: return self
        if not self: return other
        return RF(self.n*other.d+other.n*self.d,self.d*other.d)
    __radd__ = __add__
    def __sub__(self,other): return self+-RF(other)
    def __rsub__(self,other): return RF(other)+-self
    def __mul__(self,other):
        other = RF(other)
        if not self or not other: return RF(0)
        return RF(self.n*other.n,self.d*other.d)
    __rmul__ = __mul__
    def __truediv__(self,other):
        other = RF(other)
        return RF(self.n*other.d,self.d*other.n)
    def __rtruediv__(self,other): return RF(other)/self
    def __pow__(self,n):
        if not isinstance(n,int): raise TypeError("Only integer powers")
        if n < 0: return RF(self.d**(-n),self.n**(-n))
        return RF(self.n**n,self.d**n)
    def __eq__(self,other):
        other = RF(other)
        return (self.n*other.d-other.n*self.d)%IMOD == 0
    def diff(self,index):
        return RF(self.n.derivative(index)*self.d-self.n*self.d.derivative(index),self.d**2)
    def subs(self,mapping): return RF(self.n.subs(mapping),self.d.subs(mapping))
    def record(self):
        return {"numerator":[[[int(power) for power in k],str(v)] for k,v in self.n.terms()],
                "denominator":[[[int(power) for power in k],str(v)] for k,v in self.d.terms()]}
    def __repr__(self): return f"({self.n})/({self.d})"


r,u,w,E,Er,O,Or,I = [RF(g) for g in GENS]
f = 1-2/r
Lam = 4+6/r
VR = f*(6/r**2-6/r**3)
VZ = f*(16/r**2*(6+6/r)+36/r**4*(4+2/r))/Lam**2
AE,AO,BP = (VZ-w**2)/f**2,(VR-w**2)/f**2,-f.diff(0)/f


def dr(value):
    value = RF(value)
    return value.diff(0)+value.diff(3)*Er+value.diff(4)*(AE*E+BP*Er)+value.diff(5)*Or+value.diff(6)*(AO*O+BP*Or)


def partial(value,coordinate,order):
    value = RF(value)
    if not value: return value
    if coordinate == 0: return -I*w*order*value
    if coordinate == 1: return dr(value)
    if coordinate == 2: return value.diff(1)
    if coordinate == 3: return 2*I*order*value
    raise ValueError("Unknown coordinate")


def field_coefficients(value):
    value = RF(value)
    groups = {}
    allowed = {(1,0,1,0),(1,0,0,1),(0,1,1,0),(0,1,0,1)}
    for powers,coefficient in value.n.terms():
        fields = tuple(powers[3:7])
        if fields not in allowed:
            raise ValueError("Mixed source is not bilinear in parent jets")
        powers = powers[:3]+(0,0,0,0)+powers[7:]
        groups.setdefault(fields,{})[powers] = coefficient
    return {"".join(str(v) for v in key):RF(CTX.from_dict(terms),value.d).record() for key,terms in groups.items()}


def from_record(value):
    return RF(CTX.from_dict({tuple(powers):fmpq(coefficient) for powers,coefficient in value["numerator"]}),
              CTX.from_dict({tuple(powers):fmpq(coefficient) for powers,coefficient in value["denominator"]}))
