"""Reduce the published outgoing strain integral to exact boundary weights."""

import argparse
import json
from math import factorial
from pathlib import Path
import sys

from flint import acb, arb, ctx

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / "published-mixtures-20261123"))
from verify_mixtures import check_mixtures
from angular_algebra import E, Ep, Q, ell, f, k, potential, quadratic
from compare import require
from compare_mixed import admitted_body
from verify import radial_groups, verify_denominators

SCATTERING = HERE.parents[1]
ZERO = Q(0)


def product(left, right, order):
    result = []
    for n in range(order+1):
        start = max(0, n+1-len(right))
        stop = min(n+1, len(left))
        result.append(sum((left[j]*right[n-j] for j in range(start, stop)), ZERO))
    return result


def tortoise_derivative(series, order):
    result = [ZERO]*(order+1)
    for n, coefficient in enumerate(series[1:order], start=1):
        result[n+1] -= n*coefficient
        if n+2 <= order:
            result[n+2] += 2*n*coefficient
    return result


def parent_jets(rate, order):
    # Strip exp(rate*x) and expand in t = 1/r for an odd linear parent.
    h = ell*(ell+1)
    profile = [Q(1)]
    for n in range(1, order+1):
        value = (4*rate*(n-1)+(n-1)*n-h)*profile[n-1]
        if n >= 2:
            value += (2*h+6-2*(n-2)*(2*n-1))*profile[n-2]
        if n >= 3:
            value += (4*(n-3)*(n-1)-12)*profile[n-3]
        profile.append(value/(2*rate*n))

    # Check the recurrence with the differential operator acting on series.
    derivative = tortoise_derivative(profile, order+1)
    second = tortoise_derivative(derivative, order+1)
    potential_series = [ZERO, ZERO, h, -2*h-6, Q(12)]
    residual = product(potential_series, profile, order+1)
    require(all(a+2*rate*b == c for a, b, c in zip(second, derivative, residual, strict=True)),
            "Odd-parent asymptotics fail the wave equation.")
    jet = [rate*a+b for a, b in zip(profile, derivative[:order+1], strict=True)]
    return profile, jet


def laurent_jet(coefficient):
    numerator = radial_groups(coefficient.n)
    denominator = radial_groups(coefficient.d)
    leading = max(denominator)
    inverse_leading = Q(1, denominator[leading])
    if not numerator:
        return -2, [], inverse_leading

    power = max(numerator)
    growth = power-leading
    series = []
    for n in range(growth+2):
        value = Q(numerator.get(power-n, 0))
        for j in range(1, n+1):
            value -= Q(denominator.get(leading-j, 0))*series[n-j]
        series.append(value*inverse_leading)
    return growth, series, inverse_leading


def boundary_series(field):
    # quadratic() is in (J, dJ/dr). Use (J, dJ/dx) in the expansion.
    terms = [laurent_jet(a/f**j) for j, a in enumerate(quadratic(field))]
    leading = max(0, *(g for g, _, _ in terms))
    order = leading+1
    ingress, ingress_jet = parent_jets(-k, order)
    egress, egress_jet = parent_jets(k, order)

    def evaluate(left, left_derivative, right, right_derivative):
        result = [ZERO]*(order+1)
        for (growth, coefficients, _), (a, b) in zip(terms, (
            (left, right),
            (left, right_derivative),
            (left_derivative, right_derivative),
        ), strict=True):
            if coefficients:
                branch_order = growth+1
                weighted = product(coefficients, product(a, b, branch_order), branch_order)
                for j, value in enumerate(weighted, start=leading-growth):
                    result[j] += value
        return result

    incoming = evaluate(ingress, ingress_jet, ingress, ingress_jet)
    outgoing = evaluate(egress, egress_jet, egress, egress_jet)
    mixed_left = evaluate(ingress, ingress_jet, egress, egress_jet)
    mixed_right = evaluate(egress, egress_jet, ingress, ingress_jet)
    mixed = [a+b for a, b in zip(mixed_left, mixed_right, strict=True)]
    return leading, incoming, outgoing, mixed, [inverse for _, _, inverse in terms]


def check_intertwiner():
    for label in (ell, 2*ell):
        _, gamma, W, even, odd = potential(label)
        factor = W*W-gamma*gamma
        slope = f*W.diff(0)
        require(even == factor+slope and odd == factor-slope,
                "The published-wave parity map fails on the two potentials.")
        verify_denominators((1/(gamma-k), 1/(gamma-2*k), W))


def normalized_weights(mixtures):
    # No closed-form response is used to construct the boundary coefficients.
    leading, minus, plus, mixed, factors = boundary_series(E**2+f*E*Ep+(f*Ep)**2)
    require(leading == 0 and minus[0] == 1-k+k*k and plus[0] == 1+k+k*k
            and mixed[0] == 2*(1-k*k),
            "Manufactured boundary term lost a signed or mixed contribution.")
    verify_denominators(factors)

    g = potential(ell)[1]
    incident_odd = (g+k)/(g-k)
    weights = []
    for index, (rho, field) in enumerate(mixtures, start=1):
        leading, minus, plus, mixed, factors = boundary_series(field)
        require(not any(minus[:leading]) and not any(plus[:leading]),
                f"Mixture {index} has a growing same-sign branch.")
        require(not any(mixed[:-1]), f"Mixture {index} has a growing or constant mixed branch.")
        require(not mixed[-1], f"Mixture {index} has an inverse-radius mixed term.")
        incident_strain = 1+rho*incident_odd
        verify_denominators((*factors, 1/k, incident_odd, 1/incident_strain))
        # Division by 4k*A_in gives +1 on the ++ term and -R_O on the -- term.
        weights.append((plus[leading]/incident_strain**2,
                        -incident_odd**2*minus[leading]/incident_strain**2))
    return tuple(weights)


def check_closed_form(weights):
    g = potential(ell)[1]
    gamma_half = potential(2*ell)[1]/2
    # K_l divided by the angular and Eq. (19) strain factor.
    factor = (20*ell**3+35*ell**2+ell-8)*ell**2*(ell-1)**2*(ell+1)*(ell+2)/(288*(2*ell-1))
    expected = (
        (ZERO, factor*k*k/(4*g*g*(k-gamma_half))),
        (factor*k*(k-g*g/gamma_half)/(4*gamma_half*(k+g)**2),
         factor*k/(4*gamma_half*(k-gamma_half))),
    )
    verify_denominators(tuple(weight for pair in expected for weight in pair))
    for index, (measured, target) in enumerate(zip(weights, expected, strict=True), start=1):
        require(measured == target, f"Mixture {index} fails the symbolic direct or reflected weight.")


def angular_strain_factor(label):
    daughter = 2*label
    parent_norm_squared = arb(factorial(label+2))/(4*factorial(label-2))
    daughter_norm = (arb(factorial(daughter+2))/factorial(daughter-2)).sqrt()/2
    harmonic_ratio = (arb(factorial(2*label+1)*factorial(2*label))
                      / (factorial(label)**2*(4*arb.pi()*factorial(4*label+1)).sqrt()))
    return daughter_norm*harmonic_ratio/parent_norm_squared


def evaluate_weight(weight, label, rate):
    def evaluate(poly):
        total = acb(0)
        for powers, coefficient in poly.terms():
            require(not any(p for j, p in enumerate(powers) if j not in (2, 9)),
                    "A boundary weight retained a radial or jet variable.")
            total += arb(coefficient)*rate**int(powers[2])*label**int(powers[9])
        return total
    return evaluate(weight.n)/evaluate(weight.d)


def complex_interval(record):
    return acb(arb(record["real"]), arb(record["imag"]))


def interval_record(value):
    return {"real": value.real.str(60), "imag": value.imag.str(60)}


def numerical_comparison(weights):
    ctx.prec = 640
    ell3 = SCATTERING / "ell3-independent-20261116"
    integral = SCATTERING / "ell3-second-mixture-integration-20261117"
    parent = admitted_body(ell3 / "numerical-qualification/wave-E3-fine/RESULT.json",
                           "ff767f8eca8f69ad6778f12c8a461bca7d1c809fc5c20332a62ea1714f06cadc")
    daughter = admitted_body(ell3 / "linear-recovery/wave-fine/RESULT.json",
                             "aba7352947f462b9060fa5227ce1e60a83c922d02514c397140cf773d2c27b77")
    first = admitted_body(integral / "comparison/compare-A/RESULT.json",
                          "ec446e61d955f807a8fd233fe787ef4f914be4a7adcef61c722d62a9c62d5c55")
    second = admitted_body(integral / "admit-A/RESULT.json",
                           "463c22559fb3ffdb9499ccde4fd47048a82ac67df7443233e7ea2f6a298552c1")
    require(second["prediction_loaded"] is False, "The direct integral used a predicted response.")
    direct = (first["legacy_first_mixture_corrected"]["fine"]["value"],
              second["values"]["fine"]["value"])
    parent_reflection = complex_interval(parent["values"]["reflection"])
    daughter_reflection = complex_interval(daughter["values"]["reflection"])

    normalization = angular_strain_factor(3)
    rate = acb(0, arb(1)/4)
    results = []
    for index, ((a, b), record) in enumerate(zip(weights, direct, strict=True), start=1):
        parent_part = normalization*evaluate_weight(a, 3, rate)*parent_reflection**2
        daughter_part = normalization*evaluate_weight(b, 3, rate)*daughter_reflection
        outgoing = parent_part+daughter_part
        measured = complex_interval(record)
        difference = (outgoing-measured).abs_upper()
        require(outgoing.overlaps(measured) and difference < arb("2e-25"),
                f"Mixture {index} disagrees with the saved complex integral.")
        if index == 2:
            require(not measured.overlaps(parent_part) and not measured.overlaps(daughter_part),
                    "The numerical control cannot distinguish an omitted boundary contribution.")
        results.append({
            "mixture": index,
            "outgoing_strain": interval_record(outgoing),
            "direct_integral": record,
            "absolute_difference_upper": difference.str(20),
            "parent_squared_contribution": interval_record(parent_part),
            "daughter_reflected_contribution": interval_record(daughter_part),
        })
    return results


def verify(archive):
    check_intertwiner()
    mixtures, source_report = check_mixtures(archive)
    weights = normalized_weights(mixtures)
    check_closed_form(weights)
    return {
        "published_source_revision": "5831ae75e20b31489ef2034c8bbb13a53c5d4a3d",
        "domain": "highest-weight equal-frequency parent, integer ell >= 2, real Momega > 0",
        "complete_published_source_replayed": source_report["both_complete_regularized_identities"],
        "zero_horizon_current": source_report["both_regular_on_ingoing_horizon"],
        "same_sign_branches_are_bounded": True,
        "mixed_branch_is_inverse_square_or_faster": True,
        "all_four_normalized_boundary_weights_match_symbolically": True,
        "ell3_quarter_frequency": numerical_comparison(weights),
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("archive", type=Path, help="Read-only pinned author-source directory")
    args = parser.parse_args()
    print(json.dumps(verify(args.archive), indent=2))
