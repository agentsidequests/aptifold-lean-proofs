# Scientific replay root

This marker identifies the directory that holds the pinned scientific inputs.
See REFEREE-START.md at the package root for scope and instructions.
