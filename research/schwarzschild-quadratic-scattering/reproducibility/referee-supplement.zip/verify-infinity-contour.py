"""Check the saved ell=4 fine infinity tail with contour quadrature.

Run python -B verify-infinity-contour.py PATH_TO_ARCHIVED_RADIAL
with Python-FLINT 0.9.0. No files are written. This check uses the pinned
source kernels and sealed Jost amplitudes. It evaluates the infinity piece
without the Taylor expansion of the kernel or integration by parts. The
saved tail is used only in the final comparisons. The finite and horizon
integrals, source compilation, and linear amplitude extraction are outside
this check.
"""

import argparse
from dataclasses import dataclass
from hashlib import sha256
from itertools import product
import json
from math import factorial
from pathlib import Path

from flint import acb, arb, ctx


PINS = {
    "SOURCE.json": "a3e3cc553867d415d2d56a04c4f52c9b96eaf318f7ae62461f0ec411e9b2942b",
    "DIRECT-fine.json": "541b3daa07cc41d7b0e22172828ef576ba729b9f8469b51d8f8e5928ded4d710",
}
PARENT = 4
DAUGHTER = 8
OUTER_RADIUS = 176
CONTOUR_LENGTH = 80
JOST_ORDER = 44
PAIRS = ((0, 0), (0, 1), (1, 1))


def require(condition, message):
    if not condition:
        raise ArithmeticError(message)


def read_pinned(directory, name):
    raw = (directory / name).read_bytes()
    require(sha256(raw).hexdigest() == PINS[name], f"Unexpected bytes in {name}.")
    return json.loads(raw)


def decode(data):
    return acb(arb(data["real"]), arb(data["imag"]))


def evaluate(coefficients, point):
    value = acb(0)
    for coefficient in reversed(coefficients):
        value = value * point + coefficient
    return value


def absolute_polynomial_bound(coefficients, radius):
    return sum(
        (c.abs_upper() * radius**n for n, c in enumerate(coefficients)),
        arb(0),
    ).upper()


@dataclass
class Kernel:
    numerator: tuple
    denominator: tuple

    @classmethod
    def decode(cls, record):
        return cls(
            tuple(acb(arb(a), arb(b)) for a, b in record["n"]),
            tuple(acb(arb(d)) for d in record["d"]),
        )

    def __call__(self, t):
        return evaluate(self.numerator, t) / evaluate(self.denominator, t)

    def bound(self, radius):
        denominator_lower = self.denominator[0].abs_lower() - (
            radius * absolute_polynomial_bound(self.denominator[1:], radius)
        )
        require(denominator_lower > 0, "A rational denominator may vanish on the contour disk.")
        return (absolute_polynomial_bound(self.numerator, radius) / denominator_lower).upper()


@dataclass
class JostPair:
    frequency: arb
    amplitudes: dict
    coefficients: dict
    derivatives: dict
    envelope_bound: tuple
    real_ray_error: tuple

    def jets(self, sign, t, f):
        profile = evaluate(self.coefficients[sign], t)
        derivative = evaluate(self.derivatives[sign], t)
        return profile, acb(0, sign * self.frequency) * profile / f - t*t*derivative


def jost_pair(label, frequency, record, inverse_radius, f_outer):
    # For y=e^(i omega x) P(t), t=1/r, the equation for P is
    # t²(1-2t)P'' + (2t-6t²-2i omega)P' + (6t-ell(ell+1))P = 0.
    angular = label * (label + 1)
    twice_i_frequency = acb(0, 2 * frequency)
    positive = [acb(1)]
    for n in range(JOST_ORDER):
        value = (n * (n + 1) - angular) * positive[n]
        if n:
            value += (8 - 2*n*n) * positive[n - 1]
        positive.append(value / (twice_i_frequency * (n + 1)))

    # Multiply this polynomial residual by f t² to get the RW residual
    # after removing its unit-modulus phase on the real ray. The f cancels
    # against dx/dr. The integral of each t^(n+2) in dr is T^(n+1)/(n+1).
    residual = [acb(0) for _ in range(JOST_ORDER + 2)]
    for n, coefficient in enumerate(positive):
        if n:
            residual[n - 1] -= twice_i_frequency * n * coefficient
        residual[n] += (n * (n + 1) - angular) * coefficient
        residual[n + 1] += (6 - 2*n*(n + 2)) * coefficient
    residual_l1 = sum(
        (c.abs_upper() * inverse_radius**(n + 1) / (n + 1)
         for n, c in enumerate(residual)),
        arb(0),
    )
    potential_l1 = angular*inverse_radius - 3*inverse_radius**2
    require(0 < potential_l1 < frequency, "The Jost Volterra contraction is unresolved.")
    # The free sine Green kernel has supremum 1/omega. Its x derivative
    # has supremum 1, and conversion to d/dr costs at most 1/f(R).
    error_y = (residual_l1 / (frequency - potential_l1)).upper()
    error_yr = ((residual_l1 + potential_l1*error_y) / f_outer).upper()

    coefficients = {1: positive, -1: [c.conjugate() for c in positive]}
    derivatives = {
        sign: [n*c for n, c in enumerate(coefficient) if n]
        for sign, coefficient in coefficients.items()
    }
    p_bound = absolute_polynomial_bound(positive, inverse_radius)
    pr_bound = (
        frequency*p_bound/f_outer
        + inverse_radius**2 * absolute_polynomial_bound(derivatives[1], inverse_radius)
    ).upper()
    amplitudes = {-1: decode(record["A_in"]), 1: decode(record["A_out"])}
    return JostPair(
        frequency, amplitudes, coefficients, derivatives,
        (p_bound, pr_bound), (error_y, error_yr),
    )


def branch_density(t, signs, parent, daughter, kernels):
    ds, ps, pt = signs
    f = 1 - 2*t
    p = parent.jets(ps, t, f)
    pp = parent.jets(pt, t, f)
    d = evaluate(daughter.coefficients[ds], t)
    return d * sum(
        (kernel(t)*p[i]*pp[j] for kernel, (i, j) in zip(kernels, PAIRS, strict=True)),
        acb(0),
    ) / f


def branch_integral(q, density, inverse_radius):
    # For q=0 the inverse-radius change of variables cancels t². Use
    # fixed endpoints 0 and 1, putting the 1/R scale inside the integrand.
    if q == 0:
        def integrand(s, _):
            return inverse_radius * density(inverse_radius * s)
        endpoint = 1
    else:
        ray = acb(0, 1 if q > 0 else -1)

        def integrand(s, analytic):
            r = OUTER_RADIUS + ray*s
            log_argument = (r - 2)/2
            if analytic and not log_argument.real > 0:
                return acb(arb("nan"))
            t = 1/r
            x = r + 2*log_argument.log()
            return ray * (acb(0, q)*x).exp() * t*t * density(t)

        endpoint = CONTOUR_LENGTH
    integral = acb.integral(
        integrand, 0, endpoint, abs_tol=arb("1e-24"),
        rel_tol=arb("1e-27"), eval_limit=5000,
    )
    require(integral.is_finite(), "Branch quadrature did not produce a finite enclosure.")
    return integral


def product_increment(bounds, errors):
    a, b, c = bounds
    da, db, dc = errors
    return da*(b + db)*(c + dc) + a*db*(c + dc) + a*b*dc


def strain_scale(parent, daughter):
    def c_squared(label):
        return arb(factorial(2*label + 1)) / (
            4*arb.pi()*2**(2*label)*factorial(label)**2
        )

    def n_squared(label):
        return arb(factorial(label + 2)) / (4*factorial(label - 2))

    k = acb(0, parent.frequency)
    alpha = (30 + k) / (30 - k)
    angular = c_squared(PARENT) / c_squared(DAUGHTER).sqrt()
    scale = n_squared(DAUGHTER).sqrt() * angular / n_squared(PARENT)
    incident = alpha / parent.amplitudes[-1] / (1 + arb(4)/3)
    return scale * incident**2 / (4*k*daughter.amplitudes[-1])


def verify(directory):
    ctx.prec = 256
    source = read_pinned(directory, "SOURCE.json")
    fine = read_pinned(directory, "DIRECT-fine.json")
    inverse_radius = arb(1) / OUTER_RADIUS
    f_outer = 1 - 2*inverse_radius
    kernels = tuple(map(Kernel.decode, source["kernels"]["inverse_square"]))
    kernel_bounds = [kernel.bound(inverse_radius) for kernel in kernels]
    parent = jost_pair(PARENT, arb(1)/2, fine["linear"]["4"], inverse_radius, f_outer)
    daughter = jost_pair(DAUGHTER, arb(1), fine["linear"]["8"], inverse_radius, f_outer)
    p, d = parent.envelope_bound, daughter.envelope_bound
    ep, ed = parent.real_ray_error, daughter.real_ray_error
    density_bound = d[0] * sum(
        (bound*p[i]*p[j] for bound, (i, j) in zip(kernel_bounds, PAIRS, strict=True)),
        arb(0),
    ) / f_outer
    density_error = sum(
        (bound*product_increment((d[0], p[i], p[j]), (ed[0], ep[i], ep[j]))
         for bound, (i, j) in zip(kernel_bounds, PAIRS, strict=True)),
        arb(0),
    ) / f_outer

    branch_values = {}
    contour_error, jost_error = arb(0), arb(0)
    for signs in product((-1, 1), repeat=3):
        ds, ps, pt = signs
        q = ds + (ps + pt)//2
        amplitude = daughter.amplitudes[ds] * parent.amplitudes[ps] * parent.amplitudes[pt]

        def density(t):
            return branch_density(t, signs, parent, daughter, kernels)

        branch_values[signs] = amplitude * branch_integral(q, density, inverse_radius)

        # The density without t² is analytic for |t| <= 1/R. On the
        # outward quarter-plane the rational factors have O(r^-2) decay
        # after restoring t². The x-log is analytic there and its modulus
        # factor is exp(-2 q arg((r-2)/2)) <= 1 on the chosen ray. The
        # outer arc decays to zero. On the ray the remaining phase modulus
        # is exp(-|q| s). Deform only the Jost polynomials, not exact waves.
        if q:
            contour_error += (
                amplitude.abs_upper() * density_bound * inverse_radius**2
                * arb(-abs(q)*CONTOUR_LENGTH).exp() / abs(q)
            )
        # The error from the exact Jost waves is estimated on the real
        # ray, where each phase has unit modulus and int_R^inf r^-2 dr=1/R.
        jost_error += amplitude.abs_upper() * density_error * inverse_radius

    central = sum(branch_values.values(), acb(0))
    radius = (contour_error + jost_error).upper()
    error = acb(arb(0, radius), arb(0, radius))
    scale = strain_scale(parent, daughter)
    result = scale * (central + error)
    saved = decode(fine["parts"]["infinity"])
    require(saved.contains(result), "The independent tail is outside the saved enclosure.")

    omitted_qq2 = scale * (central - branch_values[(1, 1, 1)] + error)
    require(not saved.overlaps(omitted_qq2), "Omitting the q=+2 branch still matches the saved tail.")
    return {
        "state": "PASS",
        "input_sha256": PINS,
        "condition": "shared source kernels and saved Jost amplitudes",
        "normalized_infinity_tail": {"real": str(result.real), "imag": str(result.imag)},
        "saved_contains_contour_tail": True,
        "normalized_contour_omission_upper": str((contour_error*scale.abs_upper()).upper()),
        "normalized_Jost_residual_upper": str((jost_error*scale.abs_upper()).upper()),
        "omit_q_plus_2_branch_disjoint": True,
        "omit_q_plus_2_branch_distance_lower": str((saved - omitted_qq2).abs_lower()),
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("radial_archive", type=Path)
    print(json.dumps(verify(parser.parse_args().radial_archive), indent=2))
