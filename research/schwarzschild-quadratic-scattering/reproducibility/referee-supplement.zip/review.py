"""Reproduce the theorem and strain checks from the files in this supplement."""

import argparse
from hashlib import sha256
from importlib.util import module_from_spec, spec_from_file_location
import json
from pathlib import Path
import subprocess
import sys
from tempfile import TemporaryDirectory, gettempdir

from flint import arb, ctx, __version__ as flint_version


ROOT = Path(__file__).resolve().parent
STUDY = ROOT / "verification/investigations/gw-likelihood-opportunities-20261101/scattering"
ANGULAR = STUDY / "second-polarization-angular-20261117"
RADIAL = STUDY / "ell4-second-mixture-direct-20261123"
UPSTREAM = ROOT / "upstream"
LIMITS = {"coarse": "1.32e-14", "fine": "1.09e-20"}


def require(condition, message):
    if not condition:
        raise ArithmeticError(message)


def file_hash(path):
    return sha256(path.read_bytes()).hexdigest()


def run(script, *arguments):
    # Keep the process working directory shallow on Windows and give the
    # child an explicit module location even when its script path is long.
    startup = (
        "from pathlib import Path; import runpy, sys; "
        "sys.argv = sys.argv[1:]; sys.path.insert(0, str(Path(sys.argv[0]).parent)); "
        "runpy.run_path(sys.argv[0], run_name='__main__')"
    )
    result = subprocess.run(
        [sys.executable, "-B", "-c", startup, str(script), *map(str, arguments)],
        cwd=ROOT,
        stdout=subprocess.PIPE,
        text=True,
        encoding="utf-8",
        check=True,
    )
    return json.loads(result.stdout)


def rerun_integrations():
    comparison_spec = spec_from_file_location("sealed_strain_comparison", RADIAL / "compare.py")
    comparison = module_from_spec(comparison_spec)
    comparison_spec.loader.exec_module(comparison)
    archived = comparison.verify()

    temp = Path(gettempdir()).resolve(strict=True)
    with TemporaryDirectory(prefix="cqg-referee-", dir=temp) as directory:
        output = Path(directory).resolve(strict=True)
        require(output.parent == temp, "Unexpected replay directory.")
        source = output / "SOURCE.json"
        run(RADIAL / "source.py", UPSTREAM, source)
        require(file_hash(source) == comparison.PINS["SOURCE.json"],
                "Regenerated rational source differs from the reference.")
        rows = {}
        ctx.prec = 512
        for level, limit in LIMITS.items():
            path = output / f"DIRECT-{level}.json"
            run(RADIAL / "direct.py", level, source, path)
            fresh = json.loads(path.read_bytes())
            require(
                (fresh["state"], fresh["level"], fresh["source_sha256"], fresh["closed_response_used"])
                == ("PASS", level, comparison.PINS["SOURCE.json"], False),
                "Fresh result does not bind the tested source to a direct integration.",
            )
            direct = comparison.decode(fresh["strain"])
            archived_direct = comparison.decode(comparison.load_direct(level)["strain"])
            parent, daughter = comparison.coefficients(fresh)
            closed = parent + daughter
            difference = (direct - closed).abs_upper()
            require(direct.overlaps(archived_direct), f"{level} run differs from its archived enclosure.")
            require(direct.overlaps(closed) and difference < arb(limit),
                    f"{level} run misses the manuscript's comparison bound.")
            rows[level] = {
                "absolute_complex_difference_upper": difference.str(22),
                "byte_identical_to_archived_run": file_hash(path) == comparison.PINS[path.name],
            }
    return {"regenerated_published_source_sha256": comparison.PINS["SOURCE.json"],
            "archived_controls": len(archived["checks"]), "new_integrations": rows}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--check", default="all",
                        choices=("all", "certificate", "symbolic", "radial", "contour", "linear", "table"))
    parser.add_argument("--manuscript", type=Path, help="Editable LaTeX for the Table 1 check.")
    args = parser.parse_args()
    requested = args.check
    if requested == "table" and args.manuscript is None:
        parser.error("--check table requires --manuscript.")
    require(flint_version == "0.9.0", "This packet was checked with Python-FLINT 0.9.0.")
    for name, expected in json.loads((ROOT / "SHA256.json").read_text()).items():
        path = (ROOT / name).resolve(strict=True)
        require(path.is_relative_to(ROOT) and file_hash(path) == expected, f"Changed file: {name}.")

    if requested in ("all", "certificate"):
        certificate = run(ROOT / "check-witness-domain.py", ROOT / "certificate")
        require(certificate["state"] == "PASS", "The exclusion certificate failed.")
        print("Certificate: 41 equations, 30 exact zero projections, all allowed parameters.", flush=True)

    if requested in ("all", "symbolic"):
        result = run(ANGULAR / "published-strain-20261123/verify_strain.py", UPSTREAM)
        require(result["complete_published_source_replayed"] and result["zero_horizon_current"]
                and result["all_four_normalized_boundary_weights_match_symbolically"],
                "The exact source or boundary weights did not match.")
        print("Published source: both local identities, horizon cancellation and four strain weights.", flush=True)

    if requested in ("all", "radial"):
        radial = rerun_integrations()
        print(json.dumps({"direct_radial": radial}, indent=2), flush=True)

    if requested in ("all", "contour"):
        contour = run(ROOT / "verify-infinity-contour.py", RADIAL)
        require(contour["state"] == "PASS" and contour["saved_contains_contour_tail"]
                and contour["omit_q_plus_2_branch_disjoint"], "The far-tail cross-check failed.")
        print(json.dumps({"infinity_contour": contour}, indent=2), flush=True)

    if requested in ("all", "linear"):
        linear = run(ROOT / "verify_linear_reflections.py", RADIAL)
        require(linear["state"] == "PASS", "The independent linear reflections did not match.")
        print(json.dumps({"independent_linear_reflections": linear}, indent=2), flush=True)

    if requested in ("all", "table") and args.manuscript is not None:
        table = run(ROOT / "check-table-bounds.py", args.manuscript.resolve(strict=True), ROOT, STUDY, RADIAL)
        require(table["state"] == "PASS", "An exported benchmark misses the printed bound.")
        print(json.dumps({"printed_table": table}, indent=2), flush=True)

    print(f"PASS: {requested}.")


if __name__ == "__main__":
    main()
