# Referee guide

**Rational local solutions in quadratic Schwarzschild scattering**

Theorem 1 classifies local particular fields with rational coefficients at
every integer ell ≥ 2 and positive real common parent frequency, in the
channel (ell, ell) + (ell, ell) → (2 ell, 2 ell). The common normalization,
projection and phase convention are in Section 2. The radial benchmark is
the second mixture at ell = 4 and M omega = 1/2.

## Run the checks

Extract the archive. From this directory, use Python 3.13 with Python-FLINT
0.9.0. Once that package is installed, the checks run offline. The
required upstream files and their MIT license are in the archive. The
upstream revision is 5831ae75e20b31489ef2034c8bbb13a53c5d4a3d.

    python -m pip install python-flint==0.9.0
    python -B review.py

Each check also runs separately with `--check` and one of the names below.
The driver checks the bundled inputs against SHA256.json before running.

| Check | Start in the manuscript | What the command verifies |
| --- | --- | --- |
| certificate | Section 3 and Appendices A–B | Rebuilds the 41 by 30 operator matrix from the parent and daughter equations. Verifies that all 30 columns give zero under the witness, and that the odd–odd source projection stays nonzero over the entire stated domain. |
| symbolic | Sections 3–4 | Starts from the pinned generated Julia expressions for all three parity sectors. It compares the coefficients in the common parent basis, checks both regularized identities and the simple-pole horizon argument, and evaluates the four strain weights exactly. |
| radial | Section 5, Table 1 | Regenerates the rational radial kernels from the pinned published files. Computes the waves and direct integral on two fresh grids. Checks their agreement with the archived results and with the boundary formula formed from the same linear reflections. |
| contour | Section 5, infinity integral | Re-evaluates the fine infinity contribution with the same radial kernels and saved linear amplitudes, using inverse radius for the resonant terms and a complex contour for the oscillatory terms. The saved enclosure contains the result and omitting the q = +2 branch fails. |
| linear | Section 5, linear reflection inputs | Solves the even parent and odd daughter independently at three resolutions and substitutes the new complex reflection amplitudes into the closed response. Reports refinement, current conservation and the effect of a changed phase origin or parity. |
| table | Section 5, Table 1 | With the editable LaTeX source, compares each printed error bound with the complex intervals in the actual referee package. |

The final line should be PASS. To check the printed table too, point to the
manuscript file from the editable source ZIP.

    python -B review.py --check table --manuscript "path/to/schwarzschild.tex"

The default command runs the other five checks without a manuscript file. For the radial check the target distance
bounds between the two complex enclosures are 1.32e-14 (coarse) and
1.09e-20 (fine) in normalized strain. The output reports byte agreement
with the archived runs separately from agreement of the enclosures.
The exact identities are checked symbolically in r, ell and k = i omega.
The runtime tests leave the analytic pole and fixed-parent arguments to
Appendices A–B.
The archived ell = 2 comparisons for Table 1 are in benchmarks/. The
symbolic check compares the archived ell = 3 enclosures with the exact
strain weights.

## Start here to try to falsify the theorem

Read the factorization in Section 3.1. A third mixture would require a
local rational solution for the bare odd–odd forcing. Rebuild that
forcing from upstream/jl/generated/SourceOOE.jl. Use the identical-parent
factor, the odd phase convention and the daughter Darboux map in the
paper. Compare the coefficients of J², JZ and Z² with the odd–odd array
in certificate/data/assembly.json. In Section 3.2 check which poles the
operator can generate and whether a proposed larger pole or degree
can escape the bounds. The exact replay checks the source and the
weighting of the resulting 41 equations.

For the physical normalization, start with the incoming/outgoing masters
in Section 4 and check the sign of the daughter boundary subtraction.
The second mixture's two contributions are about 48 times the magnitude
of their sum at the benchmark. In the replay, either omitted contribution
or either reversed sign fails against the fine enclosure.

The supplied source replay uses the published generated source. A
derivation of those kernels directly from Einstein's equations and a
numerical calculation in a different implementation remain distinct
ways to check the work. A discrepancy report is most useful with its
equation, coefficient or phase convention and exact angular and
frequency settings.

- [Bucciotti et al., scattering equations and convention, v2](https://arxiv.org/html/2609.20934v2)
- [Pinned upstream implementation](https://github.com/jredondoyuste/BlackHoleNonlinearities.jl/tree/5831ae75e20b31489ef2034c8bbb13a53c5d4a3d)
